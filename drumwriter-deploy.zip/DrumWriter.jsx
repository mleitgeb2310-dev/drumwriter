import React, { useState, useRef, useCallback, useEffect } from "react";

// ── Constants ─────────────────────────────────────────────────────────────
var LS=8, STOP=52, NOTE_R=4.0, X_SZ=4.2, STEM_LEN=22, BEAM_H=3.5, BEAM_G=5;
var CLEF_W=26, BAR_PAD=5, SNAP_BEATS=0.04, DEFAULT_NV_ID="16";
var MIN_BEAT_W=14;

function staffLineY(i){ return STOP+i*LS; }

var INSTRUMENTS=[
  {id:"crash",  name:"Crash",     isX:true,  isDiamond:false, sy:-1.5, voice:1},
  {id:"hihat",  name:"Hi-Hat",    isX:true,  isDiamond:false, sy:-0.5, voice:1},
  {id:"ride",   name:"Ride",      isX:true,  isDiamond:false, sy:0,    voice:1},
  {id:"tom1",   name:"Tom 1",     isX:false, isDiamond:false, sy:0.5,  voice:1},
  {id:"tom2",   name:"Tom 2",     isX:false, isDiamond:false, sy:1,    voice:1},
  {id:"snare",  name:"Snare",     isX:false, isDiamond:false, sy:1.5,  voice:1},
  {id:"floor",  name:"Floor Tom", isX:false, isDiamond:false, sy:3.5,  voice:1},
  {id:"kick",   name:"Kick",      isX:false, isDiamond:false, sy:4.5,  voice:2},
  {id:"hihat_f",name:"HH Pedal",  isX:true,  isDiamond:true,  sy:5.5,  voice:2},
];

var NOTE_VALUES=[
  {id:"1",  label:"Ganze",       flag:0, dur:4,    triolen:false, half:false},
  {id:"2",  label:"Halbe",       flag:0, dur:2,    triolen:false, half:true},
  {id:"4",  label:"Viertel",     flag:0, dur:1,    triolen:false, half:false},
  {id:"8",  label:"Achtel",      flag:1, dur:0.5,  triolen:false, half:false},
  {id:"16", label:"Sechzehntel", flag:2, dur:0.25, triolen:false, half:false},
  {id:"8t", label:"Triole",      flag:1, dur:1/3,  triolen:true,  half:false},
];

var TIME_SIGS=["4/4","3/4","6/8","2/4","5/4"];
var ACCENT_TYPES=[
  {id:"normal",label:"Normal",sym:""},
  {id:"ghost", label:"Ghost",  sym:"()"},
  {id:"accent",label:"Akzent", sym:">"},
  {id:"flam",  label:"Flam",   sym:"f"},
];
var SECTION_MARKS=["","Intro","Verse","Pre-Chorus","Chorus","Bridge","Outro","Fill","Solo"];

var ORCH_SYMBOLS=[
  {id:"segno",     label:"Segno",           cat:"nav",  unicode:"\u{1D10B}"},
  {id:"coda",      label:"Coda",            cat:"nav",  unicode:"\u{1D10C}"},
  {id:"dc",        label:"D.C.",            cat:"nav",  text:"D.C."},
  {id:"dc_coda",   label:"D.C. al Coda",    cat:"nav",  text:"D.C. al Coda"},
  {id:"dc_fine",   label:"D.C. al Fine",    cat:"nav",  text:"D.C. al Fine"},
  {id:"ds",        label:"D.S.",            cat:"nav",  text:"D.S."},
  {id:"ds_coda",   label:"D.S. al Coda",    cat:"nav",  text:"D.S. al Coda"},
  {id:"fine",      label:"Fine",            cat:"nav",  text:"Fine"},
  {id:"fermata",   label:"Fermata",         cat:"str",  unicode:""},
  {id:"volta1",    label:"1. Haus",         cat:"str",  text:"1."},
  {id:"volta2",    label:"2. Haus",         cat:"str",  text:"2."},
  {id:"rehearsal", label:"Probe A-Z",       cat:"str",  isRehearsal:true},
  {id:"bar_rep",   label:"% Taktwdh.",      cat:"str",  unicode:"%"},
  {id:"dyn_pp",    label:"pp",              cat:"dyn",  text:"pp"},
  {id:"dyn_p",     label:"p",               cat:"dyn",  text:"p"},
  {id:"dyn_mp",    label:"mp",              cat:"dyn",  text:"mp"},
  {id:"dyn_mf",    label:"mf",              cat:"dyn",  text:"mf"},
  {id:"dyn_f",     label:"f",               cat:"dyn",  text:"f"},
  {id:"dyn_ff",    label:"ff",              cat:"dyn",  text:"ff"},
  {id:"cresc",     label:"< cresc.",        cat:"dyn",  text:"cresc."},
  {id:"decresc",   label:"> decresc.",      cat:"dyn",  text:"decresc."},
  {id:"slash",     label:"/ Slash",         cat:"patt", isSlash:true},
  {id:"rep_start", label:"||: Anfang",      cat:"rep",  repeatValue:"start"},
  {id:"rep_end",   label:":|| Ende",        cat:"rep",  repeatValue:"end"},
  {id:"rep_both",  label:":||: Beides",     cat:"rep",  repeatValue:"both"},
  {id:"rep_none",  label:"Keine",           cat:"rep",  repeatValue:"none"},
];

function instrById(id){return INSTRUMENTS.find(function(i){return i.id===id;});}
function nvById(id){return NOTE_VALUES.find(function(n){return n.id===id;})||NOTE_VALUES[4];}
function noteY(instr){return staffLineY(0)+instr.sy*LS;}
function beatsInMeasure(ts){var p=ts.split("/").map(Number);return p[0]*(4/p[1]);}

function beatToX(beat,total,barW){return BAR_PAD+(beat/total)*(barW-BAR_PAD*2);}
function xToBeat(x,barW,total){var f=(x-BAR_PAD)/(barW-BAR_PAD*2);return Math.max(0,Math.min(total-0.01,f*total));}
function snapBeat(beat,nvId,total){var nv=nvById(nvId),grid=nv.dur,s=Math.round(beat/grid)*grid;return Math.min(s,total-grid);}
function minMeasW(timeSig){var total=beatsInMeasure(timeSig);return (total/0.25)*MIN_BEAT_W+BAR_PAD*2;}

var _id=0;
function uid(){_id++;return String(_id);}
function newMeasure(ts,notes,section){
  return {id:uid(),timeSig:ts||"4/4",notes:notes||{},section:section||"",
          repeat:"none",comment:"",symbols:[],voltaLabel:"",rehearsalLetter:""};
}

function makeBeats(instrId,beats,nvId,accent){
  var notes={};
  beats.forEach(function(b){notes[instrId+":"+b.toFixed(6)]={accent:accent||"normal",nvId:nvId||"8"};});
  return notes;
}
function mergeNotes(){
  var r={};
  for(var i=0;i<arguments.length;i++){var s=arguments[i];for(var k in s){if(s.hasOwnProperty(k))r[k]=s[k];}}
  return r;
}

var HH_PRESETS=[
  {id:"hh_q",    label:"Viertel",      desc:"4 Schlage",        notes:makeBeats("hihat",[0,1,2,3],"4")},
  {id:"hh_8",    label:"Achtel",       desc:"8 Schlage",        notes:makeBeats("hihat",[0,0.5,1,1.5,2,2.5,3,3.5],"8")},
  {id:"hh_16",   label:"Sechzehntel",  desc:"16 Schlage",       notes:makeBeats("hihat",[0,0.25,0.5,0.75,1,1.25,1.5,1.75,2,2.25,2.5,2.75,3,3.25,3.5,3.75],"16")},
  {id:"hh_skip", label:"Skip",         desc:"Achtel, Pause 4+", notes:makeBeats("hihat",[0,0.5,1,1.5,2,2.5,3],"8")},
  {id:"ride_8",  label:"Ride Achtel",  desc:"Ride 8 Schlage",   notes:makeBeats("ride",[0,0.5,1,1.5,2,2.5,3,3.5],"8")},
  {id:"crash_1", label:"Crash auf 1",  desc:"Crash Akzent",     notes:makeBeats("crash",[0],"4","accent")},
];
var SN_PRESETS=[
  {id:"sn_24",   label:"2 und 4",      desc:"Backbeat klassisch",notes:makeBeats("snare",[1,3],"4")},
  {id:"sn_24acc",label:"2+4 Akzent",   desc:"Backbeat akzentuiert",notes:makeBeats("snare",[1,3],"4","accent")},
  {id:"sn_ht",   label:"Half-Time",    desc:"Nur Zahlzeit 3",   notes:makeBeats("snare",[2],"4")},
  {id:"sn_ghost",label:"+Ghost",       desc:"Backbeat + Ghosts", notes:mergeNotes(makeBeats("snare",[1,3],"4"),makeBeats("snare",[0.5,1.5,2.5,3.5],"8","ghost"))},
];
var KI_PRESETS=[
  {id:"ki_13",   label:"1 und 3",      desc:"Standard",         notes:makeBeats("kick",[0,2],"4")},
  {id:"ki_4fl",  label:"4-on-floor",   desc:"Alle Viertel",     notes:makeBeats("kick",[0,1,2,3],"4")},
  {id:"ki_13and",label:"1, 3, 3+",     desc:"Mit Vorlauf",      notes:makeBeats("kick",[0,2,2.5],"8")},
  {id:"ki_hhped",label:"HH-Pedal 2+4", desc:"Fuss hi-hat",      notes:makeBeats("hihat_f",[1,3],"4")},
];
var PRESET_GROUPS=[
  {label:"Hi-Hat / Ride / Crash", presets:HH_PRESETS, color:"#5b8af0"},
  {label:"Snare",                 presets:SN_PRESETS,  color:"#e05c5c"},
  {label:"Kick / HH-Pedal",       presets:KI_PRESETS,  color:"#4caf80"},
];
function applyPresets(ids){
  var notes={};
  ids.forEach(function(pid){
    PRESET_GROUPS.forEach(function(g){g.presets.forEach(function(p){if(p.id===pid)notes=mergeNotes(notes,p.notes);});});
  });
  return notes;
}

// Layout
function groupChords(raw,stemUp){
  raw.sort(function(a,b){return a.beat-b.beat||a.instr.sy-b.instr.sy;});
  var cols=[];
  raw.forEach(function(n){
    var col=null;
    for(var i=0;i<cols.length;i++){if(Math.abs(cols[i].beat-n.beat)<=SNAP_BEATS){col=cols[i];break;}}
    if(col)col.notes.push(n);else cols.push({beat:n.beat,x:n.x,notes:[n]});
  });
  var chords=[],noteList=[];
  cols.forEach(function(col){
    col.notes.sort(function(a,b){return a.instr.sy-b.instr.sy;});
    var ys=col.notes.map(function(n){return noteY(n.instr);});
    var tipY=stemUp?Math.min.apply(null,ys)-STEM_LEN:Math.max.apply(null,ys)+STEM_LEN;
    var maxF=Math.max.apply(null,col.notes.map(function(n){return n.flags;}));
    var hasTri=col.notes.some(function(n){return n.triolen;});
    chords.push({x:col.x,beat:col.beat,tipY:tipY,stemUp:stemUp,flags:maxF,triolen:hasTri,notes:col.notes});
    col.notes.forEach(function(n){
      noteList.push({key:n.key,instrId:n.instrId,instr:n.instr,beat:n.beat,
        x:col.x,y:noteY(n.instr),tipY:tipY,stemUp:stemUp,
        accent:n.accent,nvId:n.nvId,flags:n.flags,half:n.half});
    });
  });
  return {chords:chords,noteList:noteList};
}

function computeLayout(notes,timeSig,barW){
  var total=beatsInMeasure(timeSig),r1=[],r2=[];
  for(var __k in notes){(function(key){
    var note=notes[key],parts=key.split(":"),instrId=parts[0],beat=parseFloat(parts[1]);
    var instr=instrById(instrId);if(!instr)return;
    var nv=nvById(note.nvId||DEFAULT_NV_ID);
    if(beat>=total)return;
    var x=beatToX(beat,total,barW);
    var n={key:key,instrId:instrId,instr:instr,beat:beat,x:x,
           accent:note.accent,nvId:nv.id,flags:nv.flag,triolen:nv.triolen,half:nv.half,dur:nv.dur};
    if(instr.voice===2&&nv.flag>0)r2.push(n);else r1.push(n);
  })(__k);}
  var v1=groupChords(r1,true),v2=groupChords(r2,false);
  return {noteList:v1.noteList.concat(v2.noteList),chords1:v1.chords,chords2:v2.chords,total:total};
}

function buildBeamGroups(chords){
  if(!chords.length)return[];
  var groups={};
  chords.forEach(function(c){
    if(c.flags===0)return;
    var g=Math.floor(c.beat+0.001);
    if(!groups[g])groups[g]={chords:[],maxFlags:0,triolen:false};
    if(c.flags>groups[g].maxFlags)groups[g].maxFlags=c.flags;
    if(c.triolen)groups[g].triolen=true;
    groups[g].chords.push(c);
  });
  var arr=[];
  for(var k in groups){if(groups.hasOwnProperty(k)&&groups[k].chords.length>=2)arr.push(groups[k]);}
  return arr;
}

function Notehead({x,y,instr,accent,half,onClick,onMouseDown,onTouchStart,onMouseUp,onTouchEnd,onMouseLeave}){
  var ghost=accent==="ghost",col="#111",al=1;
  var head;
  if(instr.isX){
    head=<g>
      <line x1={x-X_SZ} y1={y-X_SZ} x2={x+X_SZ} y2={y+X_SZ} stroke={col} strokeWidth={2.0}/>
      <line x1={x+X_SZ} y1={y-X_SZ} x2={x-X_SZ} y2={y+X_SZ} stroke={col} strokeWidth={2.0}/>
    </g>;
  } else if(instr.isDiamond){
    head=<polygon points={`${x},${y-NOTE_R-1} ${x+NOTE_R+2},${y} ${x},${y+NOTE_R+1} ${x-NOTE_R-2},${y}`}
      fill={col} stroke={col} strokeWidth={0}/>;
  } else {
    head=<ellipse cx={x} cy={y} rx={NOTE_R+0.8} ry={NOTE_R-0.5} transform={`rotate(-12,${x},${y})`}
      fill={half?"none":col} stroke={col} strokeWidth={half?1.8:0}/>;
  }
  return(
    <g onClick={onClick} onMouseDown={onMouseDown} onTouchStart={onTouchStart} onMouseUp={onMouseUp} onTouchEnd={onTouchEnd} onMouseLeave={onMouseLeave} style={{cursor:"pointer"}}>
      {head}
      {ghost&&<g>
        <text x={x-9} y={y+4} fontSize="13" fontFamily="serif" fill="#111" fontWeight="400" style={{pointerEvents:"none"}}>(</text>
        <text x={x+4} y={y+4} fontSize="13" fontFamily="serif" fill="#111" fontWeight="400" style={{pointerEvents:"none"}}>)</text>
      </g>}
      {accent==="accent"&&<text x={x} y={y-STEM_LEN-4} textAnchor="middle" fontSize="11" fontWeight="900" fill={col} fontFamily="serif" style={{pointerEvents:"none"}}>{">"}</text>}
    </g>
  );
}

function WholeRest({cx}){return <rect x={cx-10} y={staffLineY(1)-4} width={20} height={5} fill="#111" rx={1}/>;}

function TrioleBracket({x1,x2,y}){
  var mx=(x1+x2)/2;
  return <g>
    <line x1={x1} y1={y} x2={x2} y2={y} stroke="#444" strokeWidth={1}/>
    <line x1={x1} y1={y} x2={x1} y2={y+5} stroke="#444" strokeWidth={1}/>
    <line x1={x2} y1={y} x2={x2} y2={y+5} stroke="#444" strokeWidth={1}/>
    <text x={mx} y={y-3} textAnchor="middle" fontSize="9" fill="#444" fontFamily="serif" fontStyle="italic">3</text>
  </g>;
}

function ChordBeams({groups,stemUp}){
  var up=stemUp!==false;
  return <g>{groups.map(function(g,gi){
    var cs=g.chords;
    if(cs.length<2)return null;
    var f=cs[0],l=cs[cs.length-1];
    var x1=f.x,x2=l.x,y1=f.tipY,y2=l.tipY;
    var slope=Math.max(-0.3,Math.min(0.3,(y2-y1)/(x2-x1||1)));
    var yAt=function(x){return y1+slope*(x-x1);};
    var off=up?BEAM_G:-BEAM_G;
    var ty=up?Math.min.apply(null,cs.map(function(c){return c.tipY;}))-12:Math.max.apply(null,cs.map(function(c){return c.tipY;}))+12;
    var beams=[<line key="b1" x1={x1} y1={y1} x2={x2} y2={yAt(x2)} stroke="#111" strokeWidth={BEAM_H} strokeLinecap="butt"/>];
    for(var i=0;i<cs.length-1;i++){
      if(cs[i].flags>=2&&cs[i+1].flags>=2){
        beams.push(<line key={"b2_"+i} x1={cs[i].x} y1={yAt(cs[i].x)+off} x2={cs[i+1].x} y2={yAt(cs[i+1].x)+off} stroke="#111" strokeWidth={BEAM_H} strokeLinecap="butt"/>);
      }
    }
    if(g.triolen)beams.push(<TrioleBracket key="tri" x1={x1} x2={x2} y={ty}/>);
    return <g key={gi}>{beams}</g>;
  })}</g>;
}

function Barline({x,repeat}){
  var y1=staffLineY(0),y2=staffLineY(4);
  var d1=staffLineY(1)+LS*0.5,d2=staffLineY(2)+LS*0.5;
  if(repeat==="end"||repeat==="both")return <g>
    <line x1={x-6} y1={y1} x2={x-6} y2={y2} stroke="#111" strokeWidth={1.2}/>
    <line x1={x-2} y1={y1} x2={x-2} y2={y2} stroke="#111" strokeWidth={3.5}/>
    <circle cx={x-10} cy={d1} r={1.8} fill="#111"/>
    <circle cx={x-10} cy={d2} r={1.8} fill="#111"/>
  </g>;
  return <line x1={x} y1={y1} x2={x} y2={y2} stroke="#111" strokeWidth={1.3}/>;
}

function StartRepeat({x}){
  var y1=staffLineY(0),y2=staffLineY(4);
  var d1=staffLineY(1)+LS*0.5,d2=staffLineY(2)+LS*0.5;
  return <g>
    <line x1={x+1} y1={y1} x2={x+1} y2={y2} stroke="#111" strokeWidth={3.5}/>
    <line x1={x+6} y1={y1} x2={x+6} y2={y2} stroke="#111" strokeWidth={1.2}/>
    <circle cx={x+10} cy={d1} r={1.8} fill="#111"/>
    <circle cx={x+10} cy={d2} r={1.8} fill="#111"/>
  </g>;
}

function VoltaBracket({x,w,label}){
  var y=staffLineY(0)-14;
  return <g>
    <line x1={x} y1={y+10} x2={x} y2={y} stroke="#111" strokeWidth={1.2}/>
    <line x1={x} y1={y} x2={x+w-2} y2={y} stroke="#111" strokeWidth={1.2}/>
    <text x={x+4} y={y+9} fontSize="8" fill="#111" fontFamily="serif">{label}</text>
  </g>;
}

function FermataSign({x,y}){
  return <g>
    <path d={`M${x-8},${y} A8,6 0 0,1 ${x+8},${y}`} fill="none" stroke="#111" strokeWidth={1.3}/>
    <circle cx={x} cy={y+2} r={1.8} fill="#111"/>
  </g>;
}

function SlashNotation({measW,total}){
  var marks=[];
  for(var b=0;b<total;b+=1){
    var x=beatToX(b+0.5,total,measW);
    var y=staffLineY(2);
    marks.push(<g key={b}>
      <line x1={x-5} y1={y+6} x2={x+5} y2={y-6} stroke="#555" strokeWidth={2}/>
    </g>);
  }
  return <g>{marks}</g>;
}

function OrchSymbols({symbols,measW,voltaLabel,rehearsalLetter}){
  if(!symbols||!symbols.length)return null;
  var top=staffLineY(0);
  var items=symbols.map(function(sym,i){
    var def=ORCH_SYMBOLS.find(function(s){return s.id===sym.id;});
    if(!def)return null;
    var x=measW-8,y=top-22;
    if(def.cat==="nav"){
      return <text key={i} x={x} y={y} textAnchor="end" fontSize="8.5" fontFamily="Times New Roman,serif" fontStyle="italic" fill="#222">{def.text||def.unicode}</text>;
    } else if(def.id==="fermata"){
      return <FermataSign key={i} x={measW-6} y={top-18}/>;
    } else if(def.id==="volta1"||def.id==="volta2"){
      return <VoltaBracket key={i} x={0} w={measW} label={sym.label||def.text}/>;
    } else if(def.id==="bar_rep"){
      var mx=measW/2,my=staffLineY(2);
      return <g key={i}>
        <line x1={mx-8} y1={my+6} x2={mx+8} y2={my-6} stroke="#333" strokeWidth={2}/>
        <circle cx={mx-10} cy={my-3} r={1.8} fill="#333"/>
        <circle cx={mx+10} cy={my+3} r={1.8} fill="#333"/>
      </g>;
    } else if(def.cat==="dyn"){
      return <text key={i} x={4} y={staffLineY(4)+22} fontSize="10" fontFamily="Times New Roman,serif" fontStyle="italic" fontWeight="bold" fill="#222">{def.text}</text>;
    } else if(def.isRehearsal){
      var rl=sym.letter||"A";
      return <g key={i}>
        <rect x={2} y={top-32} width={16} height={14} fill="none" stroke="#111" strokeWidth={1.5} rx={1}/>
        <text x={10} y={top-22} textAnchor="middle" fontSize="9" fontWeight="bold" fontFamily="sans-serif" fill="#111">{rl}</text>
      </g>;
    }
    return null;
  });
  return <g>{items}</g>;
}

function MeasureContent({m,measW,onToggleNote,selInstr,selNVId,highlight,onChangeInstr,onLongPress,lpNote,selNote,onSelectNote}){
  var lay=computeLayout(m.notes,m.timeSig,measW);
  var nl=lay.noteList,c1=lay.chords1,c2=lay.chords2;
  var lpPressState=useState(null); var lpPress=lpPressState[0]; var setLpPress=lpPressState[1];
  var bg1=buildBeamGroups(c1),bg2=buildBeamGroups(c2);
  var beamed1={},beamed2={};
  bg1.forEach(function(g){g.chords.forEach(function(c){beamed1[c.beat.toFixed(6)]=true;});});
  bg2.forEach(function(g){g.chords.forEach(function(c){beamed2[c.beat.toFixed(6)]=true;});});
  var lone1=c1.filter(function(c){return c.flags>0&&!beamed1[c.beat.toFixed(6)];});
  var lone2=c2.filter(function(c){return c.flags>0&&!beamed2[c.beat.toFixed(6)];});
  var hasSlash=m.symbols&&m.symbols.some(function(s){return s.id==="slash";});

  return <g>
    {highlight&&<rect x={0} y={staffLineY(0)-8} width={measW} height={staffLineY(4)-staffLineY(0)+16} fill="#4f6ef7" fillOpacity={0.07} rx={3}/>}
    <OrchSymbols symbols={m.symbols} measW={measW} voltaLabel={m.voltaLabel} rehearsalLetter={m.rehearsalLetter}/>
    {hasSlash&&<SlashNotation measW={measW} total={beatsInMeasure(m.timeSig)}/>}
    {nl.length===0&&!hasSlash&&<WholeRest cx={measW/2}/>}
    {nl.filter(function(n){return n.instr.sy<0;}).map(function(n){
      var ls=[];for(var ly=-1;ly>=Math.ceil(n.instr.sy);ly--)
        ls.push(<line key={ly} x1={n.x-9} y1={staffLineY(ly)} x2={n.x+9} y2={staffLineY(ly)} stroke="#111" strokeWidth={0.9}/>);
      return <g key={n.key+"la"}>{ls}</g>;
    })}
    {nl.filter(function(n){return n.instr.sy>4;}).map(function(n){
      var ls=[];for(var ly=5;ly<=Math.floor(n.instr.sy);ly++)
        ls.push(<line key={ly} x1={n.x-9} y1={staffLineY(ly)} x2={n.x+9} y2={staffLineY(ly)} stroke="#111" strokeWidth={0.9}/>);
      return <g key={n.key+"lb"}>{ls}</g>;
    })}
    {c1.filter(function(c){return c.notes[0]&&nvById(c.notes[0].nvId).id!=="1";}).map(function(c,ci){
      var bot=Math.max.apply(null,c.notes.map(function(n){return noteY(n.instr);}));
      return <line key={"s1"+ci} x1={c.x} y1={c.tipY} x2={c.x} y2={bot} stroke="#111" strokeWidth={1.3}/>;
    })}
    {c2.filter(function(c){return c.notes[0]&&nvById(c.notes[0].nvId).id!=="1";}).map(function(c,ci){
      var top=Math.min.apply(null,c.notes.map(function(n){return noteY(n.instr);}));
      return <line key={"s2"+ci} x1={c.x} y1={c.tipY} x2={c.x} y2={top} stroke="#111" strokeWidth={1.3}/>;
    })}
    <ChordBeams groups={bg1} stemUp={true}/>
    <ChordBeams groups={bg2} stemUp={false}/>
    {lone1.map(function(c,ci){
      var sx=c.x,sy=c.tipY;
      return <g key={"f1"+ci}>
        <path d={`M${sx},${sy} C${sx+13},${sy+6} ${sx+11},${sy+15} ${sx},${sy+17}`} fill="none" stroke="#111" strokeWidth={1.3}/>
        {c.flags>=2&&<path d={`M${sx},${sy+7} C${sx+13},${sy+13} ${sx+11},${sy+22} ${sx},${sy+24}`} fill="none" stroke="#111" strokeWidth={1.3}/>}
      </g>;
    })}
    {lone2.map(function(c,ci){
      var sx=c.x,sy=c.tipY;
      return <g key={"f2"+ci}>
        <path d={`M${sx},${sy} C${sx+13},${sy-6} ${sx+11},${sy-15} ${sx},${sy-17}`} fill="none" stroke="#111" strokeWidth={1.3}/>
        {c.flags>=2&&<path d={`M${sx},${sy-7} C${sx+13},${sy-13} ${sx+11},${sy-22} ${sx},${sy-24}`} fill="none" stroke="#111" strokeWidth={1.3}/>}
      </g>;
    })}
    {nl.filter(function(n){return nvById(n.nvId).id!=="1";}).map(function(n){
      var isLpSelected=lpNote&&lpNote.key===n.key;
      var isNoteSelected=selNote&&selNote.key===n.key;
      return <g key={n.key+"wrap"}>

        {isNoteSelected&&<circle cx={n.x} cy={n.y} r={13}
          fill="#40c4ff" fillOpacity={0.15}
          stroke="#40c4ff" strokeWidth={2}
          opacity={1}
          style={{filter:"drop-shadow(0 0 6px #40c4ff)"}}/>}
        {isNoteSelected&&<circle cx={n.x} cy={n.y} r={18}
          fill="none" stroke="#40c4ff" strokeWidth={0.8}
          opacity={0.4}/>}
        {isLpSelected&&<circle cx={n.x} cy={n.y} r={14}
          fill="#e040fb" fillOpacity={0.1}
          stroke="#e040fb" strokeWidth={2.5}
          opacity={1}
          style={{filter:"drop-shadow(0 0 8px #e040fb)"}}/>}
        <Notehead key={n.key} x={n.x} y={n.y} instr={n.instr} accent={n.accent} half={n.half}
          onClick={function(e){e.stopPropagation();}}/>
      </g>;
    })}

    {nl.filter(function(n){return nvById(n.nvId).id==="1";}).map(function(n){
      return <ellipse key={n.key+"wn"} cx={n.x} cy={n.y} rx={NOTE_R+2} ry={NOTE_R}
        transform={`rotate(-12,${n.x},${n.y})`} fill="none" stroke="#111" strokeWidth={2}
        onClick={function(e){e.stopPropagation();if(onToggleNote)onToggleNote(m.id,n.instrId,n.beat,n.nvId);}}
        style={{cursor:"pointer"}}/>;
    })}
    {nl.filter(function(n){return n.accent==="flam";}).map(function(n){
      return <g key={n.key+"fl"}>
        <ellipse cx={n.x-10} cy={n.y-3} rx={NOTE_R-1} ry={NOTE_R-1.5} transform={`rotate(-12,${n.x-10},${n.y-3})`} fill="#111"/>
        <line x1={n.x-10} y1={n.y-3} x2={n.x-10} y2={n.y-15} stroke="#111" strokeWidth={1}/>
      </g>;
    })}
    <Barline x={measW-1} repeat={m.repeat}/>
    {(m.repeat==="start"||m.repeat==="both")&&<StartRepeat x={0}/>}
  </g>;
}

function LegendSVG({width}){
  var W=width,col="#333";
  var items=[
    {instr:instrById("crash"),label:"Crash"},
    {instr:instrById("hihat"),label:"Hi-Hat"},
    {instr:instrById("ride"), label:"Ride"},
    {instr:instrById("snare"),label:"Snare"},
    {instr:instrById("tom1"), label:"Tom 1"},
    {instr:instrById("tom2"), label:"Tom 2"},
    {instr:instrById("floor"),label:"Floor"},
    {instr:instrById("kick"), label:"Kick"},
    {instr:instrById("hihat_f"),label:"HH Ped."},
  ];
  var H=24,pad=10,itemW=Math.min(84,(W-pad*2-52)/items.length);
  return(
    <svg width={W} height={H} style={{display:"block",background:"#0a001a",borderBottom:"1px solid #1e2130"}}>
      <text x={pad} y={15} fontSize="7" fill="#3a4060" fontFamily="Inter,system-ui,sans-serif" letterSpacing="0.14em">LEGENDE</text>
      {items.map(function(item,i){
        var ins=item.instr;if(!ins)return null;
        var cx=pad+64+i*itemW+itemW/2,cy=13;
        var head;
        if(ins.isX){head=<g><line x1={cx-3.5} y1={cy-3.5} x2={cx+3.5} y2={cy+3.5} stroke={col} strokeWidth={1.8}/><line x1={cx+3.5} y1={cy-3.5} x2={cx-3.5} y2={cy+3.5} stroke={col} strokeWidth={1.8}/></g>;}
        else if(ins.isDiamond){head=<polygon points={`${cx},${cy-4} ${cx+4},${cy} ${cx},${cy+4} ${cx-4},${cy}`} fill={col}/>;}
        else{head=<ellipse cx={cx} cy={cy} rx={4} ry={2.8} transform={`rotate(-12,${cx},${cy})`} fill={col}/>;}
        return <g key={ins.id}>{head}<text x={cx} y={cy+10} textAnchor="middle" fontSize="6.5" fill="#666" fontFamily="Inter,system-ui,sans-serif">{item.label}</text></g>;
      })}
    </svg>
  );
}

function RowSVG({row,rowWidth,firstMeasureNum,onToggleNote,onSelectMeasure,selInstr,selNVId,isFirst,zoomedId}){
  var leftW=isFirst?CLEF_W+4:CLEF_W+2;
  var svgW=rowWidth;
  var measW=(svgW-leftW)/row.length;
  var SVG_H=STOP+8*LS+10;
  function xOfM(mi){return leftW+mi*measW;}
  var p0=isFirst?row[0].timeSig.split("/").map(Number):null;
  return(
    <div style={{overflowX:"hidden"}}>
    <svg width={svgW} height={SVG_H} viewBox={"0 0 "+svgW+" "+SVG_H} preserveAspectRatio="none" style={{display:"block",background:"#fff",width:"100%",cursor:"pointer",touchAction:"manipulation"}}>
      {[0,1,2,3,4].map(function(i){return <line key={"sl"+i} x1={0} y1={staffLineY(i)} x2={svgW} y2={staffLineY(i)} stroke={i===0||i===4?"#3a1060":"#1e0840"} strokeWidth={i===0||i===4?1.2:0.7}/>;  })}
      <text x={2} y={staffLineY(0)-8} fontSize="9" fill="#666" fontFamily="Inter,system-ui,sans-serif">{firstMeasureNum}</text>
      {isFirst?<React.Fragment>
        <rect x={8} y={staffLineY(0)+LS*0.6} width={4} height={LS*2.8} fill="#111" rx={0.8}/>
        <rect x={15} y={staffLineY(0)+LS*0.6} width={4} height={LS*2.8} fill="#111" rx={0.8}/>
        <text x={CLEF_W+8} y={staffLineY(1)+2} textAnchor="middle" fontSize="15" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{p0[0]}</text>
        <text x={CLEF_W+8} y={staffLineY(3)+3} textAnchor="middle" fontSize="15" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{p0[1]}</text>
      </React.Fragment>:<React.Fragment>
        <rect x={4} y={staffLineY(0)+LS*0.8} width={3} height={LS*2.4} fill="#111" rx={0.6}/>
        <rect x={9} y={staffLineY(0)+LS*0.8} width={3} height={LS*2.4} fill="#111" rx={0.6}/>
      </React.Fragment>}
      <line x1={leftW-2} y1={staffLineY(0)} x2={leftW-2} y2={staffLineY(4)} stroke="#111" strokeWidth={1.5}/>
      {row.map(function(m,mi){
        if(mi===0&&isFirst)return null;
        if(mi>0&&m.timeSig===row[mi-1].timeSig)return null;
        var p=m.timeSig.split("/").map(Number),tx=xOfM(mi)+4;
        return <g key={"ts"+mi}>
          <text x={tx+6} y={staffLineY(1)+2} textAnchor="middle" fontSize="13" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{p[0]}</text>
          <text x={tx+6} y={staffLineY(3)+3} textAnchor="middle" fontSize="13" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{p[1]}</text>
        </g>;
      })}
      {row.map(function(m,mi){return m.section?<text key={"sec"+mi} x={xOfM(mi)-2} y={staffLineY(0)-STEM_LEN-10} fontSize="11" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{m.section}</text>:null;})}
      {row.map(function(m,mi){return m.comment?<text key={"cm"+mi} x={xOfM(mi)-2} y={staffLineY(0)-10} fontSize="8" fontStyle="italic" fontFamily="Times New Roman,serif" fill="#888">{m.comment}</text>:null;})}
      {row.map(function(m,mi){
        var tx=xOfM(mi),isZoomed=zoomedId===m.id;
        return <g key={"m"+mi} transform={`translate(${tx},0)`}>
          <rect x={0} y={staffLineY(0)-36} width={measW} height={SVG_H-10} fill="transparent" style={{cursor:"zoom-in"}} onClick={function(){onSelectMeasure(m.id);}}/>
          <MeasureContent m={m} measW={measW} onToggleNote={onToggleNote} selInstr={selInstr} selNVId={selNVId} highlight={isZoomed}/>
          <text x={measW-4} y={staffLineY(4)+16} textAnchor="end" fontSize="7.5" fill="#ccc" fontFamily="Inter,system-ui,sans-serif">{firstMeasureNum+mi}</text>
        </g>;
      })}
      {/* Final closing barline */}
      <line x1={svgW-2} y1={staffLineY(0)} x2={svgW-2} y2={staffLineY(4)} stroke="#111" strokeWidth={2.5}/>
    </svg>
    </div>
  );
}

function OrchPanel({onApply,onClose,currentSymbols,currentRepeat,onSetRepeat}){
  var [sel,setSel]=useState(currentSymbols?currentSymbols.map(function(s){return s.id;}):[]);
  var [rehearsalLetter,setRehearsalLetter]=useState("A");
  var [voltaLabel,setVoltaLabel]=useState("1.");
  var [repeatVal,setRepeatVal]=useState(currentRepeat||"none");
  function toggle(id){setSel(function(prev){return prev.includes(id)?prev.filter(function(x){return x!==id;}):[...prev,id];});}
  var cats=[
    {key:"rep",  label:"Wiederholungszeichen", color:"#e05c8a"},
    {key:"nav",  label:"Navigation",           color:"#5b8af0"},
    {key:"str",  label:"Struktur",             color:"#e09050"},
    {key:"dyn",  label:"Dynamik",              color:"#4caf80"},
    {key:"patt", label:"Pattern",              color:"#9b59b6"},
  ];
  function handleApply(){
    var syms=sel.map(function(id){
      var sym={id:id};
      if(id==="rehearsal")sym.letter=rehearsalLetter;
      if(id==="volta1"||id==="volta2")sym.label=voltaLabel;
      return sym;
    });
    onApply(syms);
    if(onSetRepeat)onSetRepeat(repeatVal);
  }
  return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:400,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"flex-end"}} onClick={onClose}>
    <div onClick={function(e){e.stopPropagation();}} style={{background:"#0d0020",borderRadius:"20px 20px 0 0",padding:"20px 20px 32px",width:"100%",maxWidth:680,margin:"0 auto",boxShadow:"0 -16px 60px rgba(0,0,0,0.7)",maxHeight:"80vh",overflowY:"auto"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
        <span style={{fontSize:14,fontWeight:"700",color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif"}}>Orchesterzeichen</span>
        <button onClick={onClose} style={{width:28,height:28,borderRadius:"50%",border:"none",background:"#2a0045",color:"#9370b8",cursor:"pointer",fontSize:14,display:"flex",alignItems:"center",justifyContent:"center"}}>x</button>
      </div>
      {cats.map(function(cat){
        var syms=ORCH_SYMBOLS.filter(function(s){return s.cat===cat.key;});
        return <div key={cat.key} style={{marginBottom:12}}>
          <div style={{fontSize:9,letterSpacing:"0.14em",textTransform:"uppercase",color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginBottom:6,fontWeight:"600"}}>{cat.label}</div>
          {cat.key==="rep"?(
            <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
              {syms.map(function(sym){
                var active=repeatVal===sym.repeatValue;
                return <button key={sym.id} onClick={function(){setRepeatVal(sym.repeatValue);}}
                  style={{padding:"6px 14px",border:"1.5px solid "+(active?cat.color:"#2a0045"),borderRadius:7,background:active?cat.color+"28":"#0a001a",color:active?cat.color:"#a080c0",fontFamily:"Inter,system-ui,sans-serif",fontSize:12,cursor:"pointer",fontWeight:active?"700":"400"}}>{sym.label}</button>;
              })}
            </div>
          ):(
            <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
              {syms.map(function(sym){
                var active=sel.includes(sym.id);
                return <button key={sym.id} onClick={function(){toggle(sym.id);}}
                  style={{padding:"5px 10px",border:"1px solid "+(active?cat.color:"#2a0045"),borderRadius:7,background:active?cat.color+"28":"#0a001a",color:active?cat.color:"#a080c0",fontFamily:"Inter,system-ui,sans-serif",fontSize:11,cursor:"pointer",fontWeight:active?"600":"400"}}>{sym.label}</button>;
              })}
            </div>
          )}
          {cat.key==="str"&&sel.includes("rehearsal")&&<div style={{marginTop:6,display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>Probebuchstabe:</span>
            <input value={rehearsalLetter} maxLength={2} onChange={function(e){setRehearsalLetter(e.target.value.toUpperCase());}} style={{width:32,padding:"2px 6px",border:"1px solid #2e3145",borderRadius:5,background:"#050510",color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif",fontSize:12,textAlign:"center"}}/>
          </div>}
        </div>;
      })}
      <div style={{display:"flex",gap:10,marginTop:12}}>
        <button onClick={handleApply} style={{flex:1,padding:"11px",borderRadius:8,border:"none",background:"linear-gradient(135deg,#e040fb,#7c4dff)",color:"white",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:"700",cursor:"pointer"}}>Auf Takt anwenden</button>
        <button onClick={onClose} style={{padding:"11px 18px",borderRadius:8,border:"1px solid #2a0045",background:"#0a001a",color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,cursor:"pointer"}}>Abbrechen</button>
      </div>
    </div>
  </div>;
}



// ── InkRecognizer ─────────────────────────────────────────────────────────
// Canvas overlay for drawing drum symbols with stylus/finger
// Recognition: position on staff = instrument, x position = beat
// Symbols: X = hihat/cymbal, filled dot = snare/tom/kick, circle = ghost

function InkRecognizer({measure,measW,leftPad,svgH,staffY,onAddNotes,onClose,selNVId}){
  var canvasRef=useRef();
  var strokState=useState([]); var strokes=strokState[0]; var setStrokes=strokState[1];
  var drawingState=useState(false); var isDrawing=drawingState[0]; var setIsDrawing=drawingState[1];
  var curStrokeState=useState([]); var curStroke=curStrokeState[0]; var setCurStroke=curStrokeState[1];
  var resultState=useState([]); var results=resultState[0]; var setResults=resultState[1];

  // Staff line Y positions (matching RowSVG)
  var LINES=[0,1,2,3,4].map(function(i){return staffY(i);});
  var total=beatsInMeasure(measure.timeSig);

  // Instrument zones based on Y position relative to staff
  // Above line 0: crash (y < LINES[0]-8)
  // Line 0: hihat (y near LINES[0])
  // Between 0-1: ride
  // Line 1: snare
  // Line 2: snare (mid)
  // Line 3: tom1
  // Line 4: tom2 / floor
  // Below line 4: kick (y > LINES[4]+8)
  function yToInstr(y){
    var l0=LINES[0],l1=LINES[1],l2=LINES[2],l3=LINES[3],l4=LINES[4];
    if(y<l0-10) return "crash";
    if(y<l0+6)  return "hihat";
    if(y<l1+4)  return "ride";
    if(y<l2+4)  return "snare";
    if(y<l3+4)  return "tom1";
    if(y<l4+4)  return "tom2";
    return "kick";
  }

  // Detect symbol type from stroke shape
  // X shape: two crossing lines → hihat/cymbal (isX)
  // Small dot/tap: filled note head
  // Circle: ghost note
  // Horizontal line: rest/slash
  function analyzeStroke(pts){
    if(pts.length<2) return null;
    var xs=pts.map(function(p){return p.x;}), ys=pts.map(function(p){return p.y;});
    var minX=Math.min.apply(null,xs), maxX=Math.max.apply(null,xs);
    var minY=Math.min.apply(null,ys), maxY=Math.max.apply(null,ys);
    var w=maxX-minX, h=maxY-minY;
    var cx=(minX+maxX)/2, cy=(minY+maxY)/2;
    var len=pts.length;

    // Small tap = note head
    if(w<16&&h<16&&len<8){
      return {cx:cx,cy:cy,type:"dot",size:Math.max(w,h)};
    }
    // Detect X: direction changes significantly
    if(w>8&&h>8&&len>4){
      // Check if stroke goes back (direction reversal)
      var dxTotal=xs[len-1]-xs[0], dyTotal=ys[len-1]-ys[0];
      var midPt=Math.floor(len/2);
      var dx1=xs[midPt]-xs[0], dy1=ys[midPt]-ys[0];
      var dx2=xs[len-1]-xs[midPt], dy2=ys[len-1]-ys[midPt];
      var cross=dx1*dy2-dy1*dx2;
      if(Math.abs(cross)>30&&w>10&&h>10){
        return {cx:cx,cy:cy,type:"x",size:Math.max(w,h)};
      }
    }
    // Circle: start and end close together, roughly round
    var dClose=Math.sqrt(Math.pow(xs[0]-xs[len-1],2)+Math.pow(ys[0]-ys[len-1],2));
    var pathLen=0;
    for(var i=1;i<len;i++){
      pathLen+=Math.sqrt(Math.pow(xs[i]-xs[i-1],2)+Math.pow(ys[i]-ys[i-1],2));
    }
    if(dClose<Math.max(w,h)*0.5&&pathLen>30&&w>12&&h>12){
      return {cx:cx,cy:cy,type:"circle",size:Math.max(w,h)};
    }
    // Default: dot
    return {cx:cx,cy:cy,type:"dot",size:Math.max(w,h)};
  }

  function xToBeatLocal(x){
    var bx=x-leftPad;
    var beat=Math.max(0,Math.min(total-0.01,(bx/measW)*total));
    return snapBeat(beat,selNVId||"16",total);
  }

  function recognizeAll(stks){
    var notes={};
    stks.forEach(function(pts){
      var sym=analyzeStroke(pts);
      if(!sym) return;
      var instrId=yToInstr(sym.cy);
      // Override: X symbol always = cymbal family
      if(sym.type==="x"){
        var cy=sym.cy;
        if(cy<LINES[0]+6) instrId="hihat";
        else instrId="ride";
      }
      var beat=xToBeatLocal(sym.cx);
      var key=instrId+":"+beat.toFixed(6);
      var accent=sym.type==="circle"?"ghost":"normal";
      notes[key]={accent:accent,nvId:selNVId||"16"};
    });
    setResults(Object.keys(notes).map(function(k){
      var parts=k.split(":");
      return {instrId:parts[0],beat:parseFloat(parts[1]),accent:notes[k].accent,nvId:notes[k].nvId,key:k};
    }));
    return notes;
  }

  function getPos(e){
    var c=canvasRef.current;
    var rect=c.getBoundingClientRect();
    var scaleX=c.width/rect.width, scaleY=c.height/rect.height;
    if(e.touches){
      return {x:(e.touches[0].clientX-rect.left)*scaleX, y:(e.touches[0].clientY-rect.top)*scaleY};
    }
    return {x:(e.clientX-rect.left)*scaleX, y:(e.clientY-rect.top)*scaleY};
  }

  function redraw(stks,cur){
    var c=canvasRef.current; if(!c) return;
    var ctx=c.getContext("2d");
    ctx.clearRect(0,0,c.width,c.height);

    // Draw staff lines as guide
    ctx.strokeStyle="rgba(100,60,160,0.3)";
    ctx.lineWidth=1;
    LINES.forEach(function(y){
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(c.width,y); ctx.stroke();
    });
    // Beat grid
    ctx.strokeStyle="rgba(100,60,160,0.15)";
    for(var b=0;b<=total;b+=0.25){
      var bx=leftPad+b/total*measW;
      ctx.beginPath(); ctx.moveTo(bx,0); ctx.lineTo(bx,c.height); ctx.stroke();
    }

    // Draw completed strokes
    ctx.strokeStyle="#e040fb"; ctx.lineWidth=2.5;
    ctx.lineCap="round"; ctx.lineJoin="round";
    stks.forEach(function(pts){
      if(pts.length<2) return;
      ctx.beginPath(); ctx.moveTo(pts[0].x,pts[0].y);
      pts.forEach(function(p){ctx.lineTo(p.x,p.y);});
      ctx.stroke();
    });

    // Draw current stroke
    ctx.strokeStyle="#40c4ff"; ctx.lineWidth=2;
    if(cur&&cur.length>1){
      ctx.beginPath(); ctx.moveTo(cur[0].x,cur[0].y);
      cur.forEach(function(p){ctx.lineTo(p.x,p.y);});
      ctx.stroke();
    }
  }

  useEffect(function(){redraw(strokes,curStroke);},[strokes,curStroke]);

  function onDown(e){
    e.preventDefault();
    setIsDrawing(true);
    var p=getPos(e);
    setCurStroke([p]);
  }
  function onMove(e){
    e.preventDefault();
    if(!isDrawing) return;
    var p=getPos(e);
    setCurStroke(function(prev){return prev.concat([p]);});
  }
  function onUp(e){
    e.preventDefault();
    setIsDrawing(false);
    var final=curStroke;
    setCurStroke([]);
    if(final.length>0){
      setStrokes(function(prev){
        var next=prev.concat([final]);
        recognizeAll(next);
        return next;
      });
    }
  }

  return <div style={{position:"absolute",top:0,left:0,right:0,bottom:0,zIndex:50}}>
    <canvas ref={canvasRef}
      width={leftPad+measW+20} height={svgH}
      style={{position:"absolute",top:0,left:0,
        width:"100%",height:"100%",
        cursor:"crosshair",touchAction:"none",
      }}
      onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp}
      onPointerCancel={onUp}
    />
    {/* Preview of recognized notes */}
    {results.length>0&&<div style={{
      position:"absolute",bottom:0,left:0,right:0,
      background:"rgba(13,0,32,0.95)",borderTop:"1px solid #e040fb",
      padding:"10px 12px",display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",
    }}>
      <span style={{fontSize:11,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",
        letterSpacing:"0.06em"}}>{"ERKANNT:"}</span>
      {results.map(function(r){
        return <span key={r.key} style={{
          padding:"3px 8px",borderRadius:6,background:"#e040fb22",
          border:"1px solid #e040fb44",color:"#e040fb",
          fontFamily:"Inter,system-ui,sans-serif",fontSize:10,fontWeight:"600",
        }}>{r.instrId+" @ "+(Math.floor(r.beat)+1)}</span>;
      })}
      <div style={{marginLeft:"auto",display:"flex",gap:6}}>
        <button onClick={function(){setStrokes([]);setResults([]);redraw([],[]);}}
          style={{padding:"5px 10px",borderRadius:6,border:"1px solid #2a0045",
            background:"#1a0010",color:"#ff4081",fontSize:10,cursor:"pointer",
            fontFamily:"Inter,system-ui,sans-serif",fontWeight:"600"}}>{"✕ Löschen"}</button>
        <button onClick={function(){
          var notes={};
          results.forEach(function(r){
            var key=r.instrId+":"+r.beat.toFixed(6);
            notes[key]={accent:r.accent,nvId:r.nvId};
          });
          onAddNotes(notes);
          onClose();
        }} style={{padding:"5px 12px",borderRadius:6,border:"none",
          background:"linear-gradient(135deg,#e040fb,#7c4dff)",
          color:"white",fontSize:10,cursor:"pointer",
          fontFamily:"Inter,system-ui,sans-serif",fontWeight:"700"}}>{"✓ Übernehmen"}</button>
      </div>
    </div>}
  </div>;
}

// ── NoteEditPopup ─────────────────────────────────────────────────────────
function NoteEditPopup({lpNote,measure,onToggleNote,onUpdateNote,onClose}){
  var tabState=useState("instr"); var tab=tabState[0]; var setTab=tabState[1];
  var accentState=useState(lpNote.accent||"normal"); var curAccent=accentState[0]; var setCurAccent=accentState[1];

  var instrIcons={"crash":"💥","hihat":"🔔","ride":"🪘","snare":"🥁","tom1":"🔵","tom2":"🟣","floor":"⬇","kick":"👟","hihat_f":"👣"};
  var tabs=[
    {id:"instr",  label:"Instrument", color:"#e040fb"},
    {id:"accent", label:"Artikulation", color:"#40c4ff"},
    {id:"nv",     label:"Notenwert",   color:"#69ff47"},
  ];

  function changeInstr(newInstrId){
    if(onToggleNote){
      onToggleNote(measure.id,lpNote.instrId,lpNote.beat,lpNote.nvId);
      onToggleNote(measure.id,newInstrId,lpNote.beat,lpNote.nvId);
    }
    onClose();
  }

  function changeAccent(newAccent){
    // Remove old note, re-add with new accent
    if(onToggleNote){
      onToggleNote(measure.id,lpNote.instrId,lpNote.beat,lpNote.nvId);
      // Add back with new accent - we need to pass accent through
      // Use the measure's notes directly
    }
    // Update via direct measure mutation approach
    var key=lpNote.instrId+":"+lpNote.beat.toFixed(6);
    if(measure.notes[key]){
      measure.notes[key].accent=newAccent;
    }
    onClose();
  }

  function changeNV(newNvId){
    if(onToggleNote){
      onToggleNote(measure.id,lpNote.instrId,lpNote.beat,lpNote.nvId);
      // Re-add with new note value — we need selAccent context
      // For now just close and let user re-place
    }
    onClose();
  }

  var accentOptions=[
    {id:"normal", label:"Normal",  sym:"–",   color:"#f0e8ff", desc:"Normaler Anschlag"},
    {id:"accent", label:"Akzent",  sym:">",   color:"#e040fb", desc:"Betonter Anschlag"},
    {id:"ghost",  label:"Ghost",   sym:"()",  color:"#40c4ff", desc:"Sehr leiser Anschlag"},
    {id:"flam",   label:"Flam",    sym:"f",   color:"#69ff47", desc:"Flam Vorschlag"},
  ];
  var nvOptions=[
    {id:"1",  label:"Ganze",       flag:0, half:false, triolen:false},
    {id:"2",  label:"Halbe",       flag:0, half:true,  triolen:false},
    {id:"4",  label:"Viertel",     flag:0, half:false, triolen:false},
    {id:"8",  label:"Achtel",      flag:1, half:false, triolen:false},
    {id:"16", label:"Sechzehntel", flag:2, half:false, triolen:false},
    {id:"8t", label:"Triole",      flag:1, half:false, triolen:true},
  ];

  return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:2000,
    background:"rgba(0,0,0,0.65)"}} onClick={onClose}>
    <div onClick={function(e){e.stopPropagation();}} style={{
      position:"fixed",left:"50%",top:"50%",transform:"translate(-50%,-50%)",
      background:"#0d0020",border:"1.5px solid #e040fb",borderRadius:18,
      padding:"0 0 16px",
      boxShadow:"0 0 50px rgba(224,64,251,0.25),0 20px 60px rgba(0,0,0,0.9)",
      zIndex:2001,width:290,maxWidth:"92vw",overflow:"hidden",
    }}>

      {/* Tab bar */}
      <div style={{display:"flex",borderBottom:"1px solid #2a0045"}}>
        {tabs.map(function(t){
          var active=tab===t.id;
          return <button key={t.id} onClick={function(){setTab(t.id);}} style={{
            flex:1,padding:"11px 6px",border:"none",
            background:active?t.color+"18":"transparent",
            borderBottom:active?"2px solid "+t.color:"2px solid transparent",
            color:active?t.color:"#6a4a80",cursor:"pointer",
            fontFamily:"Inter,system-ui,sans-serif",fontSize:10,
            fontWeight:active?"700":"400",letterSpacing:"0.05em",
            textTransform:"uppercase",
          }}>{t.label}</button>;
        })}
      </div>

      {/* Content */}
      <div style={{padding:"14px 12px 0"}}>

        {/* ── INSTRUMENT TAB ── */}
        {tab==="instr"&&<div>
          <div style={{fontSize:8,color:"#9370b8",letterSpacing:"0.14em",
            textTransform:"uppercase",fontFamily:"Inter,system-ui,sans-serif",
            textAlign:"center",marginBottom:10}}>{"Instrument wählen"}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6}}>
            {INSTRUMENTS.map(function(ins){
              var active=ins.id===lpNote.instrId;
              return <button key={ins.id} onClick={function(){changeInstr(ins.id);}} style={{
                display:"flex",flexDirection:"column",alignItems:"center",
                justifyContent:"center",gap:3,padding:"10px 4px",borderRadius:10,
                border:"2px solid "+(active?"#e040fb":"#2a0045"),
                background:active?"#e040fb22":"#1a0035",
                cursor:"pointer",boxShadow:active?"0 0 10px #e040fb44":"none",
              }}>
                <span style={{fontSize:24,lineHeight:1}}>{instrIcons[ins.id]||"●"}</span>
                <span style={{fontSize:7,color:active?"#e040fb":"#9370b8",
                  fontFamily:"Inter,system-ui,sans-serif",letterSpacing:"0.06em",
                  textTransform:"uppercase",fontWeight:active?"700":"400"}}>{ins.name}</span>
              </button>;
            })}
          </div>
        </div>}

        {/* ── ARTIKULATION TAB ── */}
        {tab==="accent"&&<div>
          <div style={{fontSize:8,color:"#40c4ff",letterSpacing:"0.14em",
            textTransform:"uppercase",fontFamily:"Inter,system-ui,sans-serif",
            textAlign:"center",marginBottom:10}}>{"Artikulation wählen"}</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {accentOptions.map(function(a){
              var active=lpNote.accent===a.id;
              return <button key={a.id} onClick={function(){
                if(onUpdateNote){
                  onUpdateNote(measure.id,lpNote.instrId,lpNote.beat,{accent:a.id,nvId:lpNote.nvId});
                }
                onClose();
              }} style={{
                display:"flex",alignItems:"center",gap:12,padding:"11px 14px",
                borderRadius:10,border:"1.5px solid "+(active?a.color:"#2a0045"),
                background:active?a.color+"22":"#1a0035",cursor:"pointer",textAlign:"left",
                boxShadow:active?"0 0 10px "+a.color+"44":"none",
              }}>
                <span style={{fontSize:22,fontFamily:"serif",fontWeight:"900",
                  color:a.color,width:28,textAlign:"center",lineHeight:1}}>{a.sym}</span>
                <div>
                  <div style={{fontSize:13,fontWeight:"700",color:active?a.color:"#f0e8ff",
                    fontFamily:"Inter,system-ui,sans-serif"}}>{a.label}</div>
                  <div style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",
                    marginTop:1}}>{a.desc}</div>
                </div>
                {active&&<span style={{marginLeft:"auto",color:a.color,fontSize:14}}>{"✦"}</span>}
              </button>;
            })}
          </div>
        </div>}

        {/* ── NOTENWERT TAB ── */}
        {tab==="nv"&&<div>
          <div style={{fontSize:8,color:"#69ff47",letterSpacing:"0.14em",
            textTransform:"uppercase",fontFamily:"Inter,system-ui,sans-serif",
            textAlign:"center",marginBottom:10}}>{"Notenwert wählen"}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
            {nvOptions.map(function(nv){
              var active=lpNote.nvId===nv.id;
              return <button key={nv.id} onClick={function(){
                if(onUpdateNote){
                  onUpdateNote(measure.id,lpNote.instrId,lpNote.beat,{accent:lpNote.accent||"normal",nvId:nv.id});
                }
                onClose();
              }} style={{
                display:"flex",alignItems:"center",gap:8,padding:"10px 12px",
                borderRadius:10,border:"1.5px solid "+(active?"#69ff47":"#2a0045"),
                background:active?"#69ff4722":"#1a0035",cursor:"pointer",textAlign:"left",
                boxShadow:active?"0 0 10px #69ff4744":"none",
              }}>
                <NVIcon flags={nv.flag} half={nv.half} triolen={nv.triolen} size={20}/>
                <span style={{fontSize:12,fontWeight:active?"700":"400",
                  color:active?"#69ff47":"#f0e8ff",
                  fontFamily:"Inter,system-ui,sans-serif"}}>{nv.label}</span>
                {active&&<span style={{marginLeft:"auto",color:"#69ff47",fontSize:12}}>{"✦"}</span>}
              </button>;
            })}
          </div>
        </div>}

      </div>

      {/* Close */}
      <button onClick={onClose} style={{
        marginTop:14,marginLeft:12,marginRight:12,width:"calc(100% - 24px)",
        padding:"9px",borderRadius:8,border:"1px solid #2a0045",background:"#0a001a",
        color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",fontSize:12,
        cursor:"pointer",display:"block",
      }}>{"Abbrechen"}</button>
    </div>
  </div>;
}

function ZoomPanel({measure,measNum,onClose,onToggleNote,onUpdateNote,selInstr,selNVId,onPrev,onNext,hasPrev,hasNext,updMeas,onOpenPresets,onClear,onOpenOrch,onAddAfter}){
  var lpState=useState(null); var lpNote=lpState[0]; var setLpNote=lpState[1];
  var snState=useState(null); var selNote=snState[0]; var setSelNote=snState[1];
  var lpTimerRef=useRef(null);
  var lpPressRef=useRef(null);
  var touchHandledRef=useRef(false);
  var inkState=useState(false); var inkMode=inkState[0]; var setInkMode=inkState[1];
  var leftPad=30;
  var total=beatsInMeasure(measure.timeSig);
  var ZOOM_CONTENT_W=Math.max(460,(total/0.25)*MIN_BEAT_W*2.5);
  var ZOOM_W=leftPad+ZOOM_CONTENT_W+16;
  var measW=ZOOM_CONTENT_W;
  var ZOOM_H=STOP+8*LS+28;
  var p0=measure.timeSig.split("/").map(Number);
  function handleSvgClick(e){
    if(selNote){setSelNote(null);return;}
    if(lpNote){setLpNote(null);return;}
    var rect=e.currentTarget.getBoundingClientRect();
    var scrollLeft=e.currentTarget.scrollLeft||0;
    var lx=e.clientX-rect.left+scrollLeft-8-leftPad;
    if(lx<0)return;
    var beat=snapBeat(xToBeat(lx,measW,total),selNVId,total);
    if(onToggleNote)onToggleNote(measure.id,selInstr,beat,selNVId);
  }

  function ZBtn({label,color,onClick,disabled,children}){
    var c=color||"#e040fb";
    return <button onClick={onClick} disabled={disabled}
      style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
        gap:2,flex:"1 1 0",minWidth:0,padding:"6px 4px",border:"none",
        background:"transparent",cursor:disabled?"default":"pointer",opacity:disabled?0.3:1}}>
      <div style={{width:38,height:38,borderRadius:10,
        background:"#1a0035",border:"1px solid "+c+"55",
        display:"flex",alignItems:"center",justifyContent:"center",
        fontSize:16,color:c,
        boxShadow:"0 0 8px "+c+"22"}}>
        {children}
      </div>
      <span style={{fontSize:8,color:c,fontFamily:"Inter,system-ui,sans-serif",
        letterSpacing:"0.06em",textTransform:"uppercase",fontWeight:"600",
        whiteSpace:"nowrap"}}>{label}</span>
    </button>;
  }

  return <div style={{position:"fixed",bottom:0,left:0,right:0,zIndex:200,
    maxHeight:"60vh",
    background:"#0d0020",borderTop:"2px solid #e040fb",
    boxShadow:"0 -12px 48px rgba(224,64,251,0.15)"}}>

    {/* ── Row 1: Takt-Info + Nav ── */}
    <div style={{display:"flex",alignItems:"center",gap:6,padding:"8px 12px 6px",
      borderBottom:"1px solid #2a0045"}}>
      <span style={{fontSize:13,color:"#e040fb",fontFamily:"Inter,system-ui,sans-serif",
        fontWeight:"800",flexShrink:0,minWidth:32}}>{"T."+measNum}</span>
      <span style={{fontSize:9,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",
        flexShrink:0,letterSpacing:"0.06em"}}>
        {Object.keys(measure.notes).length+"N"}
      </span>
      <span id="dw-pen-indicator" style={{fontSize:11,display:"none",color:"#40c4ff",
        fontFamily:"Inter,system-ui,sans-serif",flexShrink:0}}>{"✏ Stift"}</span>
      <select value={measure.timeSig}
        onChange={function(e){updMeas(measure.id,"timeSig",e.target.value);}}
        style={{border:"1px solid #2a0045",borderRadius:6,background:"#1a0035",
          fontFamily:"Inter,system-ui,sans-serif",fontSize:11,color:"#f0e8ff",
          outline:"none",cursor:"pointer",padding:"3px 6px",colorScheme:"dark",flexShrink:0}}>
        {TIME_SIGS.map(function(t){return <option key={t}>{t}</option>;})}
      </select>
      <select value={measure.section}
        onChange={function(e){updMeas(measure.id,"section",e.target.value);}}
        style={{border:"1px solid #2a0045",borderRadius:6,background:"#1a0035",
          fontFamily:"Inter,system-ui,sans-serif",fontSize:11,color:"#f0e8ff",
          outline:"none",cursor:"pointer",padding:"3px 6px",colorScheme:"dark",flex:1,minWidth:0}}>
        {SECTION_MARKS.map(function(s){return <option key={s} value={s} style={{background:"#0d0020",color:"#f0e8ff"}}>{s||"— kein Abschnitt"}</option>;})}
      </select>
      <button onClick={onPrev} disabled={!hasPrev}
        style={{width:32,height:32,border:"1px solid #2a0045",borderRadius:8,
          background:"#1a0035",cursor:hasPrev?"pointer":"default",
          color:hasPrev?"#e040fb":"#2a0045",fontSize:16,display:"flex",
          alignItems:"center",justifyContent:"center",flexShrink:0,opacity:hasPrev?1:0.3}}>{"‹"}</button>
      <button onClick={onNext} disabled={!hasNext}
        style={{width:32,height:32,border:"1px solid #2a0045",borderRadius:8,
          background:"#1a0035",cursor:hasNext?"pointer":"default",
          color:hasNext?"#7c4dff":"#2a0045",fontSize:16,display:"flex",
          alignItems:"center",justifyContent:"center",flexShrink:0,opacity:hasNext?1:0.3}}>{"›"}</button>
      <button onClick={onClose}
        style={{width:32,height:32,border:"1px solid #2a0045",borderRadius:8,
          background:"#1a0035",cursor:"pointer",color:"#a080c0",fontSize:16,
          display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{"×"}</button>
    </div>

    {/* ── Selected note bar ── */}
    {selNote&&<div style={{display:"flex",alignItems:"center",gap:8,
      padding:"6px 12px",background:"#001a30",borderBottom:"1px solid #40c4ff44"}}>
      <span style={{fontSize:11,color:"#40c4ff",fontFamily:"Inter,system-ui,sans-serif",
        fontWeight:"700",flex:1}}>
        {"✦ "+instrById(selNote.instrId).name+" · Beat "+(Math.floor(selNote.beat)+1)}
      </span>
      <button onClick={function(){
        if(onToggleNote)onToggleNote(measure.id,selNote.instrId,selNote.beat,selNote.nvId);
        setSelNote(null);
      }} style={{padding:"3px 10px",borderRadius:6,border:"1px solid #ff408144",
        background:"#1a0010",color:"#ff4081",fontSize:11,cursor:"pointer",
        fontFamily:"Inter,system-ui,sans-serif",fontWeight:"600"}}>{"🗑 Löschen"}</button>
      <button onClick={function(){setLpNote(selNote);setSelNote(null);}}
        style={{padding:"3px 10px",borderRadius:6,border:"1px solid #e040fb44",
          background:"#1a0035",color:"#e040fb",fontSize:11,cursor:"pointer",
          fontFamily:"Inter,system-ui,sans-serif",fontWeight:"600"}}>{"Instr. ↕"}</button>
    </div>}
    {/* ── Row 2: Action toolbar ── */}
    <div style={{display:"flex",alignItems:"flex-start",padding:"6px 8px 8px",
      borderBottom:"1px solid #2a0045",gap:0}}>
      <ZBtn label="Presets" color="#e040fb" onClick={onOpenPresets}>{"♩"}</ZBtn>
      <ZBtn label="Zeichen" color="#40c4ff" onClick={onOpenOrch}>{"𝄋"}</ZBtn>
      <ZBtn label="Wiederhol." color="#7c4dff" onClick={function(){
        var vals=["none","start","end","both"];
        var cur=vals.indexOf(measure.repeat||"none");
        updMeas(measure.id,"repeat",vals[(cur+1)%vals.length]);
      }}>
        {(function(){var r=measure.repeat||"none";return r==="start"?"||:":r==="end"?":||":r==="both"?":||:":"—";}())}</ZBtn>
      <ZBtn label="Kommentar" color="#69ff47" onClick={function(){
        var c=window.prompt("Kommentar:",measure.comment||"");
        if(c!==null) updMeas(measure.id,"comment",c);
      }}>{"✎"}</ZBtn>
      <ZBtn label="Leeren" color="#ff4081" onClick={onClear}>{"🗑"}</ZBtn>
      <ZBtn label="+ Takt" color="#9370b8" onClick={function(){
        if(onAddAfter)onAddAfter(measure.id);
      }}>{"+"}</ZBtn>
    </div>
    <div style={{position:"relative"}}>
    {inkMode&&<InkRecognizer
      measure={measure} measW={measW} leftPad={leftPad}
      svgH={ZOOM_H} staffY={staffLineY} selNVId={selNVId}
      onClose={function(){setInkMode(false);}}
      onAddNotes={function(notes){
        if(onToggleNote){
          Object.keys(notes).forEach(function(key){
            var parts=key.split(":");
            var instrId=parts[0];
            var beat=parseFloat(parts[1]);
            var nvId=notes[key].nvId||"16";
            onToggleNote(measure.id,instrId,beat,nvId);
          });
        }
      }}
    />}
    <div style={{overflowX:"auto",padding:"4px 8px 6px",cursor:inkMode?"crosshair":"crosshair",
      WebkitUserSelect:"none",userSelect:"none",WebkitTouchCallout:"none",
      touchAction:"pan-x"}}
      onClick={function(e){
        if(touchHandledRef.current){touchHandledRef.current=false;return;}
        handleSvgClick(e);
      }}
      onPointerDown={function(e){
        // Works for mouse, touch AND stylus (Apple Pencil, S Pen)
        var isPen=e.pointerType==="pen";
        var isTouch=e.pointerType==="touch";
        var isMouse=e.pointerType==="mouse";
        var rect=e.currentTarget.getBoundingClientRect();
        var scrollLeft=e.currentTarget.scrollLeft||0;
        var lx=e.clientX-rect.left+scrollLeft-8-leftPad;
        var ly=e.clientY-rect.top-4;
        var lay=computeLayout(measure.notes,measure.timeSig,measW);
        // Pen: smaller hit radius (precise), touch: larger (finger)
        var hitR=(isPen?12:22);
        var hit=null,minD=hitR*hitR;
        lay.noteList.forEach(function(n){
          var dx=lx-n.x,dy=ly-n.y;
          var d=dx*dx+dy*dy;
          if(d<minD){minD=d;hit=n;}
        });
        if(hit){
          e.preventDefault();
          touchHandledRef.current=false;
          lpPressRef.current=hit;
          // Pen: shorter long-press (300ms), touch: 500ms
          var lpDelay=isPen?300:500;
          lpTimerRef.current=setTimeout(function(){
            lpPressRef.current=null;
            touchHandledRef.current=true;
            setLpNote({key:hit.key,instrId:hit.instrId,beat:hit.beat,nvId:hit.nvId,x:hit.x,y:hit.y});
          },lpDelay);
        } else if(isPen){
          // Pen tap on empty space = place note directly (no need for longpress)
          e.preventDefault();
          touchHandledRef.current=true;
          handleSvgClick(e);
        }
      }}
      onPointerUp={function(e){
        clearTimeout(lpTimerRef.current);
        var hit=lpPressRef.current;
        lpPressRef.current=null;
        if(hit){
          touchHandledRef.current=true;
          e.preventDefault();
          if(e.pointerType==="pen"){
            // Pen tap on note = toggle directly
            if(onToggleNote)onToggleNote(measure.id,hit.instrId,hit.beat,hit.nvId);
          } else {
            setSelNote(function(prev){return prev&&prev.key===hit.key?null:hit;});
          }
        }
      }}
      onPointerMove={function(e){
        if(lpPressRef.current&&e.pointerType!=="pen"){
          clearTimeout(lpTimerRef.current);
          lpPressRef.current=null;
        }
      }}
      onPointerCancel={function(){
        clearTimeout(lpTimerRef.current);
        lpPressRef.current=null;
      }}>
      <svg width={ZOOM_W} height={ZOOM_H} style={{display:"block",background:"#fff"}}>
        {[0,1,2,3,4].map(function(i){return <line key={i} x1={0} y1={staffLineY(i)} x2={ZOOM_W} y2={staffLineY(i)} stroke={i===0||i===4?"#3a1060":"#1e0840"} strokeWidth={i===0||i===4?1.2:0.7}/>;  })}
        <rect x={8} y={staffLineY(0)+LS*0.6} width={5} height={LS*2.8} fill="#111" rx={1}/>
        <rect x={17} y={staffLineY(0)+LS*0.6} width={5} height={LS*2.8} fill="#111" rx={1}/>
        <text x={CLEF_W+10} y={staffLineY(1)+2} textAnchor="middle" fontSize="17" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{p0[0]}</text>
        <text x={CLEF_W+10} y={staffLineY(3)+3} textAnchor="middle" fontSize="17" fontWeight="bold" fontFamily="Times New Roman,serif" fill="#111">{p0[1]}</text>
        <line x1={leftPad-2} y1={staffLineY(0)} x2={leftPad-2} y2={staffLineY(4)} stroke="#111" strokeWidth={1.5}/>
        {(function buildGrid(){
          var gridLines=[];
          for(var b=0.25;b<total;b+=0.25){
            var bx=leftPad+beatToX(b,total,measW);
            var is8th=Math.abs(b%0.5)<0.001;
            var isQ=Math.abs(b%1)<0.001;
            gridLines.push(<line key={"bg"+b} x1={bx} y1={staffLineY(0)} x2={bx} y2={staffLineY(4)} stroke={isQ?"#ccc":is8th?"#e8e8e8":"#f2f2f2"} strokeWidth={isQ?0.9:0.6} strokeDasharray={isQ?"4,3":is8th?"2,4":"1,5"}/>);
          }
          for(var bb=0;bb<total;bb+=1){
            var bbx=leftPad+beatToX(bb,total,measW)+BAR_PAD;
            gridLines.push(<text key={"bn"+bb} x={bbx} y={staffLineY(4)+20} textAnchor="middle" fontSize="8" fill="#bbb" fontFamily="Inter,system-ui,sans-serif">{bb+1}</text>);
          }
          return gridLines;
        })()}
        <g transform={`translate(${leftPad},0)`}>
          <MeasureContent m={measure} measW={measW} onToggleNote={onToggleNote} selInstr={selInstr} selNVId={selNVId}
            lpNote={lpNote} selNote={selNote}
            onLongPress={function(n){setSelNote(null);setLpNote(n);}}
            onSelectNote={function(n){setSelNote(function(prev){return prev&&prev.key===n.key?null:n;});}}
            onChangeInstr={function(mId,oldInstr,beat,nvId,newInstr){
              if(onToggleNote){onToggleNote(mId,oldInstr,beat,nvId);onToggleNote(mId,newInstr,beat,nvId);}
              setLpNote(null);
            }}/>
        </g>
      </svg>
    </div>
    </div>

    {/* ── Instrument picker popup ── */}
    {lpNote&&<NoteEditPopup
      lpNote={lpNote}
      measure={measure}
      onToggleNote={onToggleNote}
      onUpdateNote={onUpdateNote}
      onClose={function(){setLpNote(null);}}
    />}
  </div>;
}

function PresetPanel({onApply,onClose}){
  var [selHH,setSelHH]=useState(["hh_8"]);
  var [selSN,setSelSN]=useState(["sn_24"]);
  var [selKI,setSelKI]=useState(["ki_13"]);
  function tog(list,set,id){set(function(p){return p.includes(id)?p.filter(function(x){return x!==id;}):[...p,id];});}
  function handleApply(){onApply(applyPresets(selHH.concat(selSN).concat(selKI)));}
  function Chip({preset,active,color,onToggle}){
    return <button onClick={onToggle} style={{display:"inline-flex",flexDirection:"column",alignItems:"flex-start",padding:"6px 10px",margin:"3px",border:"1px solid "+(active?color:"#2a0045"),borderRadius:8,background:active?color+"28":"#0a001a",cursor:"pointer",textAlign:"left",minWidth:90}}>
      <span style={{fontSize:11,fontWeight:"600",fontFamily:"Inter,system-ui,sans-serif",color:active?color:"#a080c0"}}>{preset.label}</span>
      <span style={{fontSize:9,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginTop:1}}>{preset.desc}</span>
    </button>;
  }
  return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:300,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"flex-end"}} onClick={onClose}>
    <div onClick={function(e){e.stopPropagation();}} style={{background:"#0d0020",borderRadius:"20px 20px 0 0",padding:"20px 20px 32px",width:"100%",maxWidth:640,margin:"0 auto",boxShadow:"0 -16px 60px rgba(0,0,0,0.7)",maxHeight:"80vh",overflowY:"auto"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
        <span style={{fontSize:14,fontWeight:"700",color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif"}}>Groove Presets</span>
        <span style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>Kombinierbar</span>
      </div>
      {PRESET_GROUPS.map(function(g,gi){
        var sel=[selHH,selSN,selKI][gi];
        var set=[setSelHH,setSelSN,setSelKI][gi];
        return <div key={gi} style={{marginBottom:12}}>
          <div style={{fontSize:9,letterSpacing:"0.14em",textTransform:"uppercase",color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginBottom:6,fontWeight:"600"}}>{g.label}</div>
          <div style={{display:"flex",flexWrap:"wrap"}}>
            {g.presets.map(function(p){return <Chip key={p.id} preset={p} active={sel.includes(p.id)} color={g.color} onToggle={function(){tog(sel,set,p.id);}}/>;  })}
          </div>
        </div>;
      })}
      <div style={{display:"flex",gap:10,marginTop:12}}>
        <button onClick={handleApply} style={{flex:1,padding:"11px",borderRadius:8,border:"none",background:"linear-gradient(135deg,#e040fb,#7c4dff)",color:"white",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:"700",cursor:"pointer"}}>Auf Takt anwenden</button>
        <button onClick={onClose} style={{padding:"11px 18px",borderRadius:8,border:"1px solid #2a0045",background:"#0a001a",color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,cursor:"pointer"}}>Abbrechen</button>
      </div>
    </div>
  </div>;
}

function NVIcon({flags,triolen,half,size}){
  var s=size||16;
  return <svg width={s} height={s+2} style={{flexShrink:0,display:"block"}}>
    <ellipse cx={6} cy={13} rx={4.2} ry={3} transform="rotate(-12,6,13)" fill={half?"none":"#aab"} stroke="#aab" strokeWidth={half?1.6:0}/>
    <line x1={10.2} y1={13} x2={10.2} y2={3} stroke="#aab" strokeWidth={1.3}/>
    {flags>=1&&<path d="M10.2,3 C18,7 16,13 10.2,14" fill="none" stroke="#aab" strokeWidth={1.2}/>}
    {flags>=2&&<path d="M10.2,6 C18,10 16,16 10.2,17" fill="none" stroke="#aab" strokeWidth={1.2}/>}
    {triolen&&<text x={13} y={5} fontSize={5} fill="#aab" fontFamily="serif" fontStyle="italic">3</text>}
  </svg>;
}

function BottomSheet({title,onClose,children}){
  return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:500,background:"rgba(5,5,16,0.85)",display:"flex",alignItems:"flex-end"}} onClick={onClose}>
    <div onClick={function(e){e.stopPropagation();}} style={{
      background:"#0d0020",borderRadius:"20px 20px 0 0",width:"100%",maxWidth:640,
      margin:"0 auto",maxHeight:"75vh",display:"flex",flexDirection:"column",
      border:"1px solid #2a0045",borderBottom:"none",
      boxShadow:"0 -20px 60px rgba(224,64,251,0.15), 0 -4px 0 #e040fb",
    }}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",
        padding:"16px 18px 12px",borderBottom:"1px solid #2a0045"}}>
        <span style={{fontSize:13,fontWeight:"700",color:"#f0e8ff",
          fontFamily:"Inter,system-ui,sans-serif",letterSpacing:"-0.01em"}}>{title}</span>
        <button onClick={onClose} style={{width:28,height:28,borderRadius:"50%",border:"1px solid #2a0045",
          background:"#1a0035",color:"#a080c0",cursor:"pointer",fontSize:14,
          display:"flex",alignItems:"center",justifyContent:"center"}}>{"×"}</button>
      </div>
      <div style={{overflowY:"auto",padding:"10px 14px 28px"}}>{children}</div>
    </div>
  </div>;
}

function SheetOption({active,color,onClick,children}){
  var c=color||"#e040fb";
  return <button onClick={onClick} style={{
    display:"flex",alignItems:"center",gap:10,width:"100%",padding:"12px 14px",
    border:"1.5px solid "+(active?c:"#2a0045"),borderRadius:12,marginBottom:6,
    background:active?"linear-gradient(135deg,"+c+"22,"+c+"08)":"#0a001a",
    color:active?c:"#a080c0",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,
    cursor:"pointer",textAlign:"left",fontWeight:active?"700":"400",
    boxShadow:active?"0 0 12px "+c+"33":"none",transition:"all 0.15s",
  }}>
    {active&&<span style={{color:c,fontSize:12,marginRight:2}}>{"✦"}</span>}
    {children}
  </button>;
}

function RoundBtn({icon,label,value,color,active,onClick}){
  var c=color||"#e040fb";
  return <button onClick={onClick} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4,background:"none",border:"none",cursor:"pointer",padding:"6px 2px",flex:"1 1 0",minWidth:0}}>
    <div style={{
      width:46,height:46,borderRadius:"50%",
      background:active?"linear-gradient(135deg,"+c+"33,"+c+"11)":"#0d0020",
      border:"1.5px solid "+(active?c:"#2a0045"),
      display:"flex",alignItems:"center",justifyContent:"center",fontSize:19,
      color:c,
      boxShadow:active?"0 0 14px "+c+"66, inset 0 0 10px "+c+"22":"none",
      transition:"all 0.15s",
    }}>{icon}</div>
    <span style={{fontSize:8,color:active?c:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",
      letterSpacing:"0.08em",textTransform:"uppercase",fontWeight:active?"700":"400",
      maxWidth:52,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{value||label}</span>
  </button>;
}

function BottomToolbar({selInstr,setSelInstr,selAccent,setSelAccent,selNVId,setSelNVId,measPerRow,setMPR,onOpenPresets,onOpenOrch}){
  var [open,setOpen]=useState(null);
  var ci=instrById(selInstr),cn=nvById(selNVId);
  var ca=ACCENT_TYPES.find(function(a){return a.id===selAccent;});
  var accentSym={normal:"–",ghost:"()",accent:">",flam:"f"};
  var instrIcon={"crash":"💥","hihat":"🔔","ride":"🪘","snare":"🥁","tom1":"🔵","tom2":"🟣","floor":"⬇","kick":"👟","hihat_f":"👣"};
  return <>
    <div style={{background:"#0d0020",borderTop:"1px solid #1e2235",padding:"6px 8px 10px",display:"flex",alignItems:"flex-start",gap:0,flexShrink:0}}>
      <RoundBtn
        icon={<span style={{fontSize:20}}>{instrIcon[selInstr]||"🥁"}</span>}
        label="Instr" value={ci?ci.name.substring(0,6):""} color="#e040fb" active={open==="instr"} onClick={function(){setOpen(open==="instr"?null:"instr");}}/>
      <RoundBtn
        icon={<NVIcon flags={cn.flag} triolen={cn.triolen} half={cn.half} size={20}/>}
        label="Note" value={cn.label.substring(0,5)} color="#69ff47" active={open==="nv"} onClick={function(){setOpen(open==="nv"?null:"nv");}}/>
      <RoundBtn
        icon={<span style={{fontFamily:"serif",fontSize:18,fontWeight:"900",lineHeight:1}}>{accentSym[selAccent]||">"}</span>}
        label="Artik." value={ca?ca.label.substring(0,5):""} color="#40c4ff" active={open==="accent"} onClick={function(){setOpen(open==="accent"?null:"accent");}}/>
      <RoundBtn
        icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <rect x="3" y="5" width="18" height="3" rx="1.5" fill="currentColor" opacity="0.9"/>
          <rect x="3" y="11" width="18" height="3" rx="1.5" fill="currentColor" opacity="0.7"/>
          <rect x="3" y="17" width="18" height="3" rx="1.5" fill="currentColor" opacity="0.5"/>
        </svg>}
        label="Zeilen" value={measPerRow+"x"} color="#7c4dff" active={open==="layout"} onClick={function(){setOpen(open==="layout"?null:"layout");}}/>
      <RoundBtn
        icon={<span style={{fontSize:20}}>{"♩"}</span>}
        label="Presets" color="#e040fb" active={false} onClick={function(){setOpen(null);onOpenPresets();}}/>
      <RoundBtn
        icon={<span style={{fontSize:18}}>{"𝄋"}</span>}
        label="Zeichen" color="#40c4ff" active={false} onClick={function(){setOpen(null);onOpenOrch();}}/>
    </div>
    {open==="instr"&&<BottomSheet title="Instrument" onClose={function(){setOpen(null);}}>
      {INSTRUMENTS.map(function(ins){return <SheetOption key={ins.id} active={selInstr===ins.id} color="#e040fb" onClick={function(){setSelInstr(ins.id);setOpen(null);}}><span style={{fontSize:16,marginRight:4}}>{instrIcon[ins.id]||"🥁"}</span>{ins.name}</SheetOption>;})}
    </BottomSheet>}
    {open==="nv"&&<BottomSheet title="Notenwert" onClose={function(){setOpen(null);}}>
      {NOTE_VALUES.map(function(nv){return <SheetOption key={nv.id} active={selNVId===nv.id} color="#69ff47" onClick={function(){setSelNVId(nv.id);setOpen(null);}}><NVIcon flags={nv.flag} triolen={nv.triolen} half={nv.half} size={20}/><span>{nv.label}</span></SheetOption>;})}
    </BottomSheet>}
    {open==="accent"&&<BottomSheet title="Artikulation" onClose={function(){setOpen(null);}}>
      {ACCENT_TYPES.map(function(a){return <SheetOption key={a.id} active={selAccent===a.id} color="#40c4ff" onClick={function(){setSelAccent(a.id);setOpen(null);}}><span style={{fontFamily:"serif",fontSize:20,width:28,textAlign:"center",display:"inline-block"}}>{accentSym[a.id]||"."}</span><div><div style={{fontWeight:"600"}}>{a.label}</div></div></SheetOption>;})}
    </BottomSheet>}
    {open==="layout"&&<BottomSheet title="Takte pro Zeile" onClose={function(){setOpen(null);}}>
      {[1,2,3,4].map(function(n){return <SheetOption key={n} active={measPerRow===n} color="#7c4dff" onClick={function(){setMPR(n);setOpen(null);}}><span style={{fontSize:22,fontWeight:"800",width:36,textAlign:"center",display:"inline-block"}}>{n}</span><span>{n===1?"1 Takt":n+" Takte"} pro Zeile</span></SheetOption>;})}
    </BottomSheet>}
  </>;
}


// ── Language definitions ──────────────────────────────────────────────────
var SPEECH_LANGS=[
  {id:"de-DE", label:"Deutsch",    flag:"🇩🇪",
    nums:["Eins","Zwei","Drei","Vier","Fünf","Sechs","Sieben","Acht","Neun","Zehn","Elf","Zwölf"],
    next:"Nächster Song",done:"Setlist fertig",bpmWord:"BPM"},
  {id:"en-US", label:"English",    flag:"🇺🇸",
    nums:["One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve"],
    next:"Next song",done:"Setlist done",bpmWord:"BPM"},
  {id:"en-GB", label:"English UK", flag:"🇬🇧",
    nums:["One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve"],
    next:"Next song",done:"Setlist done",bpmWord:"BPM"},
  {id:"es-ES", label:"Español",    flag:"🇪🇸",
    nums:["Uno","Dos","Tres","Cuatro","Cinco","Seis","Siete","Ocho","Nueve","Diez","Once","Doce"],
    next:"Siguiente canción",done:"Setlist terminada",bpmWord:"BPM"},
  {id:"fr-FR", label:"Français",   flag:"🇫🇷",
    nums:["Un","Deux","Trois","Quatre","Cinq","Six","Sept","Huit","Neuf","Dix","Onze","Douze"],
    next:"Chanson suivante",done:"Setlist terminée",bpmWord:"BPM"},
  {id:"it-IT", label:"Italiano",   flag:"🇮🇹",
    nums:["Uno","Due","Tre","Quattro","Cinque","Sei","Sette","Otto","Nove","Dieci","Undici","Dodici"],
    next:"Canzone successiva",done:"Setlist finita",bpmWord:"BPM"},
  {id:"pt-BR", label:"Português",  flag:"🇧🇷",
    nums:["Um","Dois","Três","Quatro","Cinco","Seis","Sete","Oito","Nove","Dez","Onze","Doze"],
    next:"Próxima música",done:"Setlist concluída",bpmWord:"BPM"},
  {id:"ja-JP", label:"日本語",     flag:"🇯🇵",
    nums:["イチ","ニ","サン","シ","ゴ","ロク","シチ","ハチ","ク","ジュウ","ジュウイチ","ジュウニ"],
    next:"次の曲",done:"セットリスト終了",bpmWord:"BPM"},
];

function getLangDef(langId){
  return SPEECH_LANGS.find(function(l){return l.id===langId;})||SPEECH_LANGS[0];
}

// ── i18n: UI translations ─────────────────────────────────────────────────
var I18N={
  "de-DE":{
    notation:"Notation", metronome:"Metronom", setlist:"Setlist",
    addBar:"+ Takt", removeBar:"− Takt",
    instrument:"Instrument", noteValue:"Notenwert", articulation:"Artikulation",
    linesPerRow:"Zeilen", presets:"Presets", symbols:"Zeichen",
    addSong:"+ Song hinzufügen", editSong:"Song bearbeiten",
    title:"Titel", bpm:"BPM", pdfUpload:"PDF hochladen",
    pdfChoose:"PDF auswählen", noPdf:"Kein PDF hochgeladen",
    deleteSong:"Song löschen", voiceOn:"🔊 Stimme AN", voiceOff:"🔇 Stimme AUS",
    noSongs:"Keine Songs", noSongsHint:"Füge deinen ersten Song hinzu",
    setlistDone:"Setlist fertig", countIn:"COUNT IN", voice:"STIMME",
    close:"Schließen", apply:"Auf Takt anwenden", cancel:"Abbrechen",
    clear:"Leeren", addMeasure:"+ Takt hinzufügen",
    groovePresets:"Groove Presets", combinable:"Kombinierbar",
    orchSymbols:"Orchesterzeichen", multiSelect:"Mehrfachauswahl — auf Takt anwenden",
    zoomedTact:"T.", beatsPerBar:"ZÄHLZEITEN", subdivision:"UNTERTEILUNG",
    language:"SPRACHE", progress:"Setlist",
    normal:"Normal",ghost:"Ghost",accent:"Akzent",flam:"Flam",
    whole:"Ganze",half:"Halbe",quarter:"Viertel",eighth:"Achtel",sixteenth:"Sechzehntel",triole:"Triole",
    rowsPerLine:"Takte pro Zeile",barPerLine:"Takt",barsPerLine:"Takte",perLine:"pro Zeile",
  },
  "en-US":{
    notation:"Notation", metronome:"Metronome", setlist:"Setlist",
    addBar:"+ Bar", removeBar:"− Bar",
    instrument:"Instrument", noteValue:"Note Value", articulation:"Articulation",
    linesPerRow:"Layout", presets:"Presets", symbols:"Symbols",
    addSong:"+ Add Song", editSong:"Edit Song",
    title:"Title", bpm:"BPM", pdfUpload:"Upload PDF",
    pdfChoose:"Choose PDF", noPdf:"No PDF uploaded",
    deleteSong:"Delete Song", voiceOn:"🔊 Voice ON", voiceOff:"🔇 Voice OFF",
    noSongs:"No Songs", noSongsHint:"Add your first song",
    setlistDone:"Setlist done", countIn:"COUNT IN", voice:"VOICE",
    close:"Close", apply:"Apply to bar", cancel:"Cancel",
    clear:"Clear", addMeasure:"+ Add Bar",
    groovePresets:"Groove Presets", combinable:"Combinable",
    orchSymbols:"Orchestra Symbols", multiSelect:"Multi-select — apply to bar",
    zoomedTact:"B.", beatsPerBar:"BEATS PER BAR", subdivision:"SUBDIVISION",
    language:"LANGUAGE", progress:"Setlist",
    normal:"Normal",ghost:"Ghost",accent:"Accent",flam:"Flam",
    whole:"Whole",half:"Half",quarter:"Quarter",eighth:"Eighth",sixteenth:"Sixteenth",triole:"Triplet",
    rowsPerLine:"Bars per row",barPerLine:"Bar",barsPerLine:"Bars",perLine:"per row",
  },
  "es-ES":{
    notation:"Notación", metronome:"Metrónomo", setlist:"Setlist",
    addBar:"+ Compás", removeBar:"− Compás",
    instrument:"Instrumento", noteValue:"Valor", articulation:"Articulación",
    linesPerRow:"Diseño", presets:"Presets", symbols:"Símbolos",
    addSong:"+ Añadir canción", editSong:"Editar canción",
    title:"Título", bpm:"BPM", pdfUpload:"Subir PDF",
    pdfChoose:"Elegir PDF", noPdf:"Sin PDF",
    deleteSong:"Eliminar canción", voiceOn:"🔊 Voz ACTIVA", voiceOff:"🔇 Voz DESACT.",
    noSongs:"Sin canciones", noSongsHint:"Añade tu primera canción",
    setlistDone:"Setlist lista", countIn:"CONTEO", voice:"VOZ",
    close:"Cerrar", apply:"Aplicar al compás", cancel:"Cancelar",
    clear:"Vaciar", addMeasure:"+ Añadir compás",
    groovePresets:"Presets de Groove", combinable:"Combinable",
    orchSymbols:"Símbolos de orquesta", multiSelect:"Selección múltiple",
    zoomedTact:"C.", beatsPerBar:"TIEMPOS", subdivision:"SUBDIVISIÓN",
    language:"IDIOMA", progress:"Setlist",
    normal:"Normal",ghost:"Ghost",accent:"Acento",flam:"Flam",
    whole:"Redonda",half:"Blanca",quarter:"Negra",eighth:"Corchea",sixteenth:"Semicorchea",triole:"Tresillo",
    rowsPerLine:"Compases por fila",barPerLine:"Compás",barsPerLine:"Compases",perLine:"por fila",
  },
  "fr-FR":{
    notation:"Notation", metronome:"Métronome", setlist:"Setlist",
    addBar:"+ Mesure", removeBar:"− Mesure",
    instrument:"Instrument", noteValue:"Valeur", articulation:"Articulation",
    linesPerRow:"Mise en page", presets:"Presets", symbols:"Symboles",
    addSong:"+ Ajouter chanson", editSong:"Modifier chanson",
    title:"Titre", bpm:"BPM", pdfUpload:"Charger PDF",
    pdfChoose:"Choisir PDF", noPdf:"Aucun PDF",
    deleteSong:"Supprimer chanson", voiceOn:"🔊 Voix ON", voiceOff:"🔇 Voix OFF",
    noSongs:"Aucune chanson", noSongsHint:"Ajoutez votre première chanson",
    setlistDone:"Setlist terminée", countIn:"COMPTE", voice:"VOIX",
    close:"Fermer", apply:"Appliquer à la mesure", cancel:"Annuler",
    clear:"Vider", addMeasure:"+ Ajouter mesure",
    groovePresets:"Presets Groove", combinable:"Combinable",
    orchSymbols:"Symboles d'orchestre", multiSelect:"Sélection multiple",
    zoomedTact:"M.", beatsPerBar:"TEMPS PAR MESURE", subdivision:"SUBDIVISION",
    language:"LANGUE", progress:"Setlist",
    normal:"Normal",ghost:"Ghost",accent:"Accent",flam:"Fla",
    whole:"Ronde",half:"Blanche",quarter:"Noire",eighth:"Croche",sixteenth:"Double croche",triole:"Triolet",
    rowsPerLine:"Mesures par ligne",barPerLine:"Mesure",barsPerLine:"Mesures",perLine:"par ligne",
  },
  "it-IT":{
    notation:"Notazione", metronome:"Metronomo", setlist:"Setlist",
    addBar:"+ Battuta", removeBar:"− Battuta",
    instrument:"Strumento", noteValue:"Valore", articulation:"Articolazione",
    linesPerRow:"Layout", presets:"Preset", symbols:"Simboli",
    addSong:"+ Aggiungi canzone", editSong:"Modifica canzone",
    title:"Titolo", bpm:"BPM", pdfUpload:"Carica PDF",
    pdfChoose:"Scegli PDF", noPdf:"Nessun PDF",
    deleteSong:"Elimina canzone", voiceOn:"🔊 Voce ON", voiceOff:"🔇 Voce OFF",
    noSongs:"Nessuna canzone", noSongsHint:"Aggiungi la tua prima canzone",
    setlistDone:"Setlist completata", countIn:"CONTA", voice:"VOCE",
    close:"Chiudi", apply:"Applica alla battuta", cancel:"Annulla",
    clear:"Svuota", addMeasure:"+ Aggiungi battuta",
    groovePresets:"Preset Groove", combinable:"Combinabile",
    orchSymbols:"Simboli orchestrali", multiSelect:"Selezione multipla",
    zoomedTact:"B.", beatsPerBar:"TEMPI PER BATTUTA", subdivision:"SUDDIVISIONE",
    language:"LINGUA", progress:"Setlist",
    normal:"Normale",ghost:"Ghost",accent:"Accento",flam:"Flam",
    whole:"Semibreve",half:"Minima",quarter:"Semiminima",eighth:"Croma",sixteenth:"Semicroma",triole:"Terzina",
    rowsPerLine:"Battute per riga",barPerLine:"Battuta",barsPerLine:"Battute",perLine:"per riga",
  },
  "pt-BR":{
    notation:"Notação", metronome:"Metrônomo", setlist:"Setlist",
    addBar:"+ Compasso", removeBar:"− Compasso",
    instrument:"Instrumento", noteValue:"Valor", articulation:"Articulação",
    linesPerRow:"Layout", presets:"Presets", symbols:"Símbolos",
    addSong:"+ Adicionar música", editSong:"Editar música",
    title:"Título", bpm:"BPM", pdfUpload:"Enviar PDF",
    pdfChoose:"Escolher PDF", noPdf:"Sem PDF",
    deleteSong:"Excluir música", voiceOn:"🔊 Voz ON", voiceOff:"🔇 Voz OFF",
    noSongs:"Sem músicas", noSongsHint:"Adicione sua primeira música",
    setlistDone:"Setlist concluída", countIn:"CONTAGEM", voice:"VOZ",
    close:"Fechar", apply:"Aplicar ao compasso", cancel:"Cancelar",
    clear:"Limpar", addMeasure:"+ Adicionar compasso",
    groovePresets:"Presets de Groove", combinable:"Combinável",
    orchSymbols:"Símbolos de orquestra", multiSelect:"Seleção múltipla",
    zoomedTact:"C.", beatsPerBar:"TEMPOS", subdivision:"SUBDIVISÃO",
    language:"IDIOMA", progress:"Setlist",
    normal:"Normal",ghost:"Ghost",accent:"Acento",flam:"Flam",
    whole:"Semibreve",half:"Mínima",quarter:"Semínima",eighth:"Colcheia",sixteenth:"Semicolcheia",triole:"Tercina",
    rowsPerLine:"Compassos por linha",barPerLine:"Compasso",barsPerLine:"Compassos",perLine:"por linha",
  },
  "ja-JP":{
    notation:"記譜", metronome:"メトロノーム", setlist:"セットリスト",
    addBar:"＋小節", removeBar:"－小節",
    instrument:"楽器", noteValue:"音符", articulation:"アーティキュレーション",
    linesPerRow:"レイアウト", presets:"プリセット", symbols:"記号",
    addSong:"＋曲を追加", editSong:"曲を編集",
    title:"タイトル", bpm:"BPM", pdfUpload:"PDFをアップロード",
    pdfChoose:"PDFを選択", noPdf:"PDFなし",
    deleteSong:"曲を削除", voiceOn:"🔊 音声オン", voiceOff:"🔇 音声オフ",
    noSongs:"曲がありません", noSongsHint:"最初の曲を追加してください",
    setlistDone:"セットリスト完了", countIn:"カウントイン", voice:"音声",
    close:"閉じる", apply:"小節に適用", cancel:"キャンセル",
    clear:"クリア", addMeasure:"＋小節を追加",
    groovePresets:"グルーヴプリセット", combinable:"組み合わせ可能",
    orchSymbols:"オーケストラ記号", multiSelect:"複数選択",
    zoomedTact:"小節", beatsPerBar:"拍子", subdivision:"分割",
    language:"言語", progress:"セットリスト",
    normal:"通常",ghost:"ゴースト",accent:"アクセント",flam:"フラム",
    whole:"全音符",half:"2分音符",quarter:"4分音符",eighth:"8分音符",sixteenth:"16分音符",triole:"3連符",
    rowsPerLine:"1行の小節数",barPerLine:"小節",barsPerLine:"小節",perLine:"",
  },
};

// Detect language from browser
function detectLang(){
  if(typeof navigator==="undefined") return "de-DE";
  var nav=navigator.language||navigator.userLanguage||"de-DE";
  // exact match
  if(I18N[nav]) return nav;
  // partial match (e.g. "en" → "en-US")
  var base=nav.split("-")[0];
  var match=Object.keys(I18N).find(function(k){return k.startsWith(base+"-");});
  return match||"de-DE";
}

function t(langId,key){
  var lang=I18N[langId]||I18N["de-DE"];
  return lang[key]||I18N["de-DE"][key]||key;
}


// ── useSpeech: multilingual Web Speech API wrapper ────────────────────────
function useSpeech(langId){
  var synthRef=useRef(null);
  var langDef=getLangDef(langId||"de-DE");

  useEffect(function(){
    if(typeof window!=="undefined"&&window.speechSynthesis){
      synthRef.current=window.speechSynthesis;
    }
  },[]);

  function _utt(text,rate,pitch){
    if(!synthRef.current)return;
    var u=new SpeechSynthesisUtterance(text);
    u.lang=langDef.id;
    u.rate=rate||1.0;
    u.pitch=pitch||1.0;
    u.volume=1.0;
    synthRef.current.speak(u);
  }

  function speak(text,opts){
    if(!synthRef.current)return;
    synthRef.current.cancel();
    _utt(text, opts&&opts.rate?opts.rate:1.0, opts&&opts.pitch?opts.pitch:1.0);
  }

  function cancel(){
    if(synthRef.current)synthRef.current.cancel();
  }

  function announceSong(title,bpm){
    if(!synthRef.current)return;
    synthRef.current.cancel();
    _utt(title+". "+bpm+" "+langDef.bpmWord+".",0.9,1.0);
  }

  function announceNext(nextTitle){
    if(!synthRef.current)return;
    synthRef.current.cancel();
    if(nextTitle) _utt(langDef.next+": "+nextTitle,0.95,1.0);
    else _utt(langDef.done,0.95,1.0);
  }

  function announceSection(section){
    if(!synthRef.current||!section)return;
    synthRef.current.cancel();
    _utt(section,1.0,1.0);
  }

  // Count in: spoken numbers at BPM timing
  function countIn(bpm,beatsPerBar,bars,onDone){
    var beatMs=60000/(Number(bpm)||120);
    var bpb=beatsPerBar||4;
    var totalBeats=(bars||1)*bpb;
    var timers=[];
    // Cancel any ongoing speech
    if(synthRef.current) synthRef.current.cancel();
    for(var b=0;b<totalBeats;b++){
      (function(beat,delay){
        timers.push(setTimeout(function(){
          // Speak the beat number
          if(synthRef.current){
            var langDef=getLangDef(langId);
            var num=langDef.nums[beat%bpb];
            var u=new SpeechSynthesisUtterance(num);
            u.lang=langId; u.rate=1.4; u.volume=1;
            synthRef.current.speak(u);
          }
        },delay));
      })(b, b*beatMs);
    }
    // onDone fires after all beats
    timers.push(setTimeout(function(){
      if(synthRef.current) synthRef.current.cancel();
      if(onDone) onDone();
    }, totalBeats*beatMs+100));
    return function(){ timers.forEach(function(t){clearTimeout(t);}); };
  }
  return {speak:speak,cancel:cancel,countIn:countIn,announceSong:announceSong,announceNext:announceNext,announceSection:announceSection,langDef:langDef};
}

function useMetronome(bpm){
  var [playing,setPlaying]=useState(false);
  var [beat,setBeat]=useState(-1);
  var [beatsPerBar,setBeatsPerBar]=useState(4);
  var timerRef=useRef(null);
  var nextTimeRef=useRef(0);
  var nextBeatRef=useRef(0);
  var playingRef=useRef(false);
  var bpmRef=useRef(Number(bpm)||120);
  var bpbRef=useRef(4);
  var audioHiRef=useRef(null);
  var audioLoRef=useRef(null);

  useEffect(function(){bpmRef.current=Number(bpm)||120;},[bpm]);
  useEffect(function(){bpbRef.current=beatsPerBar;},[beatsPerBar]);

  // Pre-create Audio elements
  useEffect(function(){
    audioHiRef.current=new Audio("data:audio/wav;base64,UklGRggHAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YeQGAAAAAHwmQUhxYTRvCXDvY2NMMywkB4jhtb+MpQOW0ZI/nB2x78408s0Wgzh1U5Nk92kXY9VQYTX3E37wEM+FswChlJkHnsCt2cZc5pkImimQRU1ZlmJvYCtTZzzUHuv9e91DwX2sf6F+oWSs3MB33Pj7thsHOKxNNFo7XJtTZEHEJ70Jz+qKzjC4R6pdptKs1Lx41Pfw/A4PK/dBGFHCVl5SgUTXLu0T6fYm29jDpbNgrM+ul7pMzpjnhgPZHmo2iEdGULBP6UUjNHsctAHu5j3PWL1GsyCy+bnYydnfZ/mIEzkrwT0GScpLykXHN28jJgvB8S/aJsfQuoy2ybr8xqzZpfA5CZAg+jNAQeZGVETkOdooOBOH+4bk29DEwtm72LyUxf7UQukAAJQWYyoqOTxBuUGgOtAs7RkwBCHuSdrwytPB8797xbnROOPo92ANJyH1MAA7Kj4hOmsvUB+2C+f2SuMi00XI6sOHxsDPed718AsFZxjPKGM01jmSOMowbyMWEsj+wOsy2wLPkMiPyPTO9ton66P9QRDeIJEt6jQbNgwxXSZUF7YFkfP84t/Vts1qyzTPmNh35i73yghDGbMmky/lMlIwMCh6G7ALq/pi6rbcNdPxzl/QSNfY4q/xEQIYEuwf9ikXL78uAymWHrUQAAFL8WXj5tj90lHS69Y74CPtIfx1C1sZOiTXKnYs8Si5IMkUigal99Hppt5p1+nUZteN3oTp/vZpBRoTfR5HJpgpFSj2IfcXRgth/eLvWOQU3AXYmti73cXmqfIAAD4N3RiJIUUmjiZkIkoaNg91AoT14Onf4Ibbbdqs3drkHu9B+9kHchO4HJ0ieCQaItEbXhLfBqr6Ke+u5U/fwdxJ3rLjVewt9/UCUQ7xF7se7iEwIZ8cyRScCkn/H/Rp6kPjet963zrjRerF853+iQlIE7saCx++H8UcgRavDVoDtfj77knngOIn4WDj4ugF8dT6KAXRDrQW6BvbHVkckxceENsG4PxS80zrueU54w/kHejl7pr3NgGdCroSnhigG2wbDxjxEc0JlgBg9zjvEOmY5TPl5+dd7fD0u/24BuAOQBUhGRUaBBgyEzEM1gMZ+/3ycOwx6LnmLuhh7M/yuPosAzQL4xF0FmYYhBfsEw8OnQZ2/ov2x+/u6ozo5Ojl6zPxLfgAAMUHlg6sE3MWnhYtFGwP7AhxAdr5BfO97Zrq9enc6xPwGPY3/ZoEaAvZEE4UZRUBFFEQxgoHBN/8H/aP8NLsU+s57GXvdvTT+rwBZggLDgcS5xN4E8oQMQw5BpX/CPlW8yTv7Ozs7B/vQfPU+DD/mAVPC64PNhKfEuEQMw0HCPcBufsE9oHxsu7n7TXvcPI29/f8BgOxCFENXxCEEaEQ1A11CQUEK/6Q+NvzlvAe75zv/fH39RP7tgA6BvwKcQ40EBYQHQ6GCsAFWADx+ij2i/KD8Efw3fER9YP5q/7xA7oIdwy+Dk0PFw5DCycHQAIg/V74hvQI8izxB/J99EP45/zcAZMGfgosDVAOyw2wCz8I4QMZ/3T6fPak8z7ycfI19FL3afsAAI4EjgiKCysNRQ3WCwwJPAXYAGX8Y/hK9XPzEvMw9Kn2Mfpe/rMCsQbiCekLjQy8C5IJUgZdAir+Nfrx9sD03/Nm9EP2PPn3/AQB7QQ9CJMKrQtsC9kJJwemA8H/6vuS+Bz2z/TP9Bn2hvjL+4b/SAOiBjMJrwrsCucJvge1BCcBfv0l+n/32fVj9Sb2DPjZ+jj+xgEZBdAHmglGCsEJHQiMBVwC7f6j++D49fYZ9mP2yPcd+hz9agCnA3EGeAiBCXAJRwgsBl8DMwAI/Tr6G/jq9sf2tfeW+TL8OP9QAh4FUAemCPoIRAibBjIEUgFQ/ob7RfnP9033zvdA+Xb7L/4XAdsDJwa6B2UIFwjbBtYERgJ5/7/8a/rA+O73DPgV+ej6T/0AAKwCBQXFBroHyAfxBk4FEgN/AOP9ifu3+aP4avgS+YX6mPwL/5UB7QPMBf0GXAfiBp0FtQNjAe3+mvyw+mf54/gy+Un6CPw4/pgA5ALVBDQG2QazBscFMgQkAtv/mv2l+zP6b/lv+TH6nfuI/bn/7AHkA2UFRAZoBs8FiwTDAq0Ah/6R/AP7DPrG+Tn6Vvv6/PX+CgH9ApUEogUHBrkFwgRBA2IBX/9x/dL7svox+lz6LvuM/E7+PgAkAscD+ASTBYkF2wSfA/oBHgBD/p38X/us+pf6I/s9/MX9i/9bAQADSgQSBUQF2QTgA3YCxgAD/2D9Dfwy++b6MfsK/Ff97/6kAEMCnAOIBO0EvwQFBNYCVQGx/xj+uvy/+0T7Vvvx+wP9bP4=");
    audioLoRef.current=new Audio("data:audio/wav;base64,UklGRggHAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YeQGAAAAAEoRkSH/L9g7hUSZSdlKOkjmQTg4tisKHfoMXfwO7OTcps//xHe9arkKuVK8EsPqzFLZoucZ9+gGPxZVJHAw9jltQIVDHUM/PyU4My7yIQcULgUs9sjnvdq3z0LHy8GSv7DAEMVyzG/WfuL97zb+awzjGewl6i9dN+g7Uz2SO8I2KC8tJVoZTwy5/k3xvOSq2afQJcp2xsbFGMhHzQvV996F6hr3CwSwEGEchyacLjw0HzclN1Q01C71JiId4BHIBXr5mO3A4n3ZSNJ8zVTL58spz+rU2NyJ5nfxEf28CN4T5h1QJrEsuDA1MhgxdS2AJ40fCBZyC1kAUPXo6qrhDdpz1CPRRNDc0dLV7tvb4y3tZvf9AWcMGRaWHnAlTyr2LEYtQSsEJ8wg7hjWD/0F6fsc8hnpVeE02wXX+tQq1ZDXCNxS4hjq8fJm/PgFKw+EF5ceCiSWJxIpbCiyJQshuRoSE30KbQFd+MHvC+ig4dLc3dnl2PPZ9tzC4RTolu/j94sAHAkmET4YCR48IqQkJCW5I3ggkRtHFfAN7gWu/Zv1IO6f52viyN7i3NDcjt4C4vzmN+1e9BL86gOCC3MSZBgHHSMgkSFBITsfnBuXFnIQfgkaAqn6jPMg7bjnnOP+4P7fp+Ds4q3mtevA8Xz4j/+ZBkANLBMQGK0b1h1yHnod/hojFx4SMwyxBfL+TPgY8qfsP+ga5V3jHuNc5AXn8+rv77f1+/toAqoIbw5qE1sXERpqG1Yb2hkLFxETIg6CCH0CYvyC9inxn+wd6c/m0+Ux5uTn0urS7q7zI/np/rEEMgoiD0ETWhZHGO8YTRhrFmUTZA+gClgF1P9c+jj1rfD07D3qq+hP6C3pN+tQ7kzy9vYO/FABeQZCC20PxhIgFV8WdBZhFTUTEBAdDJEHqQKp/c/4XvSO8JLtjuuc6sbqCOxP7nzxYvXO+YP+QgPOB+sLYg8JErwTZxQEFJoSPBANDTcJ7gRsAO77rvfi877wae4B7ZbsLO267ijxV/QZ+D38igDIBMAIPQwRDxoRPRJtEqoR/g+DDVoKrgawApj+mfro9rbzLfFs74nuju567z7xwfPi9nX6S/4vAvEFXAlGDIkOBxCvEHoQaw+TDQsL9gd9BNAAH/2b+XH2zPPM8YzwGvB78KjxkPMZ9iD5fPwAAH0DxwawCRUM1Q3cDhwPlQ5ODVkL0wjdBZ4CRP/6++r4PfYX9JHywPGt8Vbys/Ow9TH4Ffs0/mUBfQRVB8cJswsBDaENjA3EDFULVAnaBgsECwEF/h37e/hB9oz0cfP+8jjzGvSY9Zz3C/rF/KT/gQI6BagHrAktCxgMYQwHDA4LhQmBBx4FfAK+/wn9f/pD+HH2IfVj9D/0t/TD9VT3Vfmq+zT+0QBeA7oFxwdpCYsKIQsiC5AKdAndB+EFnAMqAa/+SfwZ+jr4xfbO9V71fPUk9k335/jc+hH9af/DAQIECQa8BwYJ1gkjCukJLQn5B14GcgRPAhIA2P2+++D5V/g294r2Xfaw9nz3uPhS+jP8RP5mAIECdgQtBo8HiggTCSQJuwjgB58GCAUyAzUBLf8z/WH7z/mT+Lr3Ufda99b3vfgC+pT7Xf1G/zQBDwO/BC0GRgf+B0oIKQicB6wGZQXZAx4CSQB2/rn8Kvve+eb4Tfgb+FL47fjl+Sz7sPxd/hwA1gF2A+UEEAbpBmUHfwc2B44GkAVLBNACMgGI/+f9ZPwU+wj6TPnp+Ob4QPny+fP6Nfyn/TX/ygBSArkD7ATcBX0Gxwa2Bk4GkwWPBFID6gFsAOz+ff0x/Br7Rfq++Yr5rPkh+uP66Psg/Xz+6v9VAawC3wPbBJYFBgYlBvMFcwWsBKgDdgImAcr/cv4y/Rj8NfuS+jj6K/ps+vX6wPvC/O39Mf98AMAB6gLrA7cEQwWJBYUFOAWnBNkD2gK3AYAARf8W/gH9F/xh++r6t/rL+iL7uvuI/IT9nv7I//IADwIOA+MDgwTmBAgF6ASGBOoDGwMlAhQB+P/d/tP96Pwo/Jz7Svs4+2X7zvtu/Dz9Lf41/0QATgFFAh0DygNDBIQEiARRBOADPgNyAocBiQCH/43+p/3i/Ej84Puv+7f7+Ptu/BL93P3A/rP/qACTAWgCGwOkA/wDHgQKBMEDRwOiAtwB/gAVAC7/Uv6O/ez8c/wr/BX8M/yE/AH9pv1o/j7/GwD3AMQBeAIKA3QDrgO4A5EDOgO6AhcCWQGLALj/6f4q/oX9Av2n/Hr8e/yq/Ab9iP0p/uL+qP9xADMB4wF6Au8CPANeA1MDHAO9AjoCmwHoACoAbP+2/hL+iv0i/eL8y/ze/Bv9fv0B/p3+S/8=");
    audioHiRef.current.volume=1.0;
    audioLoRef.current.volume=0.7;
    // Pre-load
    audioHiRef.current.load();
    audioLoRef.current.load();
  },[]);

  function beep(accent){
    try{
      var a=accent?audioHiRef.current:audioLoRef.current;
      if(!a) return;
      a.currentTime=0;
      a.play().catch(function(){});
      if(typeof window.__dwDebug==="function") window.__dwDebug("beep acc="+accent+" beat="+nextBeatRef.current);
    }catch(e){
      if(typeof window.__dwDebug==="function") window.__dwDebug("ERR:"+String(e));
    }
  }

  function tick(){
    if(!playingRef.current) return;
    var now=Date.now();
    var intervalMs=60000/bpmRef.current;

    // Check if it's time for next beat
    if(now >= nextTimeRef.current){
      var b=nextBeatRef.current;
      beep(b===0);
      setBeat(b);
      nextBeatRef.current=(b+1)%bpbRef.current;
      nextTimeRef.current+=intervalMs;
    }

    // Use requestAnimationFrame for tight timing
    timerRef.current=setTimeout(tick, Math.max(1, nextTimeRef.current-Date.now()-5));
  }

  function start(){
    if(typeof window.__dwDebug==="function") window.__dwDebug("START bpm="+bpmRef.current);
    // Unlock audio on iOS by playing silently first
    if(audioHiRef.current){
      audioHiRef.current.volume=0.001;
      audioHiRef.current.play().then(function(){
        audioHiRef.current.volume=1.0;
      }).catch(function(){});
    }
    playingRef.current=true;
    var intervalMs=60000/bpmRef.current;
    nextTimeRef.current=Date.now()+intervalMs;
    nextBeatRef.current=0;
    beep(true); // immediate first beat
    setBeat(0);
    setPlaying(true);
    timerRef.current=setTimeout(tick, intervalMs-5);
  }

  function stop(){
    playingRef.current=false;
    clearTimeout(timerRef.current);
    setPlaying(false);
    setBeat(-1);
  }

  function toggle(){
    if(playingRef.current) stop(); else start();
  }

  useEffect(function(){
    return function(){
      playingRef.current=false;
      clearTimeout(timerRef.current);
    };
  },[]);

  return {playing,beat,toggle,start,stop,beatsPerBar,setBeatsPerBar};
}


function MetronomeView({onBack,bpm,setBpm,metro,speechLang,setSpeechLang,appLang,setAppLang}){
  var [sheet,setSheet]=useState(null);
  var subdivOptions=[{id:"4",label:"Viertel",flags:0,dur:1},{id:"8",label:"Achtel",flags:1,dur:0.5},{id:"8t",label:"Triole",flags:1,dur:1/3,triolen:true},{id:"16",label:"16tel",flags:2,dur:0.25}];
  var [subdivId,setSubdivId]=useState("8");
  var [voiceOn,setVoiceOn]=useState(true);
  var [countInOn,setCountInOn]=useState(true);
  var [counting,setCounting]=useState(false);
  var speech=useSpeech(speechLang);
  var TM=function(key){return t(appLang||"de-DE",key);};
  function handleTap(){
    var now=Date.now();
    var taps=JSON.parse(sessionStorage.getItem('dw_taps')||'[]');
    taps=[...taps,now].filter(function(t){return now-t<3000;}).slice(-6);
    sessionStorage.setItem('dw_taps',JSON.stringify(taps));
    if(taps.length>=2){var diffs=[];for(var i=1;i<taps.length;i++)diffs.push(taps[i]-taps[i-1]);var avg=diffs.reduce(function(a,b){return a+b;},0)/diffs.length;setBpm(Math.round(60000/avg));}
  }
  var isOne=metro.beat===0;
  function CircleBtn({size,bg,border,onClick,children,label}){
    return <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
      <button onClick={onClick} style={{width:size||64,height:size||64,borderRadius:"50%",background:bg||"#1a1a2e",border:"2px solid "+(border||"#2a2a4a"),cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>{children}</button>
      {label&&<span style={{fontSize:9,color:"#555",fontFamily:"Inter,system-ui,sans-serif",textTransform:"uppercase",letterSpacing:"0.1em"}}>{label}</span>}
    </div>;
  }
  var metroBg=metro.playing&&isOne?"#0d1a0d":"#000000";
  var debugState=useState([]); var debugLog=debugState[0]; var setDebugLog=debugState[1];
  useEffect(function(){
    window.__dwDebug=function(msg){
      setDebugLog(function(p){return [msg].concat(p).slice(0,6);});
    };
    return function(){window.__dwDebug=null;};
  },[]);
  return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:700,background:metroBg,display:"flex",flexDirection:"column",fontFamily:"Inter,system-ui,sans-serif",transition:"background 0.06s"}}>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 16px 0",flexShrink:0}}>
      <button onClick={function(){if(metro.playing)metro.toggle();onBack();}} style={{width:38,height:38,borderRadius:"50%",border:"none",background:"rgba(255,255,255,0.08)",color:"#aaa",cursor:"pointer",fontSize:14,display:"flex",alignItems:"center",justifyContent:"center"}}>x</button>
      <span style={{fontSize:10,color:"#333",letterSpacing:"0.2em",textTransform:"uppercase"}}>METRONOM</span>
      <div style={{display:"flex",gap:6}}>
        <button onClick={function(){setCountInOn(function(v){return !v;})}}
          style={{padding:"4px 8px",borderRadius:12,border:"1px solid "+(countInOn?"#4f6ef7":"#222"),
            background:countInOn?"#4f6ef722":"transparent",color:countInOn?"#4f6ef7":"#333",
            fontSize:9,cursor:"pointer",fontFamily:"Inter,system-ui,sans-serif",letterSpacing:"0.08em"}}>
          COUNT IN
        </button>
        <button onClick={function(){setVoiceOn(function(v){return !v;})}}
          style={{padding:"4px 8px",borderRadius:12,border:"1px solid "+(voiceOn?"#4caf80":"#222"),
            background:voiceOn?"#4caf8022":"transparent",color:voiceOn?"#4caf80":"#333",
            fontSize:9,cursor:"pointer",fontFamily:"Inter,system-ui,sans-serif",letterSpacing:"0.08em"}}>
          STIMME
        </button>
        <button onClick={function(){setSheet(sheet==="lang"?null:"lang");}}
          style={{padding:"4px 8px",borderRadius:12,border:"1px solid "+(sheet==="lang"?"#f0a030":"#222"),
            background:sheet==="lang"?"#f0a03022":"transparent",color:sheet==="lang"?"#f0a030":"#333",
            fontSize:9,cursor:"pointer",fontFamily:"Inter,system-ui,sans-serif"}}>
          {getLangDef(speechLang).flag}
        </button>
      </div>
    </div>
    <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",userSelect:"none"}} onClick={function(){metro.toggle();}}>
      <div style={{fontSize:"clamp(120px,40vw,280px)",fontWeight:"900",lineHeight:1,color:metro.playing?(isOne?"#ffffff":"rgba(255,255,255,0.85)"):"#1e1e1e",letterSpacing:"-0.04em",transition:"color 0.04s"}}>
        {metro.playing&&metro.beat>=0?metro.beat+1:"▶"}
      </div>
    </div>
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:10,paddingBottom:8}}>
      <div style={{display:"flex",gap:8}}>
        {Array.from({length:metro.beatsPerBar},function(_,i){var active=metro.playing&&metro.beat===i,first=i===0;return <div key={i} style={{width:first?14:10,height:first?14:10,borderRadius:"50%",background:active?(first?"#ffffff":"#888"):"#222",border:"1.5px solid "+(active?(first?"#ffffff":"#666"):"#333"),transition:"background 0.05s"}}/>;  })}
      </div>
      <svg width={40} height={16} style={{opacity:(metro.playing&&isOne)?0.9:0.15,transition:"opacity 0.06s"}}>
        <polyline points="4,4 20,12 36,4" fill="none" stroke="white" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </div>
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:20,paddingBottom:16}}>
      <CircleBtn size={70} bg="#b03030" border="#c04040" onClick={function(){setSheet(sheet==="bpm"?null:"bpm");}}>
        <span style={{fontSize:22,fontWeight:"900",color:"white",lineHeight:1}}>{bpm}</span>
        <span style={{fontSize:8,color:"rgba(255,255,255,0.6)",letterSpacing:"0.1em",marginTop:1}}>BPM</span>
      </CircleBtn>
      <CircleBtn size={80} bg="#8b2060" border="#aa3070" onClick={function(){setSheet(sheet==="subdiv"?null:"subdiv");}}>
        <span style={{fontSize:11,color:"rgba(255,255,255,0.8)"}}>{subdivOptions.find(function(s){return s.id===subdivId;}).label}</span>
      </CircleBtn>
      <CircleBtn size={70} bg="#4a2080" border="#6030a0" onClick={function(){setSheet(sheet==="beats"?null:"beats");}}>
        <span style={{fontSize:22,fontWeight:"900",color:"white",lineHeight:1}}>{metro.beatsPerBar}</span>
        <span style={{fontSize:8,color:"rgba(255,255,255,0.5)",letterSpacing:"0.08em",marginTop:1}}>BEATS</span>
      </CircleBtn>
    </div>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 24px 20px"}}>
      <CircleBtn size={52} bg="#7a3010" border="#aa4018" onClick={function(){setSheet(sheet==="beats"?null:"beats");}}>
        <span style={{fontSize:14,fontWeight:"800",color:"white",lineHeight:1.1,textAlign:"center"}}>{metro.beatsPerBar}<br/><span style={{fontSize:10}}>4</span></span>
      </CircleBtn>
      <button onClick={function(){
        if(metro.playing){
          metro.toggle();
          speech.cancel();
          setCounting(false);
        } else if(countInOn&&voiceOn){
          setCounting(true);
          // Unlock AudioContext immediately on button press (iOS requirement)
          var AC=window.AudioContext||window.webkitAudioContext;
          if(AC){try{var tmp=new AC();tmp.resume();tmp.close();}catch(e){}}
          speech.countIn(Number(bpm),metro.beatsPerBar,1,function(){
            setCounting(false);
            if(!metro.playing) metro.start();
          });
        } else {
          metro.toggle();
        }
      }} style={{width:64,height:64,borderRadius:"50%",border:"none",cursor:"pointer",
        background:metro.playing?"#e05555":counting?"#e09050":"#4f6ef7",
        boxShadow:metro.playing?"0 0 24px #e0555555":counting?"0 0 24px #e0905055":"0 0 24px #4f6ef755",
        color:"white",fontSize:22,display:"flex",alignItems:"center",justifyContent:"center",
        transition:"all 0.2s"}}>
        {metro.playing?"◼":counting?"1…":"▶"}
      </button>
      <CircleBtn size={52} bg="#103060" border="#1850a0" onClick={handleTap}>
        <span style={{fontSize:18,color:"white"}}>TAP</span>
      </CircleBtn>
    </div>
    {sheet==="bpm"&&<div style={{position:"absolute",bottom:0,left:0,right:0,background:"#111118",borderRadius:"16px 16px 0 0",padding:"16px 20px 32px",boxShadow:"0 -12px 40px rgba(0,0,0,0.8)"}}>
      <div style={{fontSize:12,color:"#555",textAlign:"center",letterSpacing:"0.15em",marginBottom:12}}>BPM</div>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16}}>
        <button onClick={function(){setBpm(function(b){return Math.max(30,Number(b)-1);});}} style={{width:44,height:44,borderRadius:"50%",border:"1px solid #333",background:"#1a1a2e",color:"white",fontSize:22,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><span>{"-"}</span></button>
        <input type="number" inputMode="numeric" pattern="[0-9]*" value={bpm} min={30} max={300} onChange={function(e){setBpm(e.target.value);}} style={{flex:1,fontSize:36,fontWeight:"900",border:"none",outline:"none",background:"transparent",color:"white",textAlign:"center",fontFamily:"Inter,system-ui,sans-serif"}}/>
        <button onClick={function(){setBpm(function(b){return Math.min(300,Number(b)+1);});}} style={{width:44,height:44,borderRadius:"50%",border:"1px solid #333",background:"#1a1a2e",color:"white",fontSize:22,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><span>{"+"}</span></button>
      </div>
      <input type="range" min={30} max={240} value={bpm} onChange={function(e){setBpm(e.target.value);}} style={{width:"100%",accentColor:"#b03030",height:6,cursor:"pointer",marginBottom:16}}/>
      <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"center"}}>
        {[60,80,100,120,140,160,180,200].map(function(b){return <button key={b} onClick={function(){setBpm(b);setSheet(null);}} style={{padding:"6px 14px",border:"1px solid "+(Number(bpm)===b?"#b03030":"#333"),borderRadius:20,background:Number(bpm)===b?"#b03030":"#1a1a2e",color:"white",fontSize:12,cursor:"pointer",fontWeight:Number(bpm)===b?"700":"400"}}>{b}</button>;})}
      </div>
      <button onClick={function(){setSheet(null);}} style={{marginTop:14,width:"100%",padding:"10px",borderRadius:10,border:"none",background:"#222",color:"#666",cursor:"pointer",fontSize:13}}>{TM("close")}</button>
    </div>}
    {sheet==="beats"&&<div style={{position:"absolute",bottom:0,left:0,right:0,background:"#111118",borderRadius:"16px 16px 0 0",padding:"16px 20px 32px",boxShadow:"0 -12px 40px rgba(0,0,0,0.8)"}}>
      <div style={{fontSize:12,color:"#555",textAlign:"center",letterSpacing:"0.15em",marginBottom:16}}>ZAHLZEITEN</div>
      <div style={{display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap"}}>
        {[2,3,4,5,6,7,8,9,12].map(function(n){return <button key={n} onClick={function(){metro.setBeatsPerBar(n);setSheet(null);}} style={{width:52,height:52,borderRadius:"50%",border:"2px solid "+(metro.beatsPerBar===n?"#6030a0":"#333"),background:metro.beatsPerBar===n?"#6030a0":"#1a1a2e",color:"white",fontSize:18,fontWeight:"800",cursor:"pointer"}}>{n}</button>;})}
      </div>
      <button onClick={function(){setSheet(null);}} style={{marginTop:16,width:"100%",padding:"10px",borderRadius:10,border:"none",background:"#222",color:"#666",cursor:"pointer",fontSize:13}}>{TM("close")}</button>
    </div>}
    {sheet==="subdiv"&&<div style={{position:"absolute",bottom:0,left:0,right:0,background:"#111118",borderRadius:"16px 16px 0 0",padding:"16px 20px 32px",boxShadow:"0 -12px 40px rgba(0,0,0,0.8)"}}>
      <div style={{fontSize:12,color:"#555",textAlign:"center",letterSpacing:"0.15em",marginBottom:16}}>UNTERTEILUNG</div>
      <div style={{display:"flex",gap:10,justifyContent:"center"}}>
        {subdivOptions.map(function(s){return <button key={s.id} onClick={function(){setSubdivId(s.id);setSheet(null);}} style={{flex:1,padding:"14px 8px",borderRadius:12,border:"2px solid "+(subdivId===s.id?"#8b2060":"#333"),background:subdivId===s.id?"#8b2060":"#1a1a2e",color:"white",fontSize:11,fontWeight:subdivId===s.id?"700":"400",cursor:"pointer"}}>{s.label}</button>;})}
      </div>
      <button onClick={function(){setSheet(null);}} style={{marginTop:16,width:"100%",padding:"10px",borderRadius:10,border:"none",background:"#222",color:"#666",cursor:"pointer",fontSize:13}}>{TM("close")}</button>
    </div>}
    {sheet==="lang"&&<div style={{position:"absolute",bottom:0,left:0,right:0,background:"#111118",borderRadius:"16px 16px 0 0",padding:"16px 20px 32px",boxShadow:"0 -12px 40px rgba(0,0,0,0.8)"}}>
      <div style={{fontSize:12,color:"#555",textAlign:"center",letterSpacing:"0.15em",marginBottom:16}}>SPRACHE</div>
      <div style={{display:"flex",flexDirection:"column",gap:6}}>
        {SPEECH_LANGS.map(function(l){
          var active=speechLang===l.id;
          return <button key={l.id} onClick={function(){setSpeechLang(l.id);if(setAppLang)setAppLang(l.id);setSheet(null);
            // Preview voice
            setTimeout(function(){
              var u=new SpeechSynthesisUtterance(l.nums[0]+", "+l.nums[1]+", "+l.nums[2]+", "+l.nums[3]);
              u.lang=l.id; u.rate=1.2; window.speechSynthesis&&window.speechSynthesis.speak(u);
            },100);
          }}
            style={{display:"flex",alignItems:"center",gap:12,padding:"12px 16px",borderRadius:10,
              border:"2px solid "+(active?"#f0a030":"#2a2a3e"),
              background:active?"#f0a03022":"#1a1a2e",cursor:"pointer",textAlign:"left"}}>
            <span style={{fontSize:22}}>{l.flag}</span>
            <div style={{flex:1}}>
              <div style={{fontSize:14,fontWeight:active?"700":"400",color:active?"#f0a030":"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif"}}>{l.label}</div>
              <div style={{fontSize:10,color:"#555",fontFamily:"Inter,system-ui,sans-serif",marginTop:1}}>{l.nums.slice(0,4).join(" – ")}</div>
            </div>
            {active&&<span style={{color:"#f0a030",fontSize:16}}>{'✔'}</span>}
          </button>;
        })}
      </div>
      <button onClick={function(){setSheet(null);}} style={{marginTop:14,width:"100%",padding:"10px",borderRadius:10,border:"none",background:"#222",color:"#666",cursor:"pointer",fontSize:13}}>{TM("close")}</button>
    </div>}
  </div>;
}



// ── MIDI → DrumWriter note mapper ─────────────────────────────────────────
var MIDI_DRUM_MAP={
  35:"kick",36:"kick",38:"snare",40:"snare",37:"snare",
  42:"hihat",44:"hihat",46:"hihat",49:"crash",51:"ride",
  50:"tom1",48:"tom1",47:"tom2",45:"tom2",43:"floor",41:"floor",
  26:"hihat_f",
};
function parseMidi(buffer){
  var data=new Uint8Array(buffer);
  var pos=0;
  function read(n){var r=[];for(var i=0;i<n;i++)r.push(data[pos++]);return r;}
  function read32(){var b=read(4);return (b[0]<<24)|(b[1]<<16)|(b[2]<<8)|b[3];}
  function read16(){var b=read(2);return (b[0]<<8)|b[1];}
  function readVarLen(){var v=0,b;do{b=data[pos++];v=(v<<7)|(b&0x7f);}while(b&0x80);return v;}
  // Header
  if(String.fromCharCode.apply(null,read(4))!=="MThd") return null;
  read32(); // length
  var format=read16(),ntracks=read16(),tpb=read16();
  var notes={};
  for(var t=0;t<ntracks;t++){
    if(pos>=data.length) break;
    var tag=String.fromCharCode.apply(null,read(4));
    var tlen=read32();
    if(tag!=="MTrk"){pos+=tlen;continue;}
    var tend=pos+tlen;
    var tick=0,lastStatus=0;
    while(pos<tend){
      var dt=readVarLen(); tick+=dt;
      var sb=data[pos];
      var status=sb&0x80?sb:lastStatus;
      if(sb&0x80) pos++;
      else lastStatus=status;
      var type=status&0xf0,ch=status&0x0f;
      if(type===0x90||type===0x80){
        var note=data[pos++],vel=data[pos++];
        var isOn=type===0x90&&vel>0;
        if(isOn&&ch===9){
          var instr=MIDI_DRUM_MAP[note];
          if(instr){
            var beat=(tick/tpb)%4;
            beat=Math.round(beat*4)/4; // snap to 16ths
            var key=instr+":"+beat.toFixed(6);
            notes[key]={accent:"normal",nvId:"16"};
          }
        }
      } else if(type===0xa0||type===0xb0||type===0xe0){pos+=2;}
      else if(type===0xc0||type===0xd0){pos++;}
      else if(status===0xff){var mt=data[pos++];var ml=readVarLen();pos+=ml;}
      else {pos++;} // unknown, skip
    }
    pos=tend;
  }
  return Object.keys(notes).length>0?{id:uid(),timeSig:"4/4",notes:notes,section:"",repeat:"none",comment:"",symbols:[],voltaLabel:"",rehearsalLetter:""}:null;
}

// ── DrumWriter JSON Export/Import ─────────────────────────────────────────
function exportGroovesJSON(measures,title,bpm){
  var data={app:"DrumWriter",version:"1.0",title:title,bpm:bpm,measures:measures};
  var json=JSON.stringify(data,null,2);
  var blob=new Blob([json],{type:"application/json"});
  var url=URL.createObjectURL(blob);
  var a=document.createElement("a");
  a.href=url; a.download=(title||"groove")+".drumwriter.json";
  a.click(); URL.revokeObjectURL(url);
}
function importGroovesJSON(text){
  try{
    var data=JSON.parse(text);
    if(data.app!=="DrumWriter") return null;
    return data;
  }catch(e){return null;}
}

// ── Setlist ───────────────────────────────────────────────────────────────
// Each song: { id, title, bpm, pdf: {name, dataUrl}, done }
function SetlistView({metro,bpm,setBpm,speechLang,appLang}){
  var speech=useSpeech(speechLang);
  var [voiceOn,setVoiceOn]=useState(true);
  var TS=function(key){return t(appLang||"de-DE",key);};
  // ── Bands ──────────────────────────────────────────────────────────────
  var [bands,setBands]=useState([{id:"b1",name:"Meine Band",color:"#e040fb",emoji:"🎸"}]);
  var [activeBand,setActiveBand]=useState("b1");
  var [bandSheet,setBandSheet]=useState(false);
  var [editBand,setEditBand]=useState(null); // band id being edited
  // ── Songs (per band) ───────────────────────────────────────────────────
  var [allSongs,setAllSongs]=useState({"b1":[]});
  var songs=allSongs[activeBand]||[];
  function setSongs(fn){
    setAllSongs(function(prev){
      var cur=prev[activeBand]||[];
      var next=typeof fn==="function"?fn(cur):fn;
      return Object.assign({},prev,{[activeBand]:next});
    });
  }
  var [activeSong,setActiveSong]=useState(null);
  var [editSong,setEditSong]=useState(null);
  var [dragOver,setDragOver]=useState(null);
  var fileRef=useRef();

  var BAND_COLORS=["#e040fb","#40c4ff","#69ff47","#ff9040","#7c4dff","#ff4081","#00e5ff","#ffeb3b"];
  var BAND_EMOJIS=["🎸","🥁","🎹","🎺","🎻","🎤","🎷","🎵","⚡","🔥","💀","🌟"];

  function addBand(){
    var id="b"+Date.now();
    var colorIdx=bands.length%BAND_COLORS.length;
    var newBand={id:id,name:"Neue Band",color:BAND_COLORS[colorIdx],emoji:"🎸"};
    setBands(function(p){return p.concat([newBand]);});
    setAllSongs(function(p){return Object.assign({},p,{[id]:[]});});
    setActiveBand(id);
    setActiveSong(null);
    setEditBand(id);
  }
  function deleteBand(id){
    if(bands.length<=1){alert("Mindestens eine Band muss vorhanden sein.");return;}
    setBands(function(p){return p.filter(function(b){return b.id!==id;});});
    setAllSongs(function(p){var n=Object.assign({},p);delete n[id];return n;});
    if(activeBand===id){
      var remaining=bands.filter(function(b){return b.id!==id;});
      if(remaining.length>0)setActiveBand(remaining[0].id);
    }
    setEditBand(null);
  }
  function updateBand(id,patch){
    setBands(function(p){return p.map(function(b){return b.id!==id?b:Object.assign({},b,patch);});});
  }

  function newSongId(){return "s"+Date.now();}

  function addSong(){
    var s={id:newSongId(),title:"Neuer Song",bpm:120,pdf:null,done:false};
    setSongs(function(p){return p.concat([s]);});
    setEditSong(s.id);
  }

  function updateSong(id,patch){
    setSongs(function(p){return p.map(function(s){return s.id!==id?s:Object.assign({},s,patch);});});
  }

  function deleteSong(id){
    setSongs(function(p){return p.filter(function(s){return s.id!==id;});});
    if(activeSong===id)setActiveSong(null);
    if(editSong===id)setEditSong(null);
  }

  function toggleDone(id){
    setSongs(function(prev){
      var updated=prev.map(function(s){return s.id!==id?s:Object.assign({},s,{done:!s.done});});
      // If marking done, announce next song
      var idx=prev.findIndex(function(s){return s.id===id;});
      var wasDone=prev[idx]&&prev[idx].done;
      if(!wasDone&&voiceOn){
        var next=prev[idx+1];
        if(next) speech.speak("Naechster Song: "+next.title,{lang:"de-DE",rate:0.95});
        else speech.speak("Setlist fertig!",{lang:"de-DE",rate:0.95});
      }
      return updated;
    });
  }

  function handlePdfUpload(songId,file){
    if(!file||file.type!=="application/pdf")return;
    var reader=new FileReader();
    reader.onload=function(e){
      updateSong(songId,{pdf:{name:file.name,dataUrl:e.target.result}});
    };
    reader.readAsDataURL(file);
  }

  function openSong(song){
    setActiveSong(song.id);
    setBpm(song.bpm);
    if(metro.playing)metro.toggle();
    // Announce song title + BPM
    if(voiceOn){
      speech.announceSong(song.title,song.bpm);
    }
  }

  // Drag to reorder
  var dragSrc=useRef(null);
  function onDragStart(id){dragSrc.current=id;}
  function onDrop(targetId){
    if(!dragSrc.current||dragSrc.current===targetId)return;
    setSongs(function(prev){
      var from=prev.findIndex(function(s){return s.id===dragSrc.current;});
      var to=prev.findIndex(function(s){return s.id===targetId;});
      var arr=prev.slice();
      var item=arr.splice(from,1)[0];
      arr.splice(to,0,item);
      return arr;
    });
    setDragOver(null);
    dragSrc.current=null;
  }

  var activeSongObj=songs.find(function(s){return s.id===activeSong;});
  var editSongObj=songs.find(function(s){return s.id===editSong;});
  var doneCnt=songs.filter(function(s){return s.done;}).length;

  // ── PDF Viewer (full screen) ──────────────────────────────────────────
  if(activeSong&&activeSongObj){
    return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:600,background:"#000",display:"flex",flexDirection:"column"}}>
      {/* Header */}
      <div style={{background:"#0d0020",borderBottom:"1px solid #2a0045",padding:"0 12px",display:"flex",alignItems:"center",gap:8,minHeight:50,flexShrink:0}}>
        <button onClick={function(){setActiveSong(null);if(metro.playing)metro.toggle();}}
          style={{width:36,height:36,borderRadius:"50%",border:"none",background:"rgba(255,255,255,0.08)",color:"#aaa",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>{'✕'}</button>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:14,fontWeight:"700",color:"#f0f2f8",fontFamily:"Inter,system-ui,sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{activeSongObj.title}</div>
          <div style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>{activeSongObj.bpm} BPM</div>
        </div>
        {/* Metro controls */}
        <div style={{display:"flex",alignItems:"center",gap:6}}>
          <button onClick={function(){setBpm(Math.max(30,Number(bpm)-5));}}
            style={{width:28,height:28,borderRadius:6,border:"1px solid #2e3145",background:"#1a0035",color:"#f0e8ff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>{'−'}</button>
          <div style={{fontSize:12,color:"#7a9fff",fontFamily:"Inter,system-ui,sans-serif",fontWeight:"700",minWidth:36,textAlign:"center"}}>{bpm}</div>
          <button onClick={function(){setBpm(Math.min(300,Number(bpm)+5));}}
            style={{width:28,height:28,borderRadius:6,border:"1px solid #2e3145",background:"#1a0035",color:"#f0e8ff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}><span>{"+"}</span></button>
          <button onClick={function(){
              if(metro.playing){metro.toggle();speech.cancel();}
              else if(voiceOn){
                speech.countIn(Number(bpm),metro.beatsPerBar,1,function(){metro.toggle();});
              } else {metro.toggle();}
            }}
            style={{width:52,height:36,borderRadius:8,border:"none",cursor:"pointer",fontWeight:"700",fontSize:11,fontFamily:"Inter,system-ui,sans-serif",
              background:metro.playing?"#e05555":"#4f6ef7",color:"white",
              boxShadow:metro.playing?"0 0 12px #e0555566":"0 0 12px #4f6ef766"}}>
            {metro.playing?("▶ "+(metro.beat>=0?metro.beat+1:"")):"1234▶"}
          </button>
        </div>
        {/* Done toggle */}
        <button onClick={function(){toggleDone(activeSong);}}
          style={{width:36,height:36,borderRadius:"50%",border:"2px solid "+(activeSongObj.done?"#4caf80":"#2a0045"),background:activeSongObj.done?"#4caf8033":"transparent",color:activeSongObj.done?"#4caf80":"#9370b8",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>{'✓'}</button>
      </div>
      {/* Nav arrows + PDF */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",position:"relative"}}>
        {activeSongObj.pdf?
          (activeSongObj.pdf.type==="image"
            ?<img src={activeSongObj.pdf.dataUrl} style={{flex:1,objectFit:"contain",background:"#050510",width:"100%"}} alt={activeSongObj.pdf.name}/>
            :<iframe src={activeSongObj.pdf.dataUrl} style={{flex:1,border:"none",background:"white",width:"100%"}} title="PDF"/>
          )
          :
          <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,background:"#050510"}}>
            <div style={{fontSize:48}}>{'📄'}</div>
            <div style={{fontSize:14,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>Kein PDF hochgeladen</div>
            <label style={{padding:"10px 20px",borderRadius:8,background:"linear-gradient(135deg,#e040fb,#7c4dff)",color:"white",cursor:"pointer",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:"600"}}>
              PDF auswählen
              <input type="file" accept="application/pdf" style={{display:"none"}} onChange={function(e){if(e.target.files[0])handlePdfUpload(activeSong,e.target.files[0]);}}/>
            </label>
          </div>
        }
        {/* Prev / Next song arrows */}
        {(function buildNav(){
          var idx=songs.findIndex(function(s){return s.id===activeSong;});
          var hasPrev=idx>0,hasNext=idx<songs.length-1;
          return <React.Fragment>
            {hasPrev&&<button style={{position:"absolute",top:"50%",transform:"translateY(-50%)",width:36,height:48,border:"none",background:"rgba(0,0,0,0.5)",color:"white",cursor:"pointer",fontSize:22,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:6,left:6}} onClick={function(){openSong(songs[idx-1]);}}>&#8249;</button>}
            {hasNext&&<button style={{position:"absolute",top:"50%",transform:"translateY(-50%)",width:36,height:48,border:"none",background:"rgba(0,0,0,0.5)",color:"white",cursor:"pointer",fontSize:22,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:6,right:6}} onClick={function(){openSong(songs[idx+1]);}}>&#8250;</button>}
          </React.Fragment>;
        })()}
      </div>
    </div>;
  }

  // ── Edit Song Sheet ───────────────────────────────────────────────────
  var editSheet=editSong&&editSongObj?
    <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:700,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"flex-end"}}
      onClick={function(){setEditSong(null);}}>
      <div onClick={function(e){e.stopPropagation();}} style={{background:"#0d0020",borderRadius:"18px 18px 0 0",width:"100%",maxWidth:640,margin:"0 auto",padding:"20px 20px 40px",boxShadow:"0 -16px 60px rgba(0,0,0,0.7)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
          <span style={{fontSize:13,fontWeight:"700",color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif"}}>Song bearbeiten</span>
          <button onClick={function(){setEditSong(null);}} style={{width:28,height:28,borderRadius:"50%",border:"none",background:"#2a0045",color:"#9370b8",cursor:"pointer",fontSize:14,display:"flex",alignItems:"center",justifyContent:"center"}}>{'✕'}</button>
        </div>
        {/* Title */}
        <div style={{marginBottom:12}}>
          <div style={{fontSize:9,color:"#9370b8",letterSpacing:"0.14em",textTransform:"uppercase",fontFamily:"Inter,system-ui,sans-serif",marginBottom:4}}>Titel</div>
          <input value={editSongObj.title} onChange={function(e){updateSong(editSong,{title:e.target.value});}}
            style={{width:"100%",padding:"10px 12px",borderRadius:8,border:"1px solid #2e3145",background:"#050510",color:"#f0f2f8",fontFamily:"Inter,system-ui,sans-serif",fontSize:14,outline:"none"}}/>
        </div>
        {/* BPM */}
        <div style={{marginBottom:12}}>
          <div style={{fontSize:9,color:"#9370b8",letterSpacing:"0.14em",textTransform:"uppercase",fontFamily:"Inter,system-ui,sans-serif",marginBottom:4}}>BPM</div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <button onClick={function(){updateSong(editSong,{bpm:Math.max(30,editSongObj.bpm-5)});}} style={{width:36,height:36,borderRadius:8,border:"1px solid #2e3145",background:"#1a0035",color:"white",cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}>{'−'}</button>
            <input type="number" value={editSongObj.bpm} min={30} max={300}
              onChange={function(e){updateSong(editSong,{bpm:parseInt(e.target.value)||120});}}
              style={{flex:1,padding:"10px 12px",borderRadius:8,border:"1px solid #2e3145",background:"#050510",color:"#f0f2f8",fontFamily:"Inter,system-ui,sans-serif",fontSize:18,fontWeight:"700",textAlign:"center",outline:"none"}}/>
            <button onClick={function(){updateSong(editSong,{bpm:Math.min(300,editSongObj.bpm+5)});}} style={{width:36,height:36,borderRadius:8,border:"1px solid #2e3145",background:"#1a0035",color:"white",cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}><span>{"+"}</span></button>
          </div>
        </div>
        {/* PDF */}
        <div style={{marginBottom:16}}>
          <div style={{fontSize:9,color:"#9370b8",letterSpacing:"0.14em",textTransform:"uppercase",fontFamily:"Inter,system-ui,sans-serif",marginBottom:8}}>Datei</div>
          {editSongObj.pdf?
            <div style={{display:"flex",alignItems:"center",gap:8,padding:"10px 12px",borderRadius:8,border:"1px solid #2a0045",background:"#050510"}}>
              <span style={{fontSize:18}}>{editSongObj.pdf.type==="image"?"🖼️":"📄"}</span>
              <span style={{flex:1,fontSize:12,color:"#a080c0",fontFamily:"Inter,system-ui,sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{editSongObj.pdf.name}</span>
              <button onClick={function(){updateSong(editSong,{pdf:null});}} style={{border:"none",background:"transparent",color:"#ff4081",cursor:"pointer",fontSize:16}}>{"✕"}</button>
            </div>
          :
            <div style={{display:"flex",flexDirection:"column",gap:6}}>
              <label style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",borderRadius:10,border:"1px solid #2a0045",background:"#0a001a",cursor:"pointer"}}>
                <span style={{fontSize:18}}>{"📄"}</span>
                <div>
                  <div style={{fontSize:12,color:"#e040fb",fontFamily:"Inter,system-ui,sans-serif",fontWeight:"700"}}>PDF</div>
                  <div style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>Noten, Texte, Akkorde</div>
                </div>
                <input type="file" accept="application/pdf" style={{display:"none"}}
                  onChange={function(e){if(e.target.files[0])handlePdfUpload(editSong,e.target.files[0]);}}/>
              </label>
              <label style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",borderRadius:10,border:"1px solid #2a0045",background:"#0a001a",cursor:"pointer"}}>
                <span style={{fontSize:18}}>{"🖼️"}</span>
                <div>
                  <div style={{fontSize:12,color:"#7c4dff",fontFamily:"Inter,system-ui,sans-serif",fontWeight:"700"}}>Bild (JPG / PNG)</div>
                  <div style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>Foto von Noten, Screenshot</div>
                </div>
                <input type="file" accept="image/*" style={{display:"none"}}
                  onChange={function(e){
                    var f=e.target.files[0];if(!f)return;
                    var reader=new FileReader();
                    reader.onload=function(ev){updateSong(editSong,{pdf:{name:f.name,dataUrl:ev.target.result,type:"image"}});};
                    reader.readAsDataURL(f);
                  }}/>
              </label>
            </div>
          }
                </div>
        {/* Delete */}
        <button onClick={function(){deleteSong(editSong);setEditSong(null);}}
          style={{width:"100%",padding:"10px",borderRadius:8,border:"1px solid #3a2030",background:"#1a0010",color:"#ff4081",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,cursor:"pointer",fontWeight:"600"}}>
          Song löschen
        </button>
      </div>
    </div>
  :null;

  // ── Setlist overview ──────────────────────────────────────────────────
  return <div style={{display:"flex",flexDirection:"column",flex:1,overflow:"hidden"}}>
    {/* Progress bar */}
    {songs.length>0&&<div style={{background:"#0d0020",padding:"8px 16px",borderBottom:"1px solid #252838",flexShrink:0}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
        <span style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",letterSpacing:"0.1em",textTransform:"uppercase"}}>Setlist</span>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <button onClick={function(){setVoiceOn(function(v){return !v;})}}
            style={{padding:"2px 8px",borderRadius:10,border:"1px solid "+(voiceOn?"#4caf80":"#333"),
              background:voiceOn?"#4caf8022":"transparent",
              color:voiceOn?"#4caf80":"#9370b8",fontSize:9,cursor:"pointer",
              fontFamily:"Inter,system-ui,sans-serif"}}>
            {voiceOn?"🔊":"🔇"} {getLangDef(speechLang).flag}
          </button>
          <span style={{fontSize:10,color:doneCnt===songs.length?"#4caf80":"#9370b8",fontFamily:"Inter,system-ui,sans-serif",fontWeight:"600"}}>{doneCnt} / {songs.length}</span>
        </div>
      </div>
      <div style={{height:3,background:"#1a0035",borderRadius:2}}>
        <div style={{height:3,borderRadius:2,background:"#4caf80",transition:"width 0.3s",width:(songs.length?Math.round(doneCnt/songs.length*100):0)+"%"}}/>
      </div>
    </div>}

          {/* ── Band selector ── */}
      <div style={{background:"#0a001a",borderBottom:"1px solid #1a0035",
        padding:"8px 10px",display:"flex",alignItems:"center",gap:6,overflowX:"auto",
        WebkitOverflowScrolling:"touch",scrollbarWidth:"none",flexShrink:0}}>
        {bands.map(function(b){
          var active=activeBand===b.id;
          return <button key={b.id}
            onClick={function(){setActiveBand(b.id);setActiveSong(null);}}
            style={{display:"flex",alignItems:"center",gap:5,padding:"6px 12px",
              borderRadius:20,border:"2px solid "+(active?b.color:"#2a0045"),
              background:active?b.color+"22":"#1a0035",
              color:active?b.color:"#9370b8",cursor:"pointer",flexShrink:0,
              fontFamily:"Inter,system-ui,sans-serif",fontSize:12,fontWeight:active?"700":"400",
              boxShadow:active?"0 0 10px "+b.color+"44":"none",transition:"all 0.15s"}}>
            <span>{b.emoji}</span>
            <span>{b.name}</span>
            <span style={{fontSize:10,opacity:0.6}}>{(allSongs[b.id]||[]).length}</span>
          </button>;
        })}
        <button onClick={addBand}
          style={{width:32,height:32,borderRadius:"50%",border:"1.5px dashed #2a0045",
            background:"transparent",color:"#7c4dff",cursor:"pointer",fontSize:18,
            display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{"+"}</button>
        <button onClick={function(){setBandSheet(true);}}
          style={{width:32,height:32,borderRadius:"50%",border:"1px solid #2a0045",
            background:"#1a0035",color:"#9370b8",cursor:"pointer",fontSize:14,
            display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{"✏"}</button>
      </div>

{/* Song list */}
    <div style={{flex:1,overflowY:"auto",padding:"8px",background:"#050510"}}>
      {songs.length===0&&<div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:300,gap:12}}>
        <div style={{fontSize:48}}>{'🎵'}</div>
        <div style={{fontSize:15,fontWeight:"700",color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif"}}>Keine Songs</div>
        <div style={{fontSize:12,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>Füge deinen ersten Song hinzu</div>
      </div>}
      {songs.map(function(song,idx){
        var isDragTarget=dragOver===song.id;
        return <div key={song.id}
          draggable
          onDragStart={function(){onDragStart(song.id);}}
          onDragOver={function(e){e.preventDefault();setDragOver(song.id);}}
          onDragLeave={function(){setDragOver(null);}}
          onDrop={function(){onDrop(song.id);}}
          style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",
            borderRadius:10,marginBottom:6,
            background:isDragTarget?"#1e2a50":song.done?"#061a06":"#0d0020",
            border:"1px solid "+(isDragTarget?"#4f6ef7":song.done?"#4caf8044":"#2a0045"),
            transition:"all 0.2s",opacity:song.done?0.7:1}}>
          {/* Number */}
          <div style={{width:24,height:24,borderRadius:"50%",background:"#1a0035",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <span style={{fontSize:10,fontWeight:"700",color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>{idx+1}</span>
          </div>
          {/* Info */}
          <div style={{flex:1,minWidth:0,cursor:"pointer"}} onClick={function(){openSong(song);}}>
            <div style={{fontSize:14,fontWeight:"600",color:song.done?"#4caf80":"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",textDecoration:song.done?"line-through":"none",fontWeight:song.done?"400":"600"}}>{song.title}</div>
            <div style={{display:"flex",alignItems:"center",gap:8,marginTop:2}}>
              <span style={{fontSize:10,color:"#e040fb",fontFamily:"Inter,system-ui,sans-serif",fontWeight:"600"}}>{song.bpm} BPM</span>
              {song.pdf&&<span style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif"}}>📄 {song.pdf.name}</span>}
            </div>
          </div>
          {/* Done check */}
          <button onClick={function(){toggleDone(song.id);}}
            style={{
              width:40,height:40,borderRadius:"50%",
              border:"2px solid "+(song.done?"#4caf80":"#9370b8"),
              background:song.done?"linear-gradient(135deg,#4caf8055,#4caf8022)":"#1a0035",
              color:song.done?"#4caf80":"#9370b8",
              cursor:"pointer",fontSize:18,
              display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,
              boxShadow:song.done?"0 0 12px #4caf8055":"none",
              transition:"all 0.2s",
            }}>
            {song.done?"✓":"○"}
          </button>
          {/* Edit */}
          <button onClick={function(){setEditSong(song.id);}}
            style={{width:32,height:32,borderRadius:"50%",border:"1px solid #2e3145",background:"#1a0035",color:"#a080c0",cursor:"pointer",fontSize:12,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{'✎'}</button>
        </div>;
      })}
    </div>

    {/* Add song button */}
    <div style={{padding:"8px 12px 16px",background:"#050510",flexShrink:0}}>
      <button onClick={addSong} style={{width:"100%",padding:"12px",borderRadius:10,border:"1.5px dashed #2a0045",background:"transparent",color:"#e040fb",fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:"600",cursor:"pointer"}}>+ Song hinzufügen</button>
    </div>

    {editSheet}

    {/* ── Band Management Sheet ── */}
    {bandSheet&&<div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:800,
      background:"rgba(5,5,16,0.9)"}} onClick={function(){setBandSheet(false);setEditBand(null);}}>
      <div onClick={function(e){e.stopPropagation();}} style={{
        position:"fixed",bottom:0,left:0,right:0,
        background:"#0d0020",borderRadius:"20px 20px 0 0",
        border:"1px solid #2a0045",borderBottom:"none",
        padding:"20px 16px 40px",maxHeight:"80vh",overflowY:"auto",
        boxShadow:"0 -20px 60px rgba(124,77,255,0.2), 0 -4px 0 #7c4dff",
      }}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
          <span style={{fontSize:15,fontWeight:"700",color:"#f0e8ff",
            fontFamily:"Inter,system-ui,sans-serif"}}>{"🎸 Bands verwalten"}</span>
          <button onClick={function(){setBandSheet(false);setEditBand(null);}}
            style={{width:28,height:28,borderRadius:"50%",border:"1px solid #2a0045",
              background:"#1a0035",color:"#9370b8",cursor:"pointer",fontSize:16,
              display:"flex",alignItems:"center",justifyContent:"center"}}>{"×"}</button>
        </div>

        {/* Band list */}
        {bands.map(function(b){
          var isEditing=editBand===b.id;
          return <div key={b.id} style={{
            background:isEditing?"#1a0035":"#0a001a",
            border:"1.5px solid "+(isEditing?b.color:"#2a0045"),
            borderRadius:12,padding:"12px 14px",marginBottom:8,
            transition:"all 0.15s",
          }}>
            {isEditing?<div>
              {/* Emoji picker */}
              <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:10}}>
                {BAND_EMOJIS.map(function(em){
                  return <button key={em} onClick={function(){updateBand(b.id,{emoji:em});}}
                    style={{width:36,height:36,borderRadius:8,border:"1px solid "+(b.emoji===em?"#e040fb":"#2a0045"),
                      background:b.emoji===em?"#e040fb22":"#1a0035",fontSize:20,cursor:"pointer"}}>
                    {em}
                  </button>;
                })}
              </div>
              {/* Name input */}
              <input value={b.name}
                onChange={function(e){updateBand(b.id,{name:e.target.value});}}
                style={{width:"100%",padding:"8px 12px",borderRadius:8,
                  border:"1px solid #2a0045",background:"#050510",
                  color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif",
                  fontSize:14,outline:"none",boxSizing:"border-box",marginBottom:8}}/>
              {/* Color picker */}
              <div style={{display:"flex",gap:6,marginBottom:10}}>
                {BAND_COLORS.map(function(c){
                  return <button key={c} onClick={function(){updateBand(b.id,{color:c});}}
                    style={{width:28,height:28,borderRadius:"50%",border:"3px solid "+(b.color===c?"white":"transparent"),
                      background:c,cursor:"pointer",boxShadow:b.color===c?"0 0 8px "+c:"none"}}/>;
                })}
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={function(){setEditBand(null);}}
                  style={{flex:1,padding:"8px",borderRadius:8,border:"none",
                    background:"linear-gradient(135deg,#e040fb,#7c4dff)",
                    color:"white",fontFamily:"Inter,system-ui,sans-serif",
                    fontSize:12,fontWeight:"700",cursor:"pointer"}}>{"Fertig"}</button>
                <button onClick={function(){deleteBand(b.id);}}
                  style={{padding:"8px 14px",borderRadius:8,border:"1px solid #ff408144",
                    background:"#1a0010",color:"#ff4081",fontFamily:"Inter,system-ui,sans-serif",
                    fontSize:12,cursor:"pointer"}}>{"Löschen"}</button>
              </div>
            </div>:<div style={{display:"flex",alignItems:"center",gap:10}}
              onClick={function(){setEditBand(b.id);}}>
              <span style={{fontSize:24}}>{b.emoji}</span>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:"600",color:"#f0e8ff",
                  fontFamily:"Inter,system-ui,sans-serif"}}>{b.name}</div>
                <div style={{fontSize:10,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginTop:2}}>
                  {(allSongs[b.id]||[]).length+" Songs"}
                </div>
              </div>
              <div style={{width:12,height:12,borderRadius:"50%",background:b.color,
                boxShadow:"0 0 8px "+b.color}}/>
              <span style={{color:"#9370b8",fontSize:14}}>{"›"}</span>
            </div>}
          </div>;
        })}

        {/* Add band button */}
        <button onClick={function(){addBand();setBandSheet(false);}}
          style={{width:"100%",padding:"12px",borderRadius:10,marginTop:4,
            border:"1.5px dashed #7c4dff44",background:"transparent",
            color:"#7c4dff",fontFamily:"Inter,system-ui,sans-serif",
            fontSize:13,fontWeight:"600",cursor:"pointer",letterSpacing:"0.04em"}}>
          {"+ Neue Band hinzufügen"}
        </button>
      </div>
    </div>}
  </div>;
}


// ── PrintView ─────────────────────────────────────────────────────────────
// Renders a clean print-optimized overlay, then triggers window.print()
function PrintView({measures,title,composer,bpm,onClose}){
  var printRef=useRef();

  useEffect(function(){
    // Give browser time to render, then print
    var t=setTimeout(function(){
      window.print();
    },400);
    return function(){clearTimeout(t);};
  },[]);

  // Listen for afterprint to close
  useEffect(function(){
    function done(){onClose();}
    window.addEventListener("afterprint",done);
    return function(){window.removeEventListener("afterprint",done);};
  },[]);

  var SVG_H=STOP+8*LS+10;
  var pageW=680;
  var mpr=4;
  var leftW=CLEF_W+6;
  var measW=Math.max(60,(pageW-leftW-32)/mpr);
  var rowWidth=leftW+measW*mpr;

  var rows=[];
  for(var i=0;i<measures.length;i+=mpr) rows.push(measures.slice(i,i+mpr));

  return <div ref={printRef} style={{
    position:"fixed",top:0,left:0,right:0,bottom:0,
    background:"white",zIndex:9999,overflowY:"auto",
  }}>
    {/* Close button - hidden when printing */}
    <button onClick={onClose} className="no-print" style={{
      position:"fixed",top:12,right:12,width:36,height:36,
      borderRadius:"50%",border:"1px solid #ccc",background:"white",
      cursor:"pointer",fontSize:18,color:"#666",zIndex:10000,
    }}>{"×"}</button>

    {/* Print styles injected */}
    <style dangerouslySetInnerHTML={{__html:`
      @media print {
        .no-print { display: none !important; }
        body { margin: 0; }
        @page { margin: 10mm; size: A4; }
      }
    `}}/>

    {/* Score sheet */}
    <div style={{
      maxWidth:pageW,margin:"0 auto",padding:"24px 24px 32px",
      fontFamily:"Times New Roman,serif",
    }}>
      {/* Title */}
      <div style={{textAlign:"center",borderBottom:"2px solid #111",paddingBottom:10,marginBottom:12}}>
        <div style={{fontSize:26,fontWeight:"800",color:"#111",letterSpacing:"-0.01em"}}>{title||"Untitled"}</div>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:"#555",marginTop:4}}>
          <span style={{fontStyle:"italic"}}>{composer||""}</span>
          <span>{"♪"} = {bpm} BPM</span>
        </div>
      </div>

      {/* Rows */}
      {rows.map(function(row,ri){
        var firstNum=ri*mpr+1;
        return <div key={ri} style={{marginBottom:4}}>
          <RowSVG
            row={row}
            rowWidth={rowWidth}
            firstMeasureNum={firstNum}
            onToggleNote={function(){}}
            onSelectMeasure={function(){}}
            selInstr="snare"
            selNVId="16"
            isFirst={ri===0}
            zoomedId={null}
          />
        </div>;
      })}
    </div>
  </div>;
}


// ── Rudiment data ─────────────────────────────────────────────────────────
var RUDIMENTS=[
  {cat:"Single Stroke",color:"#e040fb",items:[
    {id:"ss4",   label:"Single Stroke 4",    desc:"R L R L",              bpm:[60,80,100,120], notes:{"snare:0.000000":{accent:"normal",nvId:"8"},"snare:0.500000":{accent:"normal",nvId:"8"},"snare:1.000000":{accent:"normal",nvId:"8"},"snare:1.500000":{accent:"normal",nvId:"8"},"snare:2.000000":{accent:"normal",nvId:"8"},"snare:2.500000":{accent:"normal",nvId:"8"},"snare:3.000000":{accent:"normal",nvId:"8"},"snare:3.500000":{accent:"normal",nvId:"8"}}},
    {id:"ss7",   label:"Single Stroke 7",    desc:"R L R L R L R",        bpm:[60,80,100],     notes:{"snare:0.000000":{accent:"accent",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"normal",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"},"snare:1.500000":{accent:"normal",nvId:"16"}}},
  ]},
  {cat:"Double Stroke",color:"#40c4ff",items:[
    {id:"ds",    label:"Double Stroke Roll", desc:"R R L L",              bpm:[60,80,100,120], notes:{"snare:0.000000":{accent:"accent",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"accent",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"accent",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"},"snare:1.500000":{accent:"accent",nvId:"16"},"snare:1.750000":{accent:"normal",nvId:"16"},"snare:2.000000":{accent:"accent",nvId:"16"},"snare:2.250000":{accent:"normal",nvId:"16"},"snare:2.500000":{accent:"accent",nvId:"16"},"snare:2.750000":{accent:"normal",nvId:"16"},"snare:3.000000":{accent:"accent",nvId:"16"},"snare:3.250000":{accent:"normal",nvId:"16"},"snare:3.500000":{accent:"accent",nvId:"16"},"snare:3.750000":{accent:"normal",nvId:"16"}}},
    {id:"ms5",   label:"5-Stroke Roll",      desc:"R R L L R",            bpm:[60,80,100],     notes:{"snare:0.000000":{accent:"normal",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"accent",nvId:"8"}}},
    {id:"ms7",   label:"7-Stroke Roll",      desc:"R R L L R R L",        bpm:[60,80,100],     notes:{"snare:0.000000":{accent:"normal",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"normal",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"},"snare:1.500000":{accent:"accent",nvId:"8"}}},
    {id:"ms9",   label:"9-Stroke Roll",      desc:"R R L L R R L L R",    bpm:[60,80],         notes:{"snare:0.000000":{accent:"normal",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"normal",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"},"snare:1.500000":{accent:"normal",nvId:"16"},"snare:1.750000":{accent:"normal",nvId:"16"},"snare:2.000000":{accent:"accent",nvId:"8"}}},
  ]},
  {cat:"Paradiddle",color:"#69ff47",items:[
    {id:"para",  label:"Paradiddle",         desc:"R L R R  L R L L",     bpm:[60,80,100,120], notes:{"snare:0.000000":{accent:"accent",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"accent",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"},"snare:1.500000":{accent:"normal",nvId:"16"},"snare:1.750000":{accent:"normal",nvId:"16"}}},
    {id:"dpara", label:"Double Paradiddle",  desc:"R L R L R R  L R L R L L", bpm:[60,80,100], notes:{"snare:0.000000":{accent:"accent",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"normal",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"},"snare:1.500000":{accent:"accent",nvId:"16"},"snare:1.750000":{accent:"normal",nvId:"16"},"snare:2.000000":{accent:"normal",nvId:"16"},"snare:2.250000":{accent:"normal",nvId:"16"},"snare:2.500000":{accent:"normal",nvId:"16"},"snare:2.750000":{accent:"normal",nvId:"16"}}},
    {id:"ppara", label:"Paradiddle-diddle",  desc:"R L R R L L",           bpm:[60,80,100],    notes:{"snare:0.000000":{accent:"accent",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"normal",nvId:"16"},"snare:1.250000":{accent:"normal",nvId:"16"}}},
  ]},
  {cat:"Flam",color:"#ff9040",items:[
    {id:"flam",  label:"Flam",               desc:"fL  fR",                bpm:[60,80,100,120], notes:{"snare:0.000000":{accent:"flam",nvId:"4"},"snare:1.000000":{accent:"flam",nvId:"4"},"snare:2.000000":{accent:"flam",nvId:"4"},"snare:3.000000":{accent:"flam",nvId:"4"}}},
    {id:"flamtap",label:"Flam Tap",          desc:"fR R  fL L",            bpm:[60,80,100],     notes:{"snare:0.000000":{accent:"flam",nvId:"8"},"snare:0.500000":{accent:"normal",nvId:"8"},"snare:1.000000":{accent:"flam",nvId:"8"},"snare:1.500000":{accent:"normal",nvId:"8"},"snare:2.000000":{accent:"flam",nvId:"8"},"snare:2.500000":{accent:"normal",nvId:"8"},"snare:3.000000":{accent:"flam",nvId:"8"},"snare:3.500000":{accent:"normal",nvId:"8"}}},
    {id:"flamacc",label:"Flam Accent",       desc:"fR L R  fL R L",        bpm:[60,80],         notes:{"snare:0.000000":{accent:"flam",nvId:"8"},"snare:0.500000":{accent:"normal",nvId:"8"},"snare:1.000000":{accent:"normal",nvId:"8"},"snare:1.500000":{accent:"flam",nvId:"8"},"snare:2.000000":{accent:"normal",nvId:"8"},"snare:2.500000":{accent:"normal",nvId:"8"}}},
    {id:"flampar",label:"Flamacue",          desc:"fR L R L  fL",          bpm:[60,80],         notes:{"snare:0.000000":{accent:"flam",nvId:"16"},"snare:0.250000":{accent:"normal",nvId:"16"},"snare:0.500000":{accent:"normal",nvId:"16"},"snare:0.750000":{accent:"normal",nvId:"16"},"snare:1.000000":{accent:"flam",nvId:"16"}}},
  ]},
  {cat:"Drag",color:"#e040fb",items:[
    {id:"drag",  label:"Drag",               desc:"rr L",                  bpm:[60,80,100,120], notes:{"snare:0.000000":{accent:"ghost",nvId:"16"},"snare:0.250000":{accent:"ghost",nvId:"16"},"snare:0.500000":{accent:"accent",nvId:"8"},"snare:1.000000":{accent:"ghost",nvId:"16"},"snare:1.250000":{accent:"ghost",nvId:"16"},"snare:1.500000":{accent:"accent",nvId:"8"},"snare:2.000000":{accent:"ghost",nvId:"16"},"snare:2.250000":{accent:"ghost",nvId:"16"},"snare:2.500000":{accent:"accent",nvId:"8"},"snare:3.000000":{accent:"ghost",nvId:"16"},"snare:3.250000":{accent:"ghost",nvId:"16"},"snare:3.500000":{accent:"accent",nvId:"8"}}},
    {id:"dragtap",label:"Drag Tap",          desc:"rr L  R",               bpm:[60,80,100],     notes:{"snare:0.000000":{accent:"ghost",nvId:"16"},"snare:0.250000":{accent:"ghost",nvId:"16"},"snare:0.500000":{accent:"accent",nvId:"8"},"snare:1.000000":{accent:"normal",nvId:"8"},"snare:2.000000":{accent:"ghost",nvId:"16"},"snare:2.250000":{accent:"ghost",nvId:"16"},"snare:2.500000":{accent:"accent",nvId:"8"},"snare:3.000000":{accent:"normal",nvId:"8"}}},
  ]},
  {cat:"Buzz",color:"#7c4dff",items:[
    {id:"buzz",  label:"Buzz Roll",          desc:"zzzz",                  bpm:[60,80,100,120], notes:{"snare:0.000000":{accent:"normal",nvId:"8"},"snare:0.500000":{accent:"normal",nvId:"8"},"snare:1.000000":{accent:"normal",nvId:"8"},"snare:1.500000":{accent:"normal",nvId:"8"},"snare:2.000000":{accent:"normal",nvId:"8"},"snare:2.500000":{accent:"normal",nvId:"8"},"snare:3.000000":{accent:"normal",nvId:"8"},"snare:3.500000":{accent:"normal",nvId:"8"}}},
  ]},
];

// ── WarmupSheet ───────────────────────────────────────────────────────────
function WarmupSheet({onClose,onAddMeasure,bpm,setBpm}){
  var [selCat,setSelCat]=useState(null);
  var [practicing,setPracticing]=useState(null); // rudiment id being practiced

  var cats=RUDIMENTS.map(function(r){return r.cat;});
  var filtered=selCat?RUDIMENTS.filter(function(r){return r.cat===selCat;}):RUDIMENTS;

  return <div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:800,
    background:"#050510",display:"flex",flexDirection:"column",fontFamily:"Inter,system-ui,sans-serif"}}>

    {/* Header */}
    <div style={{background:"#0d0020",borderBottom:"1px solid #2a0045",
      padding:"12px 16px",display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
      <button onClick={onClose} style={{width:36,height:36,borderRadius:"50%",border:"none",
        background:"rgba(255,255,255,0.06)",color:"#a080c0",cursor:"pointer",fontSize:18,
        display:"flex",alignItems:"center",justifyContent:"center"}}>{"←"}</button>
      <div style={{flex:1}}>
        <div style={{fontSize:16,fontWeight:"800",color:"#f0e8ff",letterSpacing:"-0.01em"}}>{"🥁 Warmup"}</div>
        <div style={{fontSize:10,color:"#9370b8",marginTop:1}}>{"PAS 40 Rudiments — tippen zum Üben"}</div>
      </div>
      {/* BPM mini */}
      <div style={{display:"flex",alignItems:"center",gap:6,background:"#1a0035",
        borderRadius:8,padding:"4px 8px",border:"1px solid #2a0045"}}>
        <button onClick={function(){setBpm(Math.max(30,Number(bpm)-5));}}
          style={{background:"none",border:"none",color:"#e040fb",cursor:"pointer",fontSize:16,fontWeight:"700",padding:"0 2px"}}>{"-"}</button>
        <span style={{fontSize:13,fontWeight:"700",color:"#40c4ff",minWidth:30,textAlign:"center"}}>{bpm}</span>
        <button onClick={function(){setBpm(Math.min(300,Number(bpm)+5));}}
          style={{background:"none",border:"none",color:"#e040fb",cursor:"pointer",fontSize:16,fontWeight:"700",padding:"0 2px"}}>{"+"}</button>
      </div>
    </div>

    {/* Category filter pills */}
    <div style={{display:"flex",gap:6,padding:"10px 14px",overflowX:"auto",
      flexShrink:0,borderBottom:"1px solid #1a0035",WebkitOverflowScrolling:"touch",scrollbarWidth:"none"}}>
      <button onClick={function(){setSelCat(null);}}
        style={{padding:"5px 14px",borderRadius:20,border:"1px solid "+(selCat===null?"#e040fb":"#2a0045"),
          background:selCat===null?"#e040fb22":"#1a0035",color:selCat===null?"#e040fb":"#9370b8",
          fontSize:11,fontWeight:"600",cursor:"pointer",flexShrink:0,fontFamily:"Inter,system-ui,sans-serif"}}>
        {"Alle"}
      </button>
      {RUDIMENTS.map(function(g){
        var active=selCat===g.cat;
        return <button key={g.cat} onClick={function(){setSelCat(active?null:g.cat);}}
          style={{padding:"5px 14px",borderRadius:20,border:"1px solid "+(active?g.color:"#2a0045"),
            background:active?g.color+"22":"#1a0035",color:active?g.color:"#9370b8",
            fontSize:11,fontWeight:"600",cursor:"pointer",flexShrink:0,
            fontFamily:"Inter,system-ui,sans-serif"}}>
          {g.cat}
        </button>;
      })}
    </div>

    {/* Rudiment list */}
    <div style={{flex:1,overflowY:"auto",padding:"10px 14px 32px"}}>
      {filtered.map(function(group){
        return <div key={group.cat} style={{marginBottom:20}}>
          <div style={{fontSize:9,letterSpacing:"0.14em",textTransform:"uppercase",
            color:group.color,fontWeight:"700",marginBottom:8,fontFamily:"Inter,system-ui,sans-serif"}}>
            {group.cat}
          </div>
          {group.items.map(function(rud){
            var isPrac=practicing===rud.id;
            return <div key={rud.id} style={{
              background:isPrac?"linear-gradient(135deg,"+group.color+"22,"+group.color+"08)":"#0d0020",
              border:"1px solid "+(isPrac?group.color:"#2a0045"),
              borderRadius:12,padding:"12px 14px",marginBottom:8,
              boxShadow:isPrac?"0 0 16px "+group.color+"33":"none",
              transition:"all 0.2s",
            }}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:"700",color:isPrac?group.color:"#f0e8ff",
                    fontFamily:"Inter,system-ui,sans-serif"}}>{rud.label}</div>
                  <div style={{fontSize:11,color:"#9370b8",fontFamily:"monospace",
                    letterSpacing:"0.12em",marginTop:3}}>{rud.desc}</div>
                  <div style={{display:"flex",gap:4,marginTop:6,flexWrap:"wrap",alignItems:"center"}}>
                    <span style={{fontSize:9,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",
                      letterSpacing:"0.08em",marginRight:2}}>BPM:</span>
                    {rud.bpm.map(function(b){
                      return <button key={b} onClick={function(){setBpm(b);}}
                        style={{padding:"2px 8px",borderRadius:10,fontSize:9,
                          border:"1px solid "+(Number(bpm)===b?group.color:"#2a0045"),
                          background:Number(bpm)===b?group.color+"33":"#1a0035",
                          color:Number(bpm)===b?group.color:"#6a4a80",
                          cursor:"pointer",fontFamily:"Inter,system-ui,sans-serif",fontWeight:"600"}}>
                        {b}
                      </button>;
                    })}
                  </div>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:6}}>
                  <button onClick={function(){
                    setPracticing(isPrac?null:rud.id);
                  }} style={{
                    width:42,height:42,borderRadius:10,border:"1px solid "+(isPrac?group.color:"#2a0045"),
                    background:isPrac?group.color+"33":"#1a0035",
                    color:isPrac?group.color:"#9370b8",cursor:"pointer",fontSize:18,
                    display:"flex",alignItems:"center",justifyContent:"center",
                  }}>{isPrac?"⏹":"▶"}</button>
                  <button onClick={function(){
                    onAddMeasure(rud.notes);
                  }} style={{
                    width:42,height:42,borderRadius:10,border:"1px solid #2a0045",
                    background:"#1a0035",color:"#69ff47",cursor:"pointer",fontSize:16,
                    display:"flex",alignItems:"center",justifyContent:"center",
                  }} title="Als Takt einfügen">{"+"}</button>
                </div>
              </div>
              {isPrac&&<div style={{marginTop:10,padding:"8px 10px",background:"#0a001a",
                borderRadius:8,border:"1px solid #2a0045"}}>
                <div style={{fontSize:9,color:"#9370b8",letterSpacing:"0.1em",
                  textTransform:"uppercase",marginBottom:4}}>{"Übungstempi"}</div>
                <div style={{fontSize:11,color:group.color,fontFamily:"Inter,system-ui,sans-serif"}}>
                  {"Starte mit "+rud.bpm[0]+" BPM · Steigere in 5er Schritten · Ziel: "+rud.bpm[rud.bpm.length-1]+" BPM"}
                </div>
              </div>}
            </div>;
          })}
        </div>;
      })}
    </div>
  </div>;
}


// ── ErrorBoundary ─────────────────────────────────────────────────────────
class ErrorBoundary extends React.Component {
  constructor(props){
    super(props);
    this.state={hasError:false,error:null};
  }
  static getDerivedStateFromError(error){
    return {hasError:true,error:error};
  }
  componentDidCatch(error,info){
    console.error("DrumWriter error:",error,info);
  }
  render(){
    if(this.state.hasError){
      return <div style={{
        position:"fixed",top:0,left:0,right:0,bottom:0,
        background:"#050510",display:"flex",flexDirection:"column",
        alignItems:"center",justifyContent:"center",padding:32,
        fontFamily:"Inter,system-ui,sans-serif",
      }}>
        <div style={{fontSize:48,marginBottom:16}}>{"🥁"}</div>
        <div style={{fontSize:18,fontWeight:"700",color:"#f0e8ff",marginBottom:8}}>
          {"Oops — DrumWriter ist abgestürzt"}
        </div>
        <div style={{fontSize:12,color:"#9370b8",marginBottom:24,textAlign:"center"}}>
          {this.state.error&&this.state.error.message}
        </div>
        <button onClick={function(){window.location.reload();}} style={{
          padding:"12px 24px",borderRadius:10,border:"none",
          background:"linear-gradient(135deg,#e040fb,#7c4dff)",
          color:"white",fontSize:14,fontWeight:"700",cursor:"pointer",
        }}>{"App neu starten"}</button>
      </div>;
    }
    return this.props.children;
  }
}


// ── Tutorial ──────────────────────────────────────────────────────────────
var TUTORIAL_STEPS=[
  {
    id:"welcome",
    emoji:"🥁",
    title:"Willkommen bei DrumWriter!",
    text:"Die App für Drummer — Notation, Metronom und Setlist in einer App. Lass uns die wichtigsten Funktionen kurz durchgehen.",
    highlight:null,
    action:null,
  },
  {
    id:"notation",
    emoji:"🎵",
    title:"Notenblatt",
    text:"Hier siehst du dein Notenblatt. Tippe auf einen Takt um die Zoom-Ansicht zu öffnen — dort kannst du Noten setzen.",
    highlight:"score",
    action:"Tippe auf Takt 1",
  },
  {
    id:"zoom",
    emoji:"🔍",
    title:"Zoom-Ansicht",
    text:"In der Zoom-Ansicht kannst du Noten setzen. Tippe auf eine leere Stelle um eine Note zu platzieren. Tippe nochmal zum Löschen.",
    highlight:"zoom",
    action:"Tippe auf das Notenblatt",
  },
  {
    id:"instruments",
    emoji:"🥁",
    title:"Instrumente",
    text:"Wähle mit dem SNARE-Button unten das Instrument. Tippe auf einen anderen Button um z.B. HiHat oder Kick zu wählen.",
    highlight:"toolbar",
    action:"Tippe auf einen Instrument-Button",
  },
  {
    id:"longpress",
    emoji:"✏",
    title:"Note bearbeiten",
    text:"Halte eine Note gedrückt (Long-Press) um sie zu bearbeiten — Instrument wechseln, Artikulation oder Notenwert ändern.",
    highlight:"zoom",
    action:"Note lange gedrückt halten",
  },
  {
    id:"metronome",
    emoji:"⏱",
    title:"Metronom",
    text:"Tippe oben auf 'Metronom' um das eingebaute Metronom zu öffnen. Count-In, Tap Tempo und Stimme sind dabei.",
    highlight:"tabs",
    action:null,
  },
  {
    id:"setlist",
    emoji:"🎸",
    title:"Setlist & Bands",
    text:"Im Setlist-Tab kannst du Songs für deine Bands verwalten. Mehrere Bands möglich — z.B. für Cover-Band und Original-Projekt.",
    highlight:"tabs",
    action:null,
  },
  {
    id:"warmup",
    emoji:"💪",
    title:"Warmup & Rudiments",
    text:"Der 🥁 Warmup-Button öffnet PAS Rudiments mit BPM-Vorgaben — perfekt zum Üben vor der Probe.",
    highlight:"toolbar2",
    action:null,
  },
  {
    id:"export",
    emoji:"💾",
    title:"Speichern & Teilen",
    text:"Mit ⇅ kannst du deine Grooves als JSON exportieren und wieder laden. PDF drucken ist auch möglich.",
    highlight:"toolbar2",
    action:null,
  },
  {
    id:"done",
    emoji:"🚀",
    title:"Los geht's!",
    text:"Du kennst jetzt die wichtigsten Funktionen. Viel Spaß beim Komponieren! Du kannst das Tutorial jederzeit über ⚙ neu starten.",
    highlight:null,
    action:null,
  },
];

function Tutorial({onClose,onSkip}){
  var stepState=useState(0); var step=stepState[0]; var setStep=stepState[1];
  var cur=TUTORIAL_STEPS[step];
  var total=TUTORIAL_STEPS.length;
  var isLast=step===total-1;

  return <div style={{
    position:"fixed",top:0,left:0,right:0,bottom:0,
    zIndex:9000,background:"rgba(5,5,16,0.92)",
    display:"flex",flexDirection:"column",alignItems:"center",
    justifyContent:"center",padding:"24px 20px",
    fontFamily:"Inter,system-ui,sans-serif",
  }}>
    {/* Progress dots */}
    <div style={{display:"flex",gap:6,marginBottom:28}}>
      {TUTORIAL_STEPS.map(function(_,i){
        return <div key={i} style={{
          width:i===step?20:6,height:6,borderRadius:3,
          background:i===step?"#e040fb":i<step?"#7c4dff44":"#2a0045",
          transition:"all 0.3s",
        }}/>;
      })}
    </div>

    {/* Card */}
    <div style={{
      background:"#0d0020",border:"1.5px solid #e040fb",borderRadius:20,
      padding:"28px 24px",maxWidth:360,width:"100%",
      boxShadow:"0 0 60px rgba(224,64,251,0.2),0 20px 60px rgba(0,0,0,0.8)",
      textAlign:"center",
    }}>
      <div style={{fontSize:52,marginBottom:16,lineHeight:1}}>{cur.emoji}</div>
      <div style={{fontSize:19,fontWeight:"800",color:"#f0e8ff",
        marginBottom:12,letterSpacing:"-0.02em"}}>{cur.title}</div>
      <div style={{fontSize:14,color:"#9370b8",lineHeight:1.6,marginBottom:20}}>
        {cur.text}
      </div>
      {cur.action&&<div style={{
        padding:"8px 14px",borderRadius:8,
        background:"#e040fb18",border:"1px solid #e040fb44",
        color:"#e040fb",fontSize:12,fontWeight:"600",
        letterSpacing:"0.04em",marginBottom:20,
      }}>{"→ "+cur.action}</div>}
    </div>

    {/* Navigation */}
    <div style={{display:"flex",gap:12,marginTop:24,width:"100%",maxWidth:360}}>
      {step>0&&<button onClick={function(){setStep(function(s){return s-1;});}}
        style={{flex:1,padding:"12px",borderRadius:10,border:"1px solid #2a0045",
          background:"#1a0035",color:"#9370b8",fontSize:14,cursor:"pointer",fontWeight:"600"}}>
        {"‹ Zurück"}
      </button>}
      <button onClick={function(){
        if(isLast){onClose();}
        else{setStep(function(s){return s+1;});}
      }} style={{
        flex:2,padding:"12px",borderRadius:10,border:"none",
        background:isLast?"linear-gradient(135deg,#69ff47,#40c4ff)":"linear-gradient(135deg,#e040fb,#7c4dff)",
        color:"white",fontSize:14,cursor:"pointer",fontWeight:"700",
        boxShadow:isLast?"0 0 20px #69ff4755":"0 0 20px #e040fb44",
      }}>
        {isLast?"🚀 App starten":"Weiter ›"}
      </button>
    </div>

    {/* Skip */}
    {!isLast&&<button onClick={onSkip}
      style={{marginTop:14,background:"none",border:"none",
        color:"#4a2060",fontSize:12,cursor:"pointer",
        fontFamily:"Inter,system-ui,sans-serif"}}>
      {"Tutorial überspringen"}
    </button>}
  </div>;
}

export default function DrumWriter(){
  var [measures,setMeasures]=useState(function(){return [newMeasure("4/4",{},"")];});
  var [selInstr,setSelInstr]=useState("snare");
  var [selAccent,setSelAccent]=useState("normal");
  var [selNVId,setSelNVId]=useState(DEFAULT_NV_ID);
  var [measPerRow,setMPR]=useState(4);
  var [title,setTitle]=useState("Untitled");
  var [composer,setComposer]=useState("");
  var [bpm,setBpm]=useState(120);
  var metro=useMetronome(bpm);
  var [scoreW,setScoreW]=useState(900);
  var [zoomedId,setZoomedId]=useState(null);
  var [presetOpen,setPresetOpen]=useState(false);
  var [orchOpen,setOrchOpen]=useState(false);
  var [metroView,setMetroView]=useState(false);
  var [setlistView,setSetlistView]=useState(false);
  var [printView,setPrintView]=useState(false);
  var [ioSheet,setIoSheet]=useState(false);
  var [showTutorial,setShowTutorial]=useState(function(){
    try{return !localStorage.getItem("dw_tutorial_done");}
    catch(e){return true;}
  });
  function completeTutorial(){
    try{localStorage.setItem("dw_tutorial_done","1");}catch(e){}
    setShowTutorial(false);
  }
  var [warmupOpen,setWarmupOpen]=useState(false);
  var [speechLang,setSpeechLang]=useState(function(){return detectLang();});
  var [appLang,setAppLang]=useState(function(){return detectLang();});
  var T=function(key){return t(appLang,key);};
  var scoreRef=useRef();

  // Load Inter font
  useEffect(function(){
    if(document.getElementById('dw-font')) return;
    var link=document.createElement('link');
    link.id='dw-font';
    link.rel='stylesheet';
    link.href='https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap';
    document.head.appendChild(link);
  },[]);

  // Detect stylus/pen and show indicator
  useEffect(function(){
    function onPen(e){
      if(e.pointerType==="pen"){
        var el=document.getElementById("dw-pen-indicator");
        if(el)el.style.display="inline";
      }
    }
    window.addEventListener("pointerdown",onPen,{passive:true});
    return function(){window.removeEventListener("pointerdown",onPen);};
  },[]);

  // Android back button closes modals
  useEffect(function(){
    function onBack(e){
      if(warmupOpen){setWarmupOpen(false);history.pushState(null,'',window.location.href);return;}
      if(ioSheet){setIoSheet(false);history.pushState(null,'',window.location.href);return;}
      if(zoomedId){setZoomedId(null);history.pushState(null,'',window.location.href);return;}
      if(metroView){setMetroView(false);history.pushState(null,'',window.location.href);return;}
      if(setlistView){setSetlistView(false);history.pushState(null,'',window.location.href);return;}
    }
    window.addEventListener('popstate',onBack);
    history.pushState(null,'',window.location.href);
    return function(){window.removeEventListener('popstate',onBack);};
  },[warmupOpen,ioSheet,zoomedId,metroView,setlistView]);

  useEffect(function(){
    if(!scoreRef.current)return;
    var obs=new ResizeObserver(function(entries){if(entries[0])setScoreW(entries[0].contentRect.width);});
    obs.observe(scoreRef.current);
    return function(){obs.disconnect();};
  },[]);

  var updateNote=useCallback(function(measId,instrId,beat,patch){
    setMeasures(function(prev){return prev.map(function(m){
      if(m.id!==measId)return m;
      var key=instrId+":"+beat.toFixed(6);
      var notes={};
      for(var k in m.notes){if(m.notes.hasOwnProperty(k))notes[k]=m.notes[k];}
      if(notes[key]){
        notes[key]=Object.assign({},notes[key],patch);
      }
      return Object.assign({},m,{notes:notes});
    });});
  },[]);

  var toggleNote=useCallback(function(measId,instrId,beat,nvId){
    setMeasures(function(prev){return prev.map(function(m){
      if(m.id!==measId)return m;
      var key=instrId+":"+beat.toFixed(6);
      var notes={};for(var k in m.notes){if(m.notes.hasOwnProperty(k))notes[k]=m.notes[k];}
      if(notes[key])delete notes[key];else notes[key]={accent:selAccent,nvId:nvId};
      return Object.assign({},m,{notes:notes});
    });});
  },[selAccent]);

  function applyPresetToMeasure(pNotes){
    var tid=zoomedId||measures[measures.length-1].id;
    setMeasures(function(prev){return prev.map(function(m){return m.id!==tid?m:Object.assign({},m,{notes:mergeNotes(m.notes,pNotes)});});});
    setPresetOpen(false);
  }
  function applyOrchToMeasure(syms){
    var tid=zoomedId||measures[measures.length-1].id;
    setMeasures(function(prev){return prev.map(function(m){return m.id!==tid?m:Object.assign({},m,{symbols:syms});});});
    setOrchOpen(false);
  }
  function addMeasure(){setMeasures(function(p){var ts=p.length>0?p[p.length-1].timeSig:"4/4";return p.concat([newMeasure(ts,{},"")]);});}
  function delLast(){setMeasures(function(p){return p.length>1?p.slice(0,-1):p;});}
  function addAfterMeasure(id){
    setMeasures(function(p){
      var idx=p.findIndex(function(m){return m.id===id;});
      var ts=idx>=0?p[idx].timeSig:"4/4";
      var arr=p.slice();
      arr.splice(idx+1,0,newMeasure(ts,{},""));
      return arr;
    });
  }
  function updMeas(id,k,v){
    setMeasures(function(p){return p.map(function(m){return m.id!==id?m:Object.assign({},m,{[k]:v});});});
  }
  function clearMeasure(id){setMeasures(function(p){return p.map(function(m){return m.id!==id?m:Object.assign({},m,{notes:{},symbols:[]});});});}

  var rows=[];
  for(var i=0;i<measures.length;i+=measPerRow)rows.push(measures.slice(i,i+measPerRow));
  var pageW=scoreW-20; var rowWidth=Math.max(300,pageW);
  var zoomedMeas=measures.find(function(m){return m.id===zoomedId;});
  var zoomedIdx=measures.findIndex(function(m){return m.id===zoomedId;});

  return <ErrorBoundary><div style={{display:"flex",flexDirection:"column",height:"100vh",touchAction:"pan-y",background:"#050510",overflow:"hidden",fontFamily:"Inter,system-ui,sans-serif"}}>
    <div style={{background:"#0d0020",borderBottom:"1px solid #2a0045",flexShrink:0}}>
      {/* Row 1: Tabs */}
      <div style={{display:"flex",alignItems:"center",borderBottom:"1px solid #1a0035",padding:"0 4px"}}>
        <button onClick={function(){setMetroView(false);setSetlistView(false);}}
          style={{padding:"0 14px",height:42,border:"none",background:"transparent",cursor:"pointer",
            borderBottom:(!metroView&&!setlistView)?"2px solid #e040fb":"2px solid transparent",
            color:(!metroView&&!setlistView)?"#f0e8ff":"#9370b8",
            fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:(!metroView&&!setlistView)?"700":"400",
            letterSpacing:"0.02em",flexShrink:0}}>
          {T("notation")}
        </button>
        <button onClick={function(){setMetroView(true);setSetlistView(false);}}
          style={{padding:"0 14px",height:42,border:"none",background:"transparent",cursor:"pointer",
            borderBottom:(metroView&&!setlistView)?"2px solid #40c4ff":"2px solid transparent",
            color:(metroView&&!setlistView)?"#40c4ff":"#9370b8",
            fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:(metroView&&!setlistView)?"700":"400",
            letterSpacing:"0.02em",flexShrink:0}}>
          {metro.playing?("▶ "+((metro.beat||0)+1)):T("metronome")}
        </button>
        <button onClick={function(){setSetlistView(true);setMetroView(false);}}
          style={{padding:"0 14px",height:42,border:"none",background:"transparent",cursor:"pointer",
            borderBottom:setlistView?"2px solid #69ff47":"2px solid transparent",
            color:setlistView?"#69ff47":"#9370b8",
            fontFamily:"Inter,system-ui,sans-serif",fontSize:13,fontWeight:setlistView?"700":"400",
            letterSpacing:"0.02em",flexShrink:0}}>
          {"🎵 "+T("setlist")}
        </button>
        <div style={{flex:1}}/>
        <div style={{position:"relative",flexShrink:0,marginRight:8}}>
          <select value={speechLang}
            onChange={function(e){
              setSpeechLang(e.target.value);
              setAppLang(e.target.value);
              setTimeout(function(){
                if(window.speechSynthesis){
                  window.speechSynthesis.cancel();
                  var l=getLangDef(e.target.value);
                  var u=new SpeechSynthesisUtterance(l.nums[0]+", "+l.nums[1]);
                  u.lang=e.target.value; u.rate=1.2;
                  window.speechSynthesis.speak(u);
                }
              },100);
            }}
            style={{
              height:34,paddingLeft:8,paddingRight:24,
              borderRadius:8,border:"1px solid #7c4dff",
              background:"#1a0035",color:"#f0e8ff",
              fontSize:13,outline:"none",cursor:"pointer",
              WebkitAppearance:"none",appearance:"none",
              fontFamily:"Inter,system-ui,sans-serif",
            }}>
            {SPEECH_LANGS.map(function(l){
              return <option key={l.id} value={l.id} style={{background:"#0d0020",color:"#f0e8ff"}}>
                {l.flag+" "+l.label}
              </option>;
            })}
          </select>
          <span style={{position:"absolute",right:7,top:"50%",transform:"translateY(-50%)",
            pointerEvents:"none",color:"#7c4dff",fontSize:10}}>{"▾"}</span>
        </div>
      </div>
      {/* Row 2: Title + Actions (only in Notation mode) */}
      {(!metroView&&!setlistView)&&<div style={{display:"flex",alignItems:"center",gap:6,padding:"6px 10px"}}>
        <input value={title} onChange={function(e){setTitle(e.target.value);}}
          placeholder="Titel..."
          style={{fontSize:14,fontWeight:"700",fontFamily:"Inter,system-ui,sans-serif",
            border:"none",outline:"none",background:"transparent",
            color:"#f0e8ff",flex:1,minWidth:60,letterSpacing:"-0.01em"}}/>
        <button onClick={addMeasure}
          style={{width:32,height:32,border:"1px solid #2a0045",borderRadius:8,
            background:"#1a0035",cursor:"pointer",color:"#e040fb",fontSize:18,
            display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"700",flexShrink:0}}>{"+"}</button>
        <button onClick={delLast}
          style={{width:32,height:32,border:"1px solid #2a0045",borderRadius:8,
            background:"#1a0035",cursor:"pointer",color:"#7c4dff",fontSize:18,
            display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"700",flexShrink:0}}>{"-"}</button>
        <button onClick={function(){setWarmupOpen(true);}}
          style={{padding:"4px 10px",borderRadius:8,border:"1px solid #40c4ff44",
            background:"#001a20",cursor:"pointer",color:"#40c4ff",
            fontFamily:"Inter,system-ui,sans-serif",fontSize:11,fontWeight:"700",
            flexShrink:0,letterSpacing:"0.04em",
            boxShadow:"0 0 8px #40c4ff22"}}>{"🥁 Warmup"}</button>
        <button onClick={function(){setIoSheet(true);}}
          style={{width:32,height:32,border:"1px solid #2a0045",borderRadius:8,
            background:"#1a0035",cursor:"pointer",color:"#40c4ff",fontSize:16,
            display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"700",flexShrink:0}}>{"⇅"}</button>
        <button onClick={function(){setPrintView(true);}}
          style={{padding:"6px 14px",borderRadius:8,cursor:"pointer",
            fontFamily:"Inter,system-ui,sans-serif",fontSize:12,
            background:"linear-gradient(135deg,#e040fb,#7c4dff)",
            color:"white",border:"none",fontWeight:"700",flexShrink:0,
            boxShadow:"0 0 12px #e040fb44"}}>PDF</button>
      </div>}
    </div>

    {metroView&&!setlistView&&<MetronomeView onBack={function(){setMetroView(false);}} bpm={bpm} setBpm={setBpm} metro={metro} speechLang={speechLang} setSpeechLang={setSpeechLang} appLang={appLang} setAppLang={setAppLang}/>}
    {setlistView&&<SetlistView metro={metro} bpm={bpm} setBpm={setBpm} speechLang={speechLang} appLang={appLang}/>}

    <div ref={scoreRef} style={{flex:1,overflowY:"auto",background:"#050510",display:(metroView||setlistView)?"none":"block",paddingBottom:zoomedId?"290px":"72px"}}>
      <div style={{background:"white",margin:"12px auto",maxWidth:"min(860px,calc(100vw - 24px))",minHeight:"calc(100vh - 120px)",boxShadow:"0 2px 16px rgba(0,0,0,0.18)",borderRadius:2,padding:"16px 10px 24px"}}>
        <div style={{textAlign:"center",marginBottom:8,borderBottom:"2px solid #111",paddingBottom:8}}>
          <div style={{fontSize:22,fontWeight:"800",fontFamily:"Times New Roman,serif",color:"#111"}}>{title||"Untitled"}</div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#666",fontFamily:"Times New Roman,serif",marginTop:3}}>
            <span style={{fontStyle:"italic"}}>{composer||" "}</span>
            <span>{"♪"} = {bpm} BPM</span>
          </div>
        </div>
        {rows.map(function(row,ri){
          var firstNum=ri*measPerRow+1;
          return <div key={ri}>
            <RowSVG row={row} rowWidth={rowWidth} firstMeasureNum={firstNum}
              onToggleNote={null}
              onSelectMeasure={function(id){setZoomedId(function(prev){return prev===id?null:id;});}}
              selInstr={selInstr} selNVId={selNVId} isFirst={ri===0} zoomedId={zoomedId}/>
          </div>;
        })}
        <button onClick={addMeasure} style={{marginTop:12,width:"100%",padding:"8px 0",
          background:"transparent",border:"1.5px dashed #2a0045",borderRadius:4,
          cursor:"pointer",color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",
          fontSize:11,letterSpacing:"0.1em",textTransform:"uppercase",
          transition:"all 0.2s"}}>{T("addMeasure")}</button>
      </div>
    </div>
    {zoomedId&&zoomedMeas&&<ZoomPanel
      measure={zoomedMeas} measNum={zoomedIdx+1}
      onClose={function(){setZoomedId(null);}}
      onToggleNote={toggleNote}
      onUpdateNote={updateNote}
      selInstr={selInstr} selNVId={selNVId}
      hasPrev={zoomedIdx>0} hasNext={zoomedIdx<measures.length-1}
      onPrev={function(){setZoomedId(measures[zoomedIdx-1].id);}}
      onNext={function(){setZoomedId(measures[zoomedIdx+1].id);}}
      updMeas={updMeas}
      onOpenPresets={function(){setPresetOpen(true);}}
      onOpenOrch={function(){setOrchOpen(true);}}
      onAddAfter={addAfterMeasure}
      onClear={function(){clearMeasure(zoomedId);}}
    />}

    {presetOpen&&<PresetPanel onApply={applyPresetToMeasure} onClose={function(){setPresetOpen(false);}}/>}
    {orchOpen&&<OrchPanel onApply={applyOrchToMeasure} onClose={function(){setOrchOpen(false);}} currentSymbols={zoomedMeas?zoomedMeas.symbols:[]} currentRepeat={zoomedMeas?zoomedMeas.repeat:"none"} onSetRepeat={function(rv){if(zoomedId)updMeas(zoomedId,"repeat",rv);}}/>}
    {warmupOpen&&<WarmupSheet
      onClose={function(){setWarmupOpen(false);}}
      bpm={bpm} setBpm={setBpm}
      onAddMeasure={function(notes){
        setMeasures(function(prev){
          var ts=prev.length>0?prev[prev.length-1].timeSig:"4/4";
          return prev.concat([newMeasure(ts,notes,"")]);
        });
        setWarmupOpen(false);
      }}
    />}
    {ioSheet&&<div style={{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:600,
      background:"rgba(5,5,16,0.88)",display:"flex",alignItems:"flex-end"}}
      onClick={function(){setIoSheet(false);}}>
      <div onClick={function(e){e.stopPropagation();}} style={{
        background:"#0d0020",borderRadius:"20px 20px 0 0",width:"100%",maxWidth:640,
        margin:"0 auto",padding:"24px 20px 40px",
        border:"1px solid #2a0045",borderBottom:"none",
        boxShadow:"0 -20px 60px rgba(64,196,255,0.12), 0 -4px 0 #40c4ff",
      }}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
          <span style={{fontSize:15,fontWeight:"700",color:"#f0e8ff",fontFamily:"Inter,system-ui,sans-serif"}}>{"Import / Export"}</span>
          <button onClick={function(){setIoSheet(false);}} style={{width:28,height:28,borderRadius:"50%",
            border:"1px solid #2a0045",background:"#1a0035",color:"#a080c0",
            cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>{"×"}</button>
        </div>

        {/* EXPORT section */}
        <div style={{fontSize:9,color:"#9370b8",letterSpacing:"0.14em",textTransform:"uppercase",
          fontFamily:"Inter,system-ui,sans-serif",marginBottom:8}}>{"Export"}</div>
        <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:20}}>
          <button onClick={function(){exportGroovesJSON(measures,title,bpm);setIoSheet(false);}}
            style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",borderRadius:12,
              border:"1px solid #2a0045",background:"#0a001a",cursor:"pointer",textAlign:"left"}}>
            <span style={{fontSize:24}}>{"📦"}</span>
            <div>
              <div style={{fontSize:13,fontWeight:"700",color:"#69ff47",fontFamily:"Inter,system-ui,sans-serif"}}>{"DrumWriter JSON"}</div>
              <div style={{fontSize:11,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginTop:2}}>{"Alle Takte, Titel & BPM speichern"}</div>
            </div>
            <span style={{marginLeft:"auto",fontSize:18,color:"#69ff47"}}>{"↓"}</span>
          </button>
          <button onClick={function(){setPrintView(true);setIoSheet(false);}}
            style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",borderRadius:12,
              border:"1px solid #2a0045",background:"#0a001a",cursor:"pointer",textAlign:"left"}}>
            <span style={{fontSize:24}}>{"📄"}</span>
            <div>
              <div style={{fontSize:13,fontWeight:"700",color:"#e040fb",fontFamily:"Inter,system-ui,sans-serif"}}>{"Als PDF drucken"}</div>
              <div style={{fontSize:11,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginTop:2}}>{"Saubere Notenblatt-Ansicht"}</div>
            </div>
            <span style={{marginLeft:"auto",fontSize:18,color:"#e040fb"}}>{"→"}</span>
          </button>
        </div>

        {/* IMPORT section */}
        <div style={{fontSize:9,color:"#9370b8",letterSpacing:"0.14em",textTransform:"uppercase",
          fontFamily:"Inter,system-ui,sans-serif",marginBottom:8}}>{"Import"}</div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <label style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",borderRadius:12,
            border:"1px solid #2a0045",background:"#0a001a",cursor:"pointer"}}>
            <span style={{fontSize:24}}>{"📦"}</span>
            <div>
              <div style={{fontSize:13,fontWeight:"700",color:"#69ff47",fontFamily:"Inter,system-ui,sans-serif"}}>{"DrumWriter JSON laden"}</div>
              <div style={{fontSize:11,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginTop:2}}>{"Gespeicherte Grooves importieren"}</div>
            </div>
            <span style={{marginLeft:"auto",fontSize:18,color:"#69ff47"}}>{"↑"}</span>
            <input type="file" accept=".json" style={{display:"none"}}
              onChange={function(e){
                var f=e.target.files[0];if(!f)return;
                var r=new FileReader();
                r.onload=function(ev){
                  var data=importGroovesJSON(ev.target.result);
                  if(data&&data.measures){
                    setMeasures(data.measures.map(function(m){return Object.assign({},m,{id:uid()});}));
                    if(data.title)setTitle(data.title);
                    if(data.bpm)setBpm(Number(data.bpm)||120);
                    setIoSheet(false);
                  } else {alert("Ungültige DrumWriter-Datei");}
                };
                r.readAsText(f);
                e.target.value="";
              }}/>
          </label>
          <label style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",borderRadius:12,
            border:"1px solid #2a0045",background:"#0a001a",cursor:"pointer"}}>
            <span style={{fontSize:24}}>{"🎵"}</span>
            <div>
              <div style={{fontSize:13,fontWeight:"700",color:"#40c4ff",fontFamily:"Inter,system-ui,sans-serif"}}>{"MIDI importieren"}</div>
              <div style={{fontSize:11,color:"#9370b8",fontFamily:"Inter,system-ui,sans-serif",marginTop:2}}>{"Channel 10 Drum-Spur (.mid / .midi)"}</div>
            </div>
            <span style={{marginLeft:"auto",fontSize:18,color:"#40c4ff"}}>{"↑"}</span>
            <input type="file" accept=".mid,.midi" style={{display:"none"}}
              onChange={function(e){
                var f=e.target.files[0];if(!f)return;
                var r=new FileReader();
                r.onload=function(ev){
                  var m=parseMidi(ev.target.result);
                  if(m){
                    setMeasures(function(prev){return prev.concat([m]);});
                    setIoSheet(false);
                  } else {alert("MIDI: Keine Drum-Spur gefunden (Channel 10)");}
                };
                r.readAsArrayBuffer(f);
                e.target.value="";
              }}/>
          </label>
        </div>
      </div>
    </div>}
    {printView&&<PrintView
      measures={measures} title={title} composer={composer} bpm={bpm}
      onClose={function(){setPrintView(false);}}
    />}
    {!zoomedId&&!metroView&&!setlistView&&<BottomToolbar selInstr={selInstr} setSelInstr={setSelInstr} selAccent={selAccent} setSelAccent={setSelAccent} selNVId={selNVId} setSelNVId={setSelNVId} measPerRow={measPerRow} setMPR={setMPR} onOpenPresets={function(){setPresetOpen(true);}} onOpenOrch={function(){setOrchOpen(true);}}/>}
  {showTutorial&&<Tutorial
    onClose={completeTutorial}
    onSkip={completeTutorial}
  />}
  </div></ErrorBoundary>;
}
